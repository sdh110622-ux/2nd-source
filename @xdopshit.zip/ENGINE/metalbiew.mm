#import "ESP/metalbiew.h"
#import "ESP/mahoa.h"
#include "sys/mman.h"
#include "ESP/Tools.h"
#import <AVFoundation/AVFoundation.h>
#include <stdio.h>
#include <stdint.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "authcheatbot/FTNotificationIndicator.h"
#import "authcheatbot/FCUUID.h"
#import "authcheatbot/menuButtonConfigLQ.h"
#import "authcheatbot/MBProgressHUD.h"
#import "authcheatbot/Reachability.h"
#include "ESP/Icon.h"
#include "ESP/Iconcpp.h"
#include "ESP/ico_font.h"
#include <string>
#include <stdio.h>
#include <string.h>
#include "ESP/Vector3.hpp"
#include "ESP/Vector2.hpp"
#import <Foundation/Foundation.h>
#import "ESP/UE4.h"
#import "ESP/PubgLoad.h"
#import "ESP/ini_rw.h"
#include "ESP/imgui_notify.h"
#include "ESP/tahoma.h"
#include "ESP/Include.h"
#import "PatchNonJB/PatchNonJB.h"
#import "ESP/ImageData.h"
#import "ESP/imgui/stb_image.h"
#import <UIKit/UIKit.h>

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
NSString *xrpb = NSSENCRYPT("Paste Key...");

#define E(str) _xor_(str).c_str()


#define iPhone8P ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)


NSString *bundle;
uint64_t GUObjectArray;
uint64_t GNameFun;

@interface metalbiew () <MTKViewDelegate>
@property (nonatomic, strong) IBOutlet MTKView *mtkView;
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;


@end


bool ESPPlayer = false;
bool ShowFov = false;
bool isAimvisual = true;
bool WideView = false;
bool Crosshair = false;
int smoothIndex = 2;
int Istargets = 2;
int WideValue = 100;
float IsAimBotRecc = 1.183f;
float AimBotSpeed = 10.0f;
static int chedoaim = 4;

static uintptr_t Get_module_base() {
    uint32_t count = _dyld_image_count();
    for (int i = 0; i < count; i++) {
        std::string path = (const char *)_dyld_get_image_name(i);
        if (path.find("ShadowTrackerExtra.app/ShadowTrackerExtra") != path.npos) {
            return (uintptr_t)_dyld_get_image_vmaddr_slide(i);
        }
    }
    return 0;
}

bool IsValidAddress(kaddr addr) {
    return addr > 0x100000000 && addr < 0x2000000000;
}

bool anti1 =false;
bool anti2 =false;
bool anti3 =false;
bool anti4 =false;
bool init1 = false;
bool init2 = false;
bool init3 = false;
bool init4 = false;
bool init5 = false;
bool giamgiat = false;

uintptr_t UE4;
kaddr module= (unsigned long)Get_module_base();

namespace Options
{
int boxtype = 1;
int healthbartype = 0;
int Nationtype = 2;
int DirectionLineSize = 70;
int VehicleDirectionLineSize = 100;
int offscreen_range = 40;
int max_distance_offscreen = 400;
int playersdistancessize = 600;
bool esp_Outline = true;
int distance_Radar = 150;
}

enum EAimTarget {
    Head = 0,
    Chest = 1
};

enum EAimTrigger {
    None = 0,
    Shooting = 1,
    Scoping = 2,
    Both = 3,
    Any = 4
};


long l1 = 0xFF544;
long l2 = 0xFFFFF;
int stack_20;
NSString * val_1;
NSString * val_x2 ;
int sort = 1,sort_1 = 3;
long RAMADDRESS = 0x4332443;
bool stack_193 = NO;
using namespace std;
using namespace SDK;

struct sConfig {
    struct sESPMenu {
        bool Enemies;
        bool Line;
        bool Box;
        bool Skeleton;
        bool Health;
        bool Name;
        bool Distance;
        bool TeamID;
        bool State;
        bool Weapon;
        bool Alert;
        bool HideBot;
        bool GrenadeWarning;
        float HealthColor[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
        float HealthColorHidden[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
    };
    sESPMenu ESPMenu{false};

    
};
sConfig Config{false};

struct JsonPreferences {
    
    int xsuit = 0;
    int skinm4 = 0;
    int skinakm = 0;
    int para = 0;
    int bag = 0;
    int helmet = 0;
    bool CoupeRB = true;
    bool Dacia = true;
    bool UAZ = true;
    bool MiniBus = true;
    bool BigFoot = true;
    bool Boat = true;
    bool Mirado = true;
    bool Buggy = true;
    bool OMirado = true;
    bool Moto = true;
    bool Emote = true;
    bool Helmett = true;
    bool Bagg = true;
    bool Face = true;
    bool Outfit = true;
    bool Parachute = true;
    bool M416 = true;
    bool AKM = true;
    bool SCARL = true;
    bool M762 = true;
    bool AWM = true;
    bool KAR98 = true;
    bool M24 = true;
    bool M16 = true;
    bool M249 = true;
    bool DP28 = true;
    bool GROZA = true;
    bool AUG = true;
    bool PAN = true;
    bool UZI = true;
    bool UMP = true;
    bool TOMMY = true;
    bool BIZON = true;
    bool ACE32 = true;
    bool VECTOR = true;

    struct sConfig {
        struct sAimMenu {
            bool AimBot;
            bool IgnoreKnocked;
            bool IgnoreBot;
            bool VisCheck;
            bool Prediction;
            bool InstantHit;
            bool Recoil;
            float RecoilRate = 1.0f;
            float Fov = 100;
        };
        sAimMenu SilentAim{false};

		struct sModSkin {
            bool Enable = 0;
            bool HitEffect = 0;
            bool KillMessage = 0;
            bool DeadBox = 0;
            int XSuits = 0;
            int AKM = 0;
            int M16A4 = 0;
            int Scar = 0;
            int M416 = 0;
            int Groza = 0;
            int AUG = 0;
            int QBZ = 0;
            int M762 = 0;
            int ACE32 = 0;
            int Parachute = 0;
            int UZI = 0;
            int UMP = 0;
            int Vector = 0;
            int Thompson = 0;
            int Bizon = 0;
            int K98 = 0;
            int M24 = 0;
            int AWM = 0;
            int DP28 = 0;
            int M249 = 0;
            int Pan = 0;
            int Moto = 0;
            int CoupeRP = 0;
            int UAZ = 0;
            int Dacia = 0;
            int Bigfoot = 0;
            int Mirado = 0;
            int OMirado = 0;
            int Buggy = 0;
            int MiniBus = 0;
            int Boat = 0;
        };
        sModSkin Skin{false};
        
    };
    sConfig Config{false};

} preferences;
static int helmett3 = 1;
static int bag3 = 1;
bool ModSkinn = false;
bool KillMessage = false;
bool DeadBox = false;
int sEmote1 = 2200101;
int sEmote2 = 2200201;
int sEmote3 = 2200301;
int ModEmote1 = 0;
namespace Active {
  inline int SkinCarDefault = 0;
  inline int SkinCarMod = 0;
  inline int SkinCarNew = 0;
}
UISlider * Auto1;
UISlider * Auto1Interval;
UISlider * sliderrr;
extern float TurnRate;
extern float NoScopeAimDisSliderVal;
extern float HiddenFOVSliderVal;
extern float NoScopeFOVSliderVal;

UISlider * aimspeed;
CGSize AutoFireCircelSize;
bool IsAirDrop = false;
int Interval = 1;
int counter;
int iAwareTexSiz = 20;
bool iAwareText = true;
int EspTextSiz = 9;
float EspBoxThik = 1.5f;
float EspSktonThik = 1.5f;
float IsfovSlider = 150.0f;
float AimSmooth = 5.0f;
float EspDistance = 250.0f;
bool AimTouch = false;
bool antibypass = false;
float AimBotDistance = 20.0f;

int boxtype = 1;
int healthbartype = 0;
int Nationtype = 2;
int DirectionLineSize = 70;
int VehicleDirectionLineSize = 100;
int offscreen_range = 40;
int max_distance_offscreen = 400;
int playersdistancessize = 600;
bool esp_Outline = true;
int distance_Radar = 150;

uintptr_t ProcessEvent_Offset,AimBullet_Offset,AimBullet_Offset2,SetControlRotation_Offset;
#define SLEEP_TIME 1000LL / 60LL
#define TORAD(x) ((x) * (M_PI / 180.f))
int g_screenWidth ;
int g_screenHeight ;
int screenWidth ;
int screenHeight ;
int screenDensity = 0;
int getEspFramerate;
int SCOLOR;
int scc;


char extra[30];
float density = -1;
float gDistance;
int localFiring{0};
BOOL kaiguan1 = NO;
BOOL kaiguan2 = NO;
BOOL kaiguan3 = NO;
BOOL kaiguan4 = NO;
#define PI 3.14159265358979323846
#define __fastcall
bool ARWP = false;
bool SMGWP =false;
bool SNPWP = false;
bool otherWP =false;
bool AmmoWP =false;
bool LIGHTMW = false;
bool SHOTGUNWP = false;
bool scopewp = false;
bool POSTOLWP = false;
bool ARMORWP =false;

bool IsRecoilComparison = false;

static int loaixe = 0;
static int xedacia = 0;
bool modxe = false;
bool tamnho = false;
bool effectm44 = false;
float dorong = 88.0f;

float aimspeedsl()
{
    float val1 = 20;
    return val1;
}
int aimpos()
{
    float speedVal = 25;
    return speedVal;
}
int autodiss()
{
    return Auto1.value;
}


NSString *resultx;
@implementation metalbiew
INI* config;
bool MenDeal;


- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}


- (void)loadView
{
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
}

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    
}

id<MTLTexture> CreateTextureFromMemory(id<MTLDevice> device, const void* data, size_t dataSize) {
    if (!data || dataSize <= 0) return nil;

    // 1. Chuyển mảng byte raw thành NSData
    NSData *nsData = [NSData dataWithBytes:data length:dataSize];
    if (!nsData) return nil;

    // 2. Sử dụng MTKTextureLoader để giải mã ảnh (PNG/JPG...)
    MTKTextureLoader *loader = [[MTKTextureLoader alloc] initWithDevice:device];
    
    NSError *error = nil;
    // Tùy chọn: SRGB = false để giữ đúng màu gốc
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    
    id<MTLTexture> texture = [loader newTextureWithData:nsData options:options error:&error];

    if (error) {
        NSLog(@"[Lỗi] Không thể load ảnh: %@", error.localizedDescription);
        return nil;
    }

    return texture;
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];

    NSFileManager *fileManager = [NSFileManager defaultManager];

    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"ENGINE.ini"];

    if(![fileManager fileExistsAtPath:filePath]){

        [fileManager createFileAtPath:filePath contents:[NSData data] attributes:nil];
    }

    config = ini_load((char*)filePath.UTF8String);
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    if (!self.device) abort();
    
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    ImGui::StyleColorsDark();

    // --- CẤU HÌNH BO TRÒN VÀ MÀU ĐEN TUYỀN ---
    ImGuiStyle& style = ImGui::GetStyle();
    
    // Bo tròn toàn bộ các thành phần
    style.WindowRounding = 15.0f;       // Bo tròn khung menu chính
    style.ChildRounding = 12.0f;        // Bo tròn các vùng nội dung con
    style.FrameRounding = 10.0f;        // Bo tròn các nút bấm, checkbox, ô nhập liệu
    style.PopupRounding = 10.0f;        // Bo tròn các thông báo popup
    style.ScrollbarRounding = 10.0f;    // Bo tròn thanh cuộn
    style.GrabRounding = 10.0f;         // Bo tròn các nút kéo slider
    
    // Chỉnh màu đen tuyền (Deep Black)
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);     // Nền menu chính
    style.Colors[ImGuiCol_ChildBg]  = ImVec4(0.05f, 0.05f, 0.05f, 0.50f);     // Nền các vùng con (đen nhạt hơn chút để tạo khối)
    style.Colors[ImGuiCol_Border]   = ImVec4(0.15f, 0.15f, 0.15f, 0.50f);     // Màu viền menu
    
    // Màu sắc các nút bấm và tương tác (Ví dụ giữ tông màu tím cho hợp với DUCK-IOS)
    style.Colors[ImGuiCol_Button]        = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.18f, 0.18f, 0.18f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive]  = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    
    // Màu Checkbox và Slider
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.60f, 0.00f, 0.80f, 1.00f);     // Dấu tích màu tím
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.50f, 0.00f, 0.70f, 1.00f);    // Nút kéo màu tím   

    ImFontConfig font_cfg;
    font_cfg.FontDataOwnedByAtlas = false;
    NSString *FontPath = @"/System/Library/Fonts/Core/AvenirNext.ttc";
    io.ConfigWindowsMoveFromTitleBarOnly = true;
    io.Fonts->AddFontFromFileTTF(FontPath.UTF8String, 15.0f, &font_cfg, io.Fonts->GetGlyphRangesVietnamese());

    ImGui::MergeIconsWithLatestFont(17.f, false);
    ImGui_ImplMetal_Init(_device);
    
    return self;
}

ImVec4 to_vec4(float r, float g, float b, float a)
    {
        return ImVec4(r / 255.0, g / 255.0, b / 255.0, a / 255.0);
    }
static auto start = std::chrono::steady_clock::now();
static auto noww = std::chrono::high_resolution_clock::now();
auto elapsedd = std::chrono::duration_cast<std::chrono::milliseconds>(noww - start).count();
namespace Settings
{
    static int Tab = 1;
}
namespace Setting
{
    static int Tabs = 1;
}
int newUAZID = 0;
int lastUAZID = 0;
int newDaciaID = 0;
int lastDaciaID = 0;
int newCoupeID = 0;
int lastCoupeID = 0;
struct snew_Skin {
    int XSuits = 403003;
    int XSuits1 = 40604002;
    int Balo1 = 501001;
    int Balo2 = 501002;
    int Balo3 = 501003;
    int Balo4 = 501004;
    int Balo5 = 501005;
    int Balo6 = 501006;
    int Helmet1 = 502001;
    int Helmet2 = 502002;
    int Helmet3 = 502003;
    int Helmet4 = 502004;
    int Helmet5 = 502005;

    int Helmet6 = 502114;
    int Helmet7 = 502115;
    int Helmet8 = 502116;
    int Parachute = 703001;

    int AKM = 101001;
    int AKM_Mag = 291001;
    int M16A4 = 101002;
    int M16A4_Stock = 205007;
    int M16A4_Mag = 291002;
    int Scar = 101003;
    int Scar_Mag = 291003;
    int Pan = 108004;

    int M416_1 = 101004;
    int M416_2 = 291004;
    int M416_3 = 203008;
    int M416_4 = 205005;
    int M416_flash = 201010;
    int M416_compe = 201009;
    int M416_silent = 201011;
    int M416_reddot = 203001;
    int M416_holo = 203001;
    int M416_x2 = 203003;
    int M416_x3 = 203014;
    int M416_x4 = 203004;
    int M416_x6 = 203015;
    int M416_quickMag = 204012;
    int M416_extendedMag = 204011;
    int M416_quickNextended = 204013;
    int M416_stock = 205002;
    int M416_verical = 203015;
    int M416_angle = 202001;
    int M416_lightgrip = 202004;
    int M416_pink = 202005;
    int M416_lazer = 202007;
    int M416_thumb = 202006;

    int Groza = 101005;
    int QBZ = 101007;
    int AUG = 101006;
    int M762 = 101008;
    int M762_Mag = 291008;
    int ACE32 = 101102;
    int Honey = 101012;
    int UZI = 102001;
    int UMP = 102002;
    int Vector = 102003;
    int Thompson = 102004;
    int Bizon = 102005;
    int K98 = 103001;
    int M24 = 103002;
    int AWM = 103003;
    int AMR = 103012;
    int VSS = 103005;
    int SKS = 103004;
    int Mini14 = 103006;
    int MK14 = 103007;
    int SLR = 103009;
    int S1897 = 104002;
    int DP28 = 105002;
    int M249 = 105001;
    int MG3 = 105010;
    int Skorpion = 106008;
    int Moto = 1901001;
    int CoupeRP = 1961001;
    int Dacia = 1903001;
    int UAZ = 1908001;
    int Bigfoot = 1953001;
    int Mirado = 1914004;
    int OMirado = 1915001;
    int Buggy = 1907001;
    int MiniBus = 1904001;
    int Boat = 1911001;
    int M249s = 205009;
};

inline snew_Skin new_Skin;



std::chrono::steady_clock::time_point lastChangeTime;
std::chrono::steady_clock::time_point lastWeaponChangeTime;

void updateSkin() {
    if (preferences.bag == 1)
    bag3 = 1501003174; //blood raven x suit
    if (preferences.bag == 2)
    bag3 = 1501003220; //Golden Pharaoh X-Suit
    if (preferences.bag == 3)
    bag3 = 1501003051; //Avalanche
    if (preferences.bag == 4)
    bag3 = 1501003443; //Irresidence
    if (preferences.bag == 5)
    bag3 = 1501003265; //Poseidon
    if (preferences.bag == 6)
    bag3 = 1501003321; //Arcane Jester X-suit
    if (preferences.bag == 7)
    bag3 = 1501003277; //Silvanus X-Suit
	if (preferences.bag == 8)
    bag3 = 1501003550;
	if (preferences.bag == 9)
    bag3 = 1501003550;
	if (preferences.xsuit == 10)
	bag3 = 0;
	if (preferences.xsuit == 11)
	bag3 = 0;
	if (preferences.xsuit == 12)//todo
	bag3 = 0;
	//Helmet
	if (preferences.helmet == 1)
    helmett3 = 1502003014; //blood raven x suit
    if (preferences.helmet == 2)
    helmett3 = 1502003028; //Golden Pharaoh X-Suit
    if (preferences.helmet == 3)
    helmett3 = 1502003023; //Avalanche
    if (preferences.helmet == 4)
    helmett3 = 1501002443; //Irresidence
    if (preferences.helmet == 5)
    helmett3 = 1502003031; //Poseidon
    if (preferences.helmet == 6)
    helmett3 = 1502003033; //Arcane Jester X-suit
    if (preferences.helmet == 7)
    helmett3 = 1502003069; //Silvanus X-Suit
	if (preferences.helmet == 8)
    helmett3 = 1502003069;
	if (preferences.helmet == 8)
    helmett3 = 1502003261;
	if (preferences.xsuit == 10)
	helmett3 = 0;
	if (preferences.xsuit == 11)
	helmett3 = 0;
	if (preferences.xsuit == 12)//todo
	helmett3 = 0;
					
    if (ModEmote1 == 0)
    sEmote1 = 2200101;
    if (ModEmote1 == 1)
    sEmote1 = 12220023;
    if (ModEmote1 == 2)
    sEmote1 = 12219677;
    if (ModEmote1 == 3)
    sEmote1 = 12219716;
    if (ModEmote1 == 4)
    sEmote1 = 12209401;
    if (ModEmote1 == 5)
    sEmote1 = 12209501;
    if (ModEmote1 == 6)
    sEmote1 = 12209701;
    if (ModEmote1 == 7)
    sEmote1 = 12209801;
    if (ModEmote1 == 8)
    sEmote1 = 12209901;


    if (ModEmote1 == 0)
    sEmote2 = 2200201;
    if (ModEmote1 == 1)
    sEmote2 = 12210201;
    if (ModEmote1 == 2)
    sEmote2 = 12210601;
    if (ModEmote1 == 3)
    sEmote2 = 12220028;
    if (ModEmote1 == 4)
    sEmote2 = 12219819;
    if (ModEmote1 == 5)
    sEmote2 = 12211801;
    if (ModEmote1 == 6)
    sEmote2 = 12212001;
    if (ModEmote1 == 7)
    sEmote2 = 12212201;
    if (ModEmote1 == 8)
    sEmote2 = 12212401;


    if (ModEmote1 == 0)
    sEmote3 = 2200301;
    if (ModEmote1 == 1)
    sEmote3 = 12212601;
    if (ModEmote1 == 2)
    sEmote3 = 12213201;
    if (ModEmote1 == 3)
    sEmote3 = 12219715;
    if (ModEmote1 == 4)
    sEmote3 = 12219814;
    if (ModEmote1 == 5)
    sEmote3 = 12213601;
    if (ModEmote1 == 6)
    sEmote3 = 12213801;
    if (ModEmote1 == 7)
    sEmote3 = 12214001;
    if (ModEmote1 == 8)
    sEmote3 = 12214201;



  if (preferences.Config.Skin.Parachute == 0)
    new_Skin.Parachute = 703001;
  if (preferences.Config.Skin.Parachute == 16)
    new_Skin.Parachute = 1401619; //Pharaoh's Scarab Parachute
  if (preferences.Config.Skin.Parachute == 1)
    new_Skin.Parachute = 1401619; //Pharaoh's Scarab Parachute
  if (preferences.Config.Skin.Parachute == 2)
    new_Skin.Parachute = 1401625; // Enigmatic Nomad Parachute
  if (preferences.Config.Skin.Parachute == 3)
    new_Skin.Parachute = 1401624; //parashot Parachute
  if (preferences.Config.Skin.Parachute == 4)
    new_Skin.Parachute = 1401836; //Paperfold Gambit Parachute
  if (preferences.Config.Skin.Parachute == 5)
    new_Skin.Parachute = 1401833; //Labyrinth Beast Parachute
  if (preferences.Config.Skin.Parachute == 6)
    new_Skin.Parachute = 1401287; //Flamewraith Parachute
  if (preferences.Config.Skin.Parachute == 7)
    new_Skin.Parachute = 1401282; //Mega Kitty Parachute
  if (preferences.Config.Skin.Parachute == 8)
    new_Skin.Parachute = 1401385; //Mega Yeti Parachute
  if (preferences.Config.Skin.Parachute == 9)
    new_Skin.Parachute = 1401549; //Endless Glory Parachute
  if (preferences.Config.Skin.Parachute == 10)
    new_Skin.Parachute = 1401336; //Magma Skull Parachute
  if (preferences.Config.Skin.Parachute == 11)
    new_Skin.Parachute = 1401335; //Aquatic Fury Parachute
  if (preferences.Config.Skin.Parachute == 12)
    new_Skin.Parachute = 1401629; //CyberGen: Zero Parachute
  if (preferences.Config.Skin.Parachute == 13)
    new_Skin.Parachute = 1401628; //Radiant Phoenix Adarna Parachute
  if (preferences.Config.Skin.Parachute == 14)
    new_Skin.Parachute = 1401615; //Will of Horus
  if (preferences.Config.Skin.Parachute == 15)
    new_Skin.Parachute = 1401613; //Anubian Magistrate Parachute

  if (preferences.Config.Skin.Pan == 0)
    new_Skin.Pan = 108004; // 108004 - Pan
  if (preferences.Config.Skin.Pan == 1)
    new_Skin.Pan = 1108004125; // Honeypot - Pan
  if (preferences.Config.Skin.Pan == 2)
    new_Skin.Pan = 1108004145; // Night of Rock - Pan
  if (preferences.Config.Skin.Pan == 3)
    new_Skin.Pan = 1108004160; // Crocodile - Pan
  if (preferences.Config.Skin.Pan == 4)
    new_Skin.Pan = 1108004283; // Accolade - Pan
  if (preferences.Config.Skin.Pan == 5)
    new_Skin.Pan = 1108004337; // Break Pad - Pan
  if (preferences.Config.Skin.Pan == 6)
    new_Skin.Pan = 1108004356; // Chicken Hot - Pan
  if (preferences.Config.Skin.Pan == 7)
    new_Skin.Pan = 1108004365; // Faerie Luster - Pan
  if (preferences.Config.Skin.Pan == 8)
    new_Skin.Pan = 1108004054; // Chicken Hot - Pan
  if (preferences.Config.Skin.Pan == 9)
    new_Skin.Pan = 1108004008; 
	
	
  if (preferences.Config.Skin.XSuits == 0) {
    new_Skin.XSuits = 403003;
    new_Skin.XSuits1 = 40604002;
  }
  if (preferences.Config.Skin.XSuits == 1) {
    new_Skin.XSuits = 1405628;
    new_Skin.XSuits1 = 1402578;
  }
  if (preferences.Config.Skin.XSuits == 2) {
    new_Skin.XSuits = 1405870;
    new_Skin.XSuits1 = 1403257;
  }
  if (preferences.Config.Skin.XSuits == 3) {
    new_Skin.XSuits = 1405983;
    new_Skin.XSuits1 = 1402874;
  }
  if (preferences.Config.Skin.XSuits == 4) {
    new_Skin.XSuits = 1406152;
    new_Skin.XSuits1 = 1403393;
  }
  if (preferences.Config.Skin.XSuits == 5) {
    new_Skin.XSuits = 1406311;
    new_Skin.XSuits1 = 1410011; //Mặt nạ 1.403.414
  }
  if (preferences.Config.Skin.XSuits == 6) {
    new_Skin.XSuits = 1406475;
    new_Skin.XSuits1 = 1410131;
  }
  if (preferences.Config.Skin.XSuits == 7) {
    new_Skin.XSuits = 1406638;
    new_Skin.XSuits1 = 1410242;
  }
  if (preferences.Config.Skin.XSuits == 8) {
    new_Skin.XSuits = 1406872;
    //new_Skin.XSuits1 = 1410346; // khung
    new_Skin.XSuits1 = 402133;
  }
  if (preferences.Config.Skin.XSuits == 9) {
    new_Skin.XSuits = 1406971;
    new_Skin.XSuits1 = 402147;
  }
  if (preferences.Config.Skin.XSuits == 10) {
    new_Skin.XSuits = 1407103;
    new_Skin.XSuits1 = 40604002;
  }
  if (preferences.Config.Skin.XSuits == 11) {
    new_Skin.XSuits = 1405174;
    new_Skin.XSuits1 = 40604012;
  }
  if (preferences.Config.Skin.XSuits == 12) {
    new_Skin.XSuits = 1407195;
  }
  if (preferences.Config.Skin.XSuits == 13) {
    new_Skin.XSuits = 1407194;
    new_Skin.XSuits1 = 1410436;
  }
if (preferences.Config.Skin.XSuits == 14) {
    new_Skin.XSuits = 1406891;
  }
  if (preferences.Config.Skin.XSuits == 15) {
    new_Skin.XSuits = 1400687;
  }
  if (preferences.Config.Skin.XSuits == 16) {
    new_Skin.XSuits = 1407196;
  }
  if (preferences.Config.Skin.XSuits == 17) {
    new_Skin.XSuits = 1407049;
  }
  if (preferences.Config.Skin.XSuits == 18) {
    new_Skin.XSuits = 1406897;
  }
  
  if (preferences.Config.Skin.XSuits == 19) {
    new_Skin.XSuits = 1406892;
  }
  if (preferences.Config.Skin.XSuits == 20) {
    new_Skin.XSuits = 1407049;
  }
  if (preferences.Config.Skin.XSuits == 21) {
    new_Skin.XSuits = 1407188;
  }
  
  

  if (preferences.Config.Skin.AKM == 0) {
    new_Skin.AKM = 101001;
    new_Skin.AKM_Mag = 205005;
  }
  if (preferences.Config.Skin.AKM == 1) {
    new_Skin.AKM = 1101001089;
    new_Skin.AKM_Mag = 1010010891;
  }
  if (preferences.Config.Skin.AKM == 2) {
    new_Skin.AKM = 1101001103;
    new_Skin.AKM_Mag = 1010011031;
  }
  if (preferences.Config.Skin.AKM == 3) {
    new_Skin.AKM = 1101001116;
    new_Skin.AKM_Mag = 1010011161;
  }
  if (preferences.Config.Skin.AKM == 4) {
    new_Skin.AKM = 1101001128;
    new_Skin.AKM_Mag = 1010011281;
  }
  if (preferences.Config.Skin.AKM == 5) {
    new_Skin.AKM = 1101001143;
    new_Skin.AKM_Mag = 1010011431;
  }
  if (preferences.Config.Skin.AKM == 6) {
    new_Skin.AKM = 1101001154;
    new_Skin.AKM_Mag = 1010011541;
  }
  if (preferences.Config.Skin.AKM == 7) {
    new_Skin.AKM = 1101001174;
    new_Skin.AKM_Mag = 1010011741;
  }
  if (preferences.Config.Skin.AKM == 8) {
    new_Skin.AKM = 1101001213;
    new_Skin.AKM_Mag = 1010012131;
  }
  if (preferences.Config.Skin.AKM == 9) {
    new_Skin.AKM = 1101001231;
    new_Skin.AKM_Mag = 1010012311;
  }
  if (preferences.Config.Skin.AKM == 10) {
    new_Skin.AKM = 1101001242;
    new_Skin.AKM_Mag = 1010012421;
  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if (preferences.Config.Skin.M16A4 == 0) {
    new_Skin.M16A4 = 101002;
    new_Skin.M16A4_Stock = 205007;
    new_Skin.M16A4_Mag = 291002;
  }
  if (preferences.Config.Skin.M16A4 == 1) {
    new_Skin.M16A4 = 1101002029;
    new_Skin.M16A4_Stock = 1010020292;
    new_Skin.M16A4_Mag = 1010020291;
  }
  if (preferences.Config.Skin.M16A4 == 2) {
    new_Skin.M16A4 = 1101002056;
    new_Skin.M16A4_Stock = 1010020562;
    new_Skin.M16A4_Mag = 1010020561;
  }
  if (preferences.Config.Skin.M16A4 == 3) {
    new_Skin.M16A4 = 1101002068;
    new_Skin.M16A4_Stock = 1010020682;
    new_Skin.M16A4_Mag = 1010020681;
  }
  if (preferences.Config.Skin.M16A4 == 4) {
    new_Skin.M16A4 = 1101002081;
    new_Skin.M16A4_Stock = 1010020812;
    new_Skin.M16A4_Mag = 1010020811;
  }
  if (preferences.Config.Skin.M16A4 == 5) {
    new_Skin.M16A4 = 1101002103;
    new_Skin.M16A4_Stock = 1010021032;
    new_Skin.M16A4_Mag = 1010021031;
  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if (preferences.Config.Skin.Scar == 0) {
    new_Skin.Scar = 101003;
    new_Skin.Scar_Mag = 291003;
  }
  if (preferences.Config.Skin.Scar == 1) {
    new_Skin.Scar = 1101003057;
    new_Skin.Scar_Mag = 1010030571;
  }
  if (preferences.Config.Skin.Scar == 2) {
    new_Skin.Scar = 1101003070;
    new_Skin.Scar_Mag = 1010030701;
  }
  if (preferences.Config.Skin.Scar == 3) {
    new_Skin.Scar = 1101003080;
    new_Skin.Scar_Mag = 1010030801;
  }
  if (preferences.Config.Skin.Scar == 4) {
    new_Skin.Scar = 1101003119;
    new_Skin.Scar_Mag = 1010031191;
  }
  if (preferences.Config.Skin.Scar == 5) {
    new_Skin.Scar = 1101003146;
    new_Skin.Scar_Mag = 1010031461;
  }
  if (preferences.Config.Skin.Scar == 6) {
    new_Skin.Scar = 1101003167;
    new_Skin.Scar_Mag = 1010031671;
  }
  if (preferences.Config.Skin.Scar == 7) {
    new_Skin.Scar = 1101003181;
    new_Skin.Scar_Mag = 1010031811;
  }
  ///////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if (preferences.Config.Skin.M416 == 0) {
    new_Skin.M416_1 = 101004;
    new_Skin.M416_2 = 291004;
    new_Skin.M416_3 = 203008;
    new_Skin.M416_4 = 205005;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 201009;
    new_Skin.M416_silent = 201011;
    new_Skin.M416_reddot = 203001;
    new_Skin.M416_holo = 203002;
    new_Skin.M416_x2 = 203003;
    new_Skin.M416_x3 = 203014;
    new_Skin.M416_x4 = 203004;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 204012;
    new_Skin.M416_extendedMag = 204011;
    new_Skin.M416_quickNextended = 204013;
    new_Skin.M416_stock = 205002;
    new_Skin.M416_verical = 203015;
    new_Skin.M416_angle = 202001;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 1) {
    new_Skin.M416_1 = 1101004046;
    new_Skin.M416_2 = 1010040461;
    new_Skin.M416_3 = 1010040462;
    new_Skin.M416_4 = 1010040463;
    new_Skin.M416_flash = 1010040474;
    new_Skin.M416_compe = 1010040475;
    new_Skin.M416_silent = 1010040476;
    new_Skin.M416_reddot = 1010040470;
    new_Skin.M416_holo = 1010040469;
    new_Skin.M416_x2 = 1010040468;
    new_Skin.M416_x3 = 1010040467;
    new_Skin.M416_x4 = 1010040466;
    new_Skin.M416_x6 = 1010040481;
    new_Skin.M416_quickMag = 1010040471;
    new_Skin.M416_extendedMag = 1010040472;
    new_Skin.M416_quickNextended = 1010040473;
    new_Skin.M416_stock = 1010040480;
    new_Skin.M416_verical = 1010040479;
    new_Skin.M416_thumb = 1010040478;
    new_Skin.M416_angle = 1010040477;
    new_Skin.M416_lightgrip = 1010040482;
    new_Skin.M416_pink = 1010040483;
    new_Skin.M416_lazer = 1010040484;
  }
  if (preferences.Config.Skin.M416 == 2) {
    new_Skin.M416_1 = 1101004062;
    new_Skin.M416_2 = 1010040611;
    new_Skin.M416_3 = 1010040612;
    new_Skin.M416_4 = 1010040613;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 201009;
    new_Skin.M416_silent = 201011;
    new_Skin.M416_reddot = 203001;
    new_Skin.M416_holo = 203002;
    new_Skin.M416_x2 = 203003;
    new_Skin.M416_x3 = 203014;
    new_Skin.M416_x4 = 203004;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 204012;
    new_Skin.M416_extendedMag = 204011;
    new_Skin.M416_quickNextended = 204013;
    new_Skin.M416_stock = 205002;
    new_Skin.M416_verical = 203015;
    new_Skin.M416_angle = 202001;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 3) {
    new_Skin.M416_1 = 1101004078;
    new_Skin.M416_2 = 1010040781;
    new_Skin.M416_3 = 1010040782;
    new_Skin.M416_4 = 1010040783;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 201009;
    new_Skin.M416_silent = 201011;
    new_Skin.M416_reddot = 203001;
    new_Skin.M416_holo = 203002;
    new_Skin.M416_x2 = 203003;
    new_Skin.M416_x3 = 203014;
    new_Skin.M416_x4 = 203004;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 204012;
    new_Skin.M416_extendedMag = 204011;
    new_Skin.M416_quickNextended = 204013;
    new_Skin.M416_stock = 205002;
    new_Skin.M416_verical = 203015;
    new_Skin.M416_angle = 202001;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 4) {
    new_Skin.M416_1 = 1101004086;
    new_Skin.M416_2 = 1010040861;
    new_Skin.M416_3 = 1010040862;
    new_Skin.M416_4 = 1010040863;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 201009;
    new_Skin.M416_silent = 201011;
    new_Skin.M416_reddot = 203001;
    new_Skin.M416_holo = 203002;
    new_Skin.M416_x2 = 203003;
    new_Skin.M416_x3 = 203014;
    new_Skin.M416_x4 = 203004;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 204012;
    new_Skin.M416_extendedMag = 204011;
    new_Skin.M416_quickNextended = 204013;
    new_Skin.M416_stock = 205002;
    new_Skin.M416_verical = 203015;
    new_Skin.M416_angle = 202001;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 5) {
    new_Skin.M416_1 = 1101004098;
    new_Skin.M416_2 = 1010040981;
    new_Skin.M416_3 = 1010040982;
    new_Skin.M416_4 = 1010040983;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 201009;
    new_Skin.M416_silent = 201011;
    new_Skin.M416_reddot = 203001;
    new_Skin.M416_holo = 203002;
    new_Skin.M416_x2 = 203003;
    new_Skin.M416_x3 = 203014;
    new_Skin.M416_x4 = 203004;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 204012;
    new_Skin.M416_extendedMag = 204011;
    new_Skin.M416_quickNextended = 204013;
    new_Skin.M416_stock = 205002;
    new_Skin.M416_verical = 203015;
    new_Skin.M416_angle = 202001;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 6) {
    new_Skin.M416_1 = 1101004138;
    new_Skin.M416_2 = 1010041381;
    new_Skin.M416_3 = 1010041382;
    new_Skin.M416_4 = 1010041383;
    new_Skin.M416_flash = 1010041136;
    new_Skin.M416_compe = 1010041137;
    new_Skin.M416_silent = 1010041138;
    new_Skin.M416_reddot = 1010041128;
    new_Skin.M416_holo = 1010041127;
    new_Skin.M416_x2 = 1010041126;
    new_Skin.M416_x3 = 1010041125;
    new_Skin.M416_x4 = 1010041124;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 1010041134;
    new_Skin.M416_extendedMag = 1010041129;
    new_Skin.M416_quickNextended = 1010041135;
    new_Skin.M416_stock = 1010041146;
    new_Skin.M416_verical = 1010041145;
    new_Skin.M416_angle = 1010041139;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 7) {
    new_Skin.M416_1 = 1101004163;
    new_Skin.M416_2 = 1010041631;
    new_Skin.M416_3 = 1010041632;
    new_Skin.M416_4 = 1010041633;
    new_Skin.M416_flash = 201010;
    new_Skin.M416_compe = 1010041574;
    new_Skin.M416_silent = 1010041575;
    new_Skin.M416_reddot = 1010041566;
    new_Skin.M416_holo = 1010041565;
    new_Skin.M416_x2 = 1010041564;
    new_Skin.M416_x3 = 1010041560;
    new_Skin.M416_x4 = 1010041554;
    new_Skin.M416_x6 = 203015;
    new_Skin.M416_quickMag = 1010041568;
    new_Skin.M416_extendedMag = 1010041569;
    new_Skin.M416_quickNextended = 1010041567;
    new_Skin.M416_stock = 1010041579;
    new_Skin.M416_verical = 1010041578;
    new_Skin.M416_angle = 1010041576;
    new_Skin.M416_lightgrip = 20200400;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 1010041577;
  }
  if (preferences.Config.Skin.M416 == 8) {
    new_Skin.M416_1 = 1101004201;
    new_Skin.M416_2 = 1010042011;
    new_Skin.M416_3 = 1010042012;
    new_Skin.M416_4 = 1010042013;
    new_Skin.M416_flash = 1010041956;
    new_Skin.M416_compe = 1010041957;
    new_Skin.M416_silent = 1010041958;
    new_Skin.M416_reddot = 1010041948;
    new_Skin.M416_holo = 1010041947;
    new_Skin.M416_x2 = 1010041946;
    new_Skin.M416_x3 = 1010041945;
    new_Skin.M416_x4 = 1010041944;
    new_Skin.M416_x6 = 1010041967;
    new_Skin.M416_quickMag = 1010041949;
    new_Skin.M416_extendedMag = 1010041950;
    new_Skin.M416_quickNextended = 1010041955;
    new_Skin.M416_stock = 1010041966;
    new_Skin.M416_verical = 1010041965;
    new_Skin.M416_angle = 1010041959;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 9) {
    new_Skin.M416_1 = 1101004209;
    new_Skin.M416_2 = 1010042073;
    new_Skin.M416_3 = 1010042083;
    new_Skin.M416_4 = 1010042093;
    new_Skin.M416_flash = 20101000;
    new_Skin.M416_compe = 1010042037;
    new_Skin.M416_silent = 1010042039;
    new_Skin.M416_reddot = 1010042029;
    new_Skin.M416_holo = 1010042028;
    new_Skin.M416_x2 = 1010042027;
    new_Skin.M416_x3 = 1010042026;
    new_Skin.M416_x4 = 1010042025;
    new_Skin.M416_x6 = 1010042024;
    new_Skin.M416_quickMag = 1010042034;
    new_Skin.M416_extendedMag = 1010042035;
    new_Skin.M416_quickNextended = 1010042036;
    new_Skin.M416_stock = 1010042047;
    new_Skin.M416_verical = 1010042046;
    new_Skin.M416_angle = 1010042044;
    new_Skin.M416_lightgrip = 202004;
    new_Skin.M416_pink = 202005;
    new_Skin.M416_lazer = 203015;
    new_Skin.M416_thumb = 202006;
  }
  if (preferences.Config.Skin.M416 == 10) {
    new_Skin.M416_1 = 1101004218;
    new_Skin.M416_2 = 1010042153;
    new_Skin.M416_3 = 1010042163;
    new_Skin.M416_4 = 1010042173;
    new_Skin.M416_flash = 1010042128;
    new_Skin.M416_compe = 1010042127;
    new_Skin.M416_silent = 1010042129;
    new_Skin.M416_reddot = 1010042119;
    new_Skin.M416_holo = 1010042118;
    new_Skin.M416_x2 = 1010042117;
    new_Skin.M416_x3 = 1010042116;
    new_Skin.M416_x4 = 1010042115;
    new_Skin.M416_x6 = 1010042114;
    new_Skin.M416_quickMag = 1010042124;
    new_Skin.M416_extendedMag = 1010042125;
    new_Skin.M416_quickNextended = 1010042126;
    new_Skin.M416_stock = 1010042137;
    new_Skin.M416_verical = 1010042136;
    new_Skin.M416_angle = 1010042134;
    new_Skin.M416_lightgrip = 1010042138;
    new_Skin.M416_pink = 1010042139;
    new_Skin.M416_lazer = 1010042144;
    new_Skin.M416_thumb = 1010042135;
  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.Groza == 0) {
    new_Skin.Groza = 101005;
  }
  if (preferences.Config.Skin.Groza == 1) {
    new_Skin.Groza = 1101005019;
  }
  if (preferences.Config.Skin.Groza == 2) {
    new_Skin.Groza = 1101005025;
  }
  if (preferences.Config.Skin.Groza == 3) {
    new_Skin.Groza = 1101005038;
  }
  if (preferences.Config.Skin.Groza == 4) {
    new_Skin.Groza = 1101005043;
  }
  if (preferences.Config.Skin.Groza == 5) {
    new_Skin.Groza = 1101005052;
  }
  if (preferences.Config.Skin.Groza == 6) {
    new_Skin.Groza = 1101005082;
  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.AUG == 0)
    new_Skin.AUG = 101006;
  if (preferences.Config.Skin.AUG == 1)
    new_Skin.AUG = 1101006033;
  if (preferences.Config.Skin.AUG == 2)
    new_Skin.AUG = 1101006044;
  if (preferences.Config.Skin.AUG == 3)
    new_Skin.AUG = 1101006062;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.QBZ == 0)
    new_Skin.QBZ = 101007;
  if (preferences.Config.Skin.QBZ == 1)
    new_Skin.QBZ = 1101007025;
  if (preferences.Config.Skin.QBZ == 2)
    new_Skin.QBZ = 1101007036;
  if (preferences.Config.Skin.QBZ == 3)
    new_Skin.QBZ = 1101007046;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.M762 == 0) {
    new_Skin.M762 = 101008;
    new_Skin.M762_Mag = 291008;
  }
  if (preferences.Config.Skin.M762 == 1) {
    new_Skin.M762 = 1101008026;
    new_Skin.M762_Mag = 1010080261;
  }
  if (preferences.Config.Skin.M762 == 2) {
    new_Skin.M762 = 1101008051;
    new_Skin.M762_Mag = 1010080511;
  }
  if (preferences.Config.Skin.M762 == 3) {
    new_Skin.M762 = 1101008061;
    new_Skin.M762_Mag = 1010080611;
  }
  if (preferences.Config.Skin.M762 == 4) {
    new_Skin.M762 = 1101008081;
    new_Skin.M762_Mag = 1010080811;
  }
  if (preferences.Config.Skin.M762 == 5) {
    new_Skin.M762 = 1101008104;
    new_Skin.M762_Mag = 1010081041;
  }
  if (preferences.Config.Skin.M762 == 6) {
    new_Skin.M762 = 1101008116;
    new_Skin.M762_Mag = 1010081161;
  }
  if (preferences.Config.Skin.M762 == 7) {
    new_Skin.M762 = 1101008126;
    new_Skin.M762_Mag = 1010081261;
  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.ACE32 == 0)
    new_Skin.ACE32 = 101102;
  if (preferences.Config.Skin.ACE32 == 1)
    new_Skin.ACE32 = 1101102007;
  if (preferences.Config.Skin.ACE32 == 2)
    new_Skin.ACE32 = 1101102017;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.UZI == 0)
    new_Skin.UZI = 102001;
  if (preferences.Config.Skin.UZI == 1)
    new_Skin.UZI = 1102001024;
  if (preferences.Config.Skin.UZI == 2)
    new_Skin.UZI = 1102001036;
  if (preferences.Config.Skin.UZI == 3)
    new_Skin.UZI = 1102001058;
  if (preferences.Config.Skin.UZI == 4)
    new_Skin.UZI = 1102001069;
  if (preferences.Config.Skin.UZI == 5)
    new_Skin.UZI = 1102001089;
  if (preferences.Config.Skin.UZI == 6)
    new_Skin.UZI = 1102001102;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.UMP == 0)
    new_Skin.UMP = 102002;
  if (preferences.Config.Skin.UMP == 1)
    new_Skin.UMP = 1102002043;
  if (preferences.Config.Skin.UMP == 2)
    new_Skin.UMP = 1102002061;
  if (preferences.Config.Skin.UMP == 3)
    new_Skin.UMP = 1102002090;
  if (preferences.Config.Skin.UMP == 4)
    new_Skin.UMP = 1102002117;
  if (preferences.Config.Skin.UMP == 5)
    new_Skin.UMP = 1102002124;
  if (preferences.Config.Skin.UMP == 6)
    new_Skin.UMP = 1102002129;
  if (preferences.Config.Skin.UMP == 7)
    new_Skin.UMP = 1102002136;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.Vector == 0)
    new_Skin.Vector = 102003;
  if (preferences.Config.Skin.Vector == 1)
    new_Skin.Vector = 1102003020;
  if (preferences.Config.Skin.Vector == 2)
    new_Skin.Vector = 1102003031;
  if (preferences.Config.Skin.Vector == 3)
    new_Skin.Vector = 1102003065;
  if (preferences.Config.Skin.Vector == 4)
    new_Skin.Vector = 1102003080;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.Thompson == 0)
    new_Skin.Thompson = 102004;
  if (preferences.Config.Skin.Thompson == 1)
    new_Skin.Thompson = 1102004018;
  if (preferences.Config.Skin.Thompson == 2)
    new_Skin.Thompson = 1102004034;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.Bizon == 0)
    new_Skin.Bizon = 102005;
  if (preferences.Config.Skin.Bizon == 1)
    new_Skin.Bizon = 1102005007;
  if (preferences.Config.Skin.Bizon == 2)
    new_Skin.Bizon = 1102005020;
  if (preferences.Config.Skin.Bizon == 3)
    new_Skin.Bizon = 1102005041;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.K98 == 0)
    new_Skin.K98 = 103001;
  if (preferences.Config.Skin.K98 == 1)
    new_Skin.K98 = 1103001060;
  if (preferences.Config.Skin.K98 == 2)
    new_Skin.K98 = 1103001079;
  if (preferences.Config.Skin.K98 == 3)
    new_Skin.K98 = 1103001101;
  if (preferences.Config.Skin.K98 == 4)
    new_Skin.K98 = 1103001145;
  if (preferences.Config.Skin.K98 == 5)
    new_Skin.K98 = 1103001160;
  if (preferences.Config.Skin.K98 == 6)
    new_Skin.K98 = 1103001179;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (new_Skin.M24 == 0)
    new_Skin.M24 = 103002;
  if (preferences.Config.Skin.M24 == 1)
    new_Skin.M24 = 1103002018;
  if (preferences.Config.Skin.M24 == 2)
    new_Skin.M24 = 1103002030;
  if (preferences.Config.Skin.M24 == 3)
    new_Skin.M24 = 1103002048;
  if (preferences.Config.Skin.M24 == 4)
    new_Skin.M24 = 1103002056;
  if (preferences.Config.Skin.M24 == 5)
    new_Skin.M24 = 1103002087;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.AWM == 0)
    new_Skin.AWM = 103003;
  if (preferences.Config.Skin.AWM == 1)
    new_Skin.AWM = 1103003022;
  if (preferences.Config.Skin.AWM == 2)
    new_Skin.AWM = 1103003030;
  if (preferences.Config.Skin.AWM == 3)
    new_Skin.AWM = 1103003042;
  if (preferences.Config.Skin.AWM == 4)
    new_Skin.AWM = 1103003051;
  if (preferences.Config.Skin.AWM == 5)
    new_Skin.AWM = 1103003062;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (preferences.Config.Skin.DP28 == 0)
    new_Skin.DP28 = 105002;
  if (preferences.Config.Skin.DP28 == 1)
    new_Skin.DP28 = 1105002018;
  if (preferences.Config.Skin.DP28 == 2)
    new_Skin.DP28 = 1105002035;
  if (preferences.Config.Skin.DP28 == 3)
    new_Skin.DP28 = 1105002058;
  if (preferences.Config.Skin.DP28 == 4)
    new_Skin.DP28 = 1105002063;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if (new_Skin.M249 == 0)
    new_Skin.M249 = 105001;
	new_Skin.M249s = 205009;
  if (preferences.Config.Skin.M249 == 1)
    new_Skin.M249 = 1105001020;
	new_Skin.M249s = 1050010351;
  if (preferences.Config.Skin.M249 == 2)
    new_Skin.M249 = 1105001034;
	new_Skin.M249s = 1050010412;
  if (preferences.Config.Skin.M249 == 3)
    new_Skin.M249 = 1105001048;
	new_Skin.M249s = 1050010482;
  if (preferences.Config.Skin.M249 == 4)
    new_Skin.M249 = 1105001054;
	new_Skin.M249s = 1050010542;
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   if (preferences.Config.Skin.Bigfoot == 0)
    new_Skin.Bigfoot = 1953001;
  if (preferences.Config.Skin.Bigfoot == 1)
    new_Skin.Bigfoot = 1953004;
	
  if (preferences.Config.Skin.OMirado == 0)
    new_Skin.OMirado = 1915001;
  if (preferences.Config.Skin.OMirado == 1)
    new_Skin.OMirado = 1915011;
  if (preferences.Config.Skin.OMirado == 2)
    new_Skin.OMirado = 1915099;
	
  if (preferences.Config.Skin.Mirado == 0)
    new_Skin.Mirado = 1914001;
  if (preferences.Config.Skin.Mirado == 1)
    new_Skin.Mirado = 1914011;
	
  if (preferences.Config.Skin.Moto == 0)
    new_Skin.Moto = 1901001;
  if (preferences.Config.Skin.Moto == 1)
    new_Skin.Moto = 1901073;
  if (preferences.Config.Skin.Moto == 2)
    new_Skin.Moto = 1901074;
  if (preferences.Config.Skin.Moto == 3)
    new_Skin.Moto = 1901075;
  if (preferences.Config.Skin.Moto == 4)
    new_Skin.Moto = 1901047;
  if (preferences.Config.Skin.Moto == 5)
    new_Skin.Moto = 1901085;
  if (preferences.Config.Skin.Moto == 6)
    new_Skin.Moto = 1901076;
  if (preferences.Config.Skin.Moto == 7)
    new_Skin.Moto = 1901027;
  if (preferences.Config.Skin.Moto == 8)
    new_Skin.Moto = 1901018;
  if (preferences.Config.Skin.Moto == 9)
    new_Skin.Moto = 1901085;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if (preferences.Config.Skin.Buggy == 0)
    new_Skin.Buggy = 1907001;
  if (preferences.Config.Skin.Buggy == 1)
    new_Skin.Buggy = 1907047;
  if (preferences.Config.Skin.Buggy == 2)
    new_Skin.Buggy = 1907009;
if (preferences.Config.Skin.Buggy == 3)
    new_Skin.Buggy = 1907010;
if (preferences.Config.Skin.Buggy == 4)
    new_Skin.Buggy = 1907011;
if (preferences.Config.Skin.Buggy == 5)
    new_Skin.Buggy = 1907012;
if (preferences.Config.Skin.Buggy == 6)
    new_Skin.Buggy = 1907013;
if (preferences.Config.Skin.Buggy == 7)
    new_Skin.Buggy = 1907014;
if (preferences.Config.Skin.Buggy == 8)
    new_Skin.Buggy = 1907015;
if (preferences.Config.Skin.Buggy == 9)
    new_Skin.Buggy = 1907016;
if (preferences.Config.Skin.Buggy == 10)
    new_Skin.Buggy = 1907017;
if (preferences.Config.Skin.Buggy == 11)
    new_Skin.Buggy = 1907018;
if (preferences.Config.Skin.Buggy == 12)
    new_Skin.Buggy = 1907019;
if (preferences.Config.Skin.Buggy == 13)
    new_Skin.Buggy = 1907020;
if (preferences.Config.Skin.Buggy == 14)
    new_Skin.Buggy = 1907021;
if (preferences.Config.Skin.Buggy == 15)
    new_Skin.Buggy = 1907022;
if (preferences.Config.Skin.Buggy == 16)
    new_Skin.Buggy = 1907023;
if (preferences.Config.Skin.Buggy == 17)
    new_Skin.Buggy = 1907024;
if (preferences.Config.Skin.Buggy == 18)
    new_Skin.Buggy = 1907025;
if (preferences.Config.Skin.Buggy == 19)
    new_Skin.Buggy = 1907026;
if (preferences.Config.Skin.Buggy == 20)
    new_Skin.Buggy = 1907027;
if (preferences.Config.Skin.Buggy == 21)
    new_Skin.Buggy = 1907028;
if (preferences.Config.Skin.Buggy == 22)
    new_Skin.Buggy = 1907029;
if (preferences.Config.Skin.Buggy == 23)
    new_Skin.Buggy = 1907030;
if (preferences.Config.Skin.Buggy == 24)
    new_Skin.Buggy = 1907031;
if (preferences.Config.Skin.Buggy == 25)
    new_Skin.Buggy = 1907032;
if (preferences.Config.Skin.Buggy == 26)
    new_Skin.Buggy = 1907033;
if (preferences.Config.Skin.Buggy == 27)
    new_Skin.Buggy = 1907034;
if (preferences.Config.Skin.Buggy == 28)
    new_Skin.Buggy = 1907035;
if (preferences.Config.Skin.Buggy == 29)
    new_Skin.Buggy = 1907036;
if (preferences.Config.Skin.Buggy == 30)
    new_Skin.Buggy = 1907037;
if (preferences.Config.Skin.Buggy == 31)
    new_Skin.Buggy = 1907038;
if (preferences.Config.Skin.Buggy == 32)
    new_Skin.Buggy = 1907039;
if (preferences.Config.Skin.Buggy == 33)
    new_Skin.Buggy = 1907040;
	
  if (preferences.Config.Skin.Dacia == 0)
    new_Skin.Dacia = 1903001;
  if (preferences.Config.Skin.Dacia == 1)
    new_Skin.Dacia = 1903076;
  if (preferences.Config.Skin.Dacia == 2)
    new_Skin.Dacia = 1903079;
  if (preferences.Config.Skin.Dacia == 3)
    new_Skin.Dacia = 1903071;
  if (preferences.Config.Skin.Dacia == 4)
    new_Skin.Dacia = 1903014;
  if (preferences.Config.Skin.Dacia == 5)
    new_Skin.Dacia = 1903017;
  if (preferences.Config.Skin.Dacia == 6)
    new_Skin.Dacia = 1903035;
  if (preferences.Config.Skin.Dacia == 7)
    new_Skin.Dacia = 1903087;
  if (preferences.Config.Skin.Dacia == 8)
    new_Skin.Dacia = 1903088;
  if (preferences.Config.Skin.Dacia == 9)
    new_Skin.Dacia = 1903089;
  if (preferences.Config.Skin.Dacia == 10)
    new_Skin.Dacia = 1903090;
  if (preferences.Config.Skin.Dacia == 11)
    new_Skin.Dacia = 1903074;
  if (preferences.Config.Skin.Dacia == 12)
    new_Skin.Dacia = 1903075;
  if (preferences.Config.Skin.Dacia == 13)
    new_Skin.Dacia = 1903072;
  if (preferences.Config.Skin.Dacia == 14)
    new_Skin.Dacia = 1903073;
  if (preferences.Config.Skin.Dacia == 15)
    new_Skin.Dacia = 1903080;
  if (preferences.Config.Skin.Dacia == 16)
    new_Skin.Dacia = 1903189;
  if (preferences.Config.Skin.Dacia == 17)
    new_Skin.Dacia = 1903190;
  if (preferences.Config.Skin.Dacia == 18)
    new_Skin.Dacia = 1903191;
  if (preferences.Config.Skin.Dacia == 19)
    new_Skin.Dacia = 1903192;
  if (preferences.Config.Skin.Dacia == 20)
    new_Skin.Dacia = 1903193;
  if (preferences.Config.Skin.Dacia == 21)
    new_Skin.Dacia = 1903197;
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  
if (preferences.Config.Skin.MiniBus == 0)
    new_Skin.MiniBus = 1904001;
  if (preferences.Config.Skin.MiniBus == 1)
    new_Skin.MiniBus = 1904005;
  if (preferences.Config.Skin.MiniBus == 2)
    new_Skin.MiniBus = 1904006;
if (preferences.Config.Skin.MiniBus == 3)
    new_Skin.MiniBus = 1904007;
if (preferences.Config.Skin.MiniBus == 4)
    new_Skin.MiniBus = 1904008;
if (preferences.Config.Skin.MiniBus == 5)
    new_Skin.MiniBus = 1904009;
if (preferences.Config.Skin.MiniBus == 6)
    new_Skin.MiniBus = 1904010;
if (preferences.Config.Skin.MiniBus == 7)
    new_Skin.MiniBus = 1904011;
if (preferences.Config.Skin.MiniBus == 8)
    new_Skin.MiniBus = 1904012;
if (preferences.Config.Skin.MiniBus == 9)
    new_Skin.MiniBus = 1904013;
if (preferences.Config.Skin.MiniBus == 10)
    new_Skin.MiniBus = 1904014;
if (preferences.Config.Skin.MiniBus == 11)
    new_Skin.MiniBus = 1904015;
if (preferences.Config.Skin.MiniBus == 12)
    new_Skin.MiniBus = 1904004;
  
  if (preferences.Config.Skin.CoupeRP == 0)
    new_Skin.CoupeRP = 1961001;
  if (preferences.Config.Skin.CoupeRP == 1)
    new_Skin.CoupeRP = 1961024;
  if (preferences.Config.Skin.CoupeRP == 2)
    new_Skin.CoupeRP = 1961047;
  if (preferences.Config.Skin.CoupeRP == 3)
    new_Skin.CoupeRP = 1961034;
  if (preferences.Config.Skin.CoupeRP == 4)
    new_Skin.CoupeRP = 1961018;
  if (preferences.Config.Skin.CoupeRP == 5)
    new_Skin.CoupeRP = 1961007;
  if (preferences.Config.Skin.CoupeRP == 6)
    new_Skin.CoupeRP = 1961010;
  if (preferences.Config.Skin.CoupeRP == 7)
    new_Skin.CoupeRP = 1961049;
  if (preferences.Config.Skin.CoupeRP == 8)
    new_Skin.CoupeRP = 1961048;
  if (preferences.Config.Skin.CoupeRP == 9)
    new_Skin.CoupeRP = 1961012;
  if (preferences.Config.Skin.CoupeRP == 10)
    new_Skin.CoupeRP = 1961013;
  if (preferences.Config.Skin.CoupeRP == 11)
    new_Skin.CoupeRP = 1961014;
  if (preferences.Config.Skin.CoupeRP == 12)
    new_Skin.CoupeRP = 1961015;
  if (preferences.Config.Skin.CoupeRP == 13)
    new_Skin.CoupeRP = 1961016;
  if (preferences.Config.Skin.CoupeRP == 14)
    new_Skin.CoupeRP = 1961017;
  if (preferences.Config.Skin.CoupeRP == 15)
    new_Skin.CoupeRP = 1961020;
  if (preferences.Config.Skin.CoupeRP == 16)
    new_Skin.CoupeRP = 1961021;
  if (preferences.Config.Skin.CoupeRP == 17)
    new_Skin.CoupeRP = 1961025;
  if (preferences.Config.Skin.CoupeRP == 18)
    new_Skin.CoupeRP = 1961029;
  if (preferences.Config.Skin.CoupeRP == 19)
    new_Skin.CoupeRP = 1961030;
  if (preferences.Config.Skin.CoupeRP == 20)
    new_Skin.CoupeRP = 1961031;
  if (preferences.Config.Skin.CoupeRP == 21)
    new_Skin.CoupeRP = 1961032;
  if (preferences.Config.Skin.CoupeRP == 22)
    new_Skin.CoupeRP = 1961033;
  if (preferences.Config.Skin.CoupeRP == 23)
    new_Skin.CoupeRP = 1961035;
  if (preferences.Config.Skin.CoupeRP == 24)
    new_Skin.CoupeRP = 1961036;
  if (preferences.Config.Skin.CoupeRP == 22)
    new_Skin.CoupeRP = 1961037;
  if (preferences.Config.Skin.CoupeRP == 26)
    new_Skin.CoupeRP = 1961038;
  if (preferences.Config.Skin.CoupeRP == 27)
    new_Skin.CoupeRP = 1961039;
  if (preferences.Config.Skin.CoupeRP == 28)
    new_Skin.CoupeRP = 1961040;
  if (preferences.Config.Skin.CoupeRP == 29)
    new_Skin.CoupeRP = 1961041;
  if (preferences.Config.Skin.CoupeRP == 30)
    new_Skin.CoupeRP = 1961042;
  if (preferences.Config.Skin.CoupeRP == 31)
    new_Skin.CoupeRP = 1961043;
  if (preferences.Config.Skin.CoupeRP == 32)
    new_Skin.CoupeRP = 1961044;
  if (preferences.Config.Skin.CoupeRP == 33)
    new_Skin.CoupeRP = 1961045;
  if (preferences.Config.Skin.CoupeRP == 34)
    new_Skin.CoupeRP = 1961046;
  if (preferences.Config.Skin.CoupeRP == 35)
    new_Skin.CoupeRP = 1961050;
  if (preferences.Config.Skin.CoupeRP == 36)
    new_Skin.CoupeRP = 1961051;
  if (preferences.Config.Skin.CoupeRP == 37)
    new_Skin.CoupeRP = 1961052;
  if (preferences.Config.Skin.CoupeRP == 38)
    new_Skin.CoupeRP = 1961053;
  if (preferences.Config.Skin.CoupeRP == 39)
    new_Skin.CoupeRP = 1961054;
  if (preferences.Config.Skin.CoupeRP == 40)
    new_Skin.CoupeRP = 1961055;
  if (preferences.Config.Skin.CoupeRP == 41)
    new_Skin.CoupeRP = 1961056;
  if (preferences.Config.Skin.CoupeRP == 42)
    new_Skin.CoupeRP = 1961057;

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if (preferences.Config.Skin.UAZ == 0)
    new_Skin.UAZ = 1908001;
  if (preferences.Config.Skin.UAZ == 1)
    new_Skin.UAZ = 1908067;
  if (preferences.Config.Skin.UAZ == 2)
    new_Skin.UAZ = 1908061;
  if (preferences.Config.Skin.UAZ == 3)
    new_Skin.UAZ = 1908032;
  if (preferences.Config.Skin.UAZ == 4)
    new_Skin.UAZ = 1908068;
  if (preferences.Config.Skin.UAZ == 5)
    new_Skin.UAZ = 1908066;
  if (preferences.Config.Skin.UAZ == 6)
    new_Skin.UAZ = 1908075;
  if (preferences.Config.Skin.UAZ == 7)
    new_Skin.UAZ = 1908076;
  if (preferences.Config.Skin.UAZ == 8)
    new_Skin.UAZ = 1908077;
  if (preferences.Config.Skin.UAZ == 9)
    new_Skin.UAZ = 1908078;
  if (preferences.Config.Skin.UAZ == 10)
    new_Skin.UAZ = 1908084;
  if (preferences.Config.Skin.UAZ == 11)
    new_Skin.UAZ = 1908085;
  if (preferences.Config.Skin.UAZ == 12)
    new_Skin.UAZ = 1908086;
  if (preferences.Config.Skin.UAZ == 13)
    new_Skin.UAZ = 1908088;
  if (preferences.Config.Skin.UAZ == 14)
    new_Skin.UAZ = 1908089;
  if (preferences.Config.Skin.UAZ == 15)
    new_Skin.UAZ = 1908188;
  if (preferences.Config.Skin.UAZ == 16)
    new_Skin.UAZ = 1908189;
  if (preferences.Config.Skin.UAZ == 17)
    new_Skin.UAZ = 1957001;
 
 if (preferences.Config.Skin.Boat == 0)
    new_Skin.Boat = 1911001;
  if (preferences.Config.Skin.Boat == 1)
    new_Skin.Boat = 1911013;
  if (preferences.Config.Skin.Boat == 2)
    new_Skin.Boat = 1911003;
if (preferences.Config.Skin.Boat == 3)
    new_Skin.Boat = 1911004;
if (preferences.Config.Skin.Boat == 4)
    new_Skin.Boat = 1911005;
if (preferences.Config.Skin.Boat == 5)
    new_Skin.Boat = 1911006;
if (preferences.Config.Skin.Boat == 6)
    new_Skin.Boat = 1911007;
if (preferences.Config.Skin.Boat == 7)
    new_Skin.Boat = 1911008;
if (preferences.Config.Skin.Boat == 8)
    new_Skin.Boat = 1911009;
if (preferences.Config.Skin.Boat == 9)
    new_Skin.Boat = 1911010;
if (preferences.Config.Skin.Boat == 10)
    new_Skin.Boat = 1911011;
if (preferences.Config.Skin.Boat == 11)
    new_Skin.Boat = 1911012;

}



int m4v[] = { 101004, 1101004046, 1101004062, 1101004078, 1101004086, 1101004098, 1101004138, 1101004163,1101004201,1101004209,1101004218
};
int scar[] = { 101003, 1101003057, 1101003070, 1101003080, 1101003119, 1101003146, 1101003167, 1101003181};
int akmv[] = { 101001,1101001089, 1101001103, 1101001116, 1101001128, 1101001143, 1101001154, 1101001174,1101001213,1101001231,1101001242
};
int m7[] = { 101008, 1101008026, 1101008051, 1101008061, 1101008081, 1101008104, 1101008116, 1101008126};
int awm[] = { 103003, 1103003022, 1103003030, 1103003042, 1103003051, 1103003062};
int kar[] = { 103001, 1103001060, 1103001079, 1103001101, 1103001145, 1103001160, 1103001179};
int m24[] = { 103002, 1103002018, 1103002030, 1103002048, 1103002056, 1103002087};
int dp[] = { 105002, 1105002018, 1105002035, 1105002058, 1105002063};
int m249[] = { 105001, 1105001020, 1105001034, 1105001048, 1105001054};
int groza[] = { 101005, 1101005019, 1101005025, 1101005038, 1101005043, 1101005052, 1101005082};
int aug[] = { 101006, 1101006033, 1101006044, 1101006062};
int m16[] = { 101002, 1101002029, 1101002056, 1101002068, 1101002081, 1101002103};
int uzi[] = { 102001, 1102001024, 1102001036, 1102001058, 1102001069, 1102001089, 1102001102};
int ump[] = { 102002, 1102002043, 1102002061, 1102002090, 1102002117, 1102002124, 1102002129, 1102002136};
int vectorr[] = { 102003, 1102003020, 1102003031, 1102003065, 1102003080};
int tommy[] = { 102004, 1102004018, 1102004034};
int bizon[] = { 102005, 1102005007, 1102005020, 1102005041};
int ace32[] = { 101102, 1101102007, 1101102017};
int pan[] = { 108004, 1108004125, 1108004145, 1108004160, 1108004283, 1108004337, 1108004356, 1108004365, 1108004054, 1108004008};

int m249s[] = { 205009, 1050010351, 1050010412, 1050010482, 1050010542};
int akmmag[] = { 291001,204013,204011,204012,1010010891, 1010011031, 1010011161, 1010011281, 1010011431, 1010011541, 1010011741,1010012131,1010012311,1010012421
};
int m7mag[] = { 291008,204013,204011,204012,1010080261, 1010080511, 1010080611, 1010080811, 1010081041, 1010081161, 1010081261};
int scarmag[] = { 291003,204013,204011,204012,1010030571, 1010030701, 1010030801, 1010031191, 1010031461, 1010031671, 1010031811};
int m4mag[] = { 291004,204013,204011,204012,1010040461,1010040611,1010040781,1010040861,1010040981,1010041381,1010041631,1010042011,1010042073,1010042153  };

int m4sight[] = { 203008,1010040462,1010040612,1010040782,1010040862,1010040982,1010041382,1010041632,1010042012,1010042083,1010042163  };

int m4stock[] = { 205005,1010040463,1010040613,1010040783,1010040863,1010040983,1010041383,1010041633,1010042013,1010042093,1010042173  };

int m4stock1[] = { 205002,1010040480,205002,205002,205002,205002,1010041146,1010041579,1010041966,1010042137,1010042173  };

int m4reddot[] = { 203001,1010040470,203001,203001,203001,203001,1010041128,1010041566,1010041948,1010042029,1010042119  };

int m16s[] = { 205007, 1010020292, 1010020562, 1010020682, 1010020812, 1010021032};
int m16mag[] = { 291002,204013,204011,204012, 1010020291, 1010020561, 1010020681, 1010020811, 1010021031};


int emote1[] = { 2200101,12220023,12219677,12219716,12209401,12220028,12209701,12209801,12209901 };
int emote2[] = { 2200201,12210201,12210601,12220028,12219819,12211801,12212001,12212201,12212401 };
int emote3[] = { 2200301,12212601,12213201,12219715,12219814,12213601,12213801,12214001,12214201 };

int SuitX[] = { 403003,1405628,1405870,1405983,1406152,1406311,1406475,1406638,1406872 };

int Bag[] = { 501006,501005,501004,501003,501002,501001,1501003550,1501003277,1501003321,1501003443,1501003265,1501003051,1501003220,1501003174 };

int Helmet[] = { 502001,502002,502003,1502003014,1502003028,1502003023,1501002443,1502003031,1502003033,1502003069,1502003261 };

static int prevXSuits = preferences.Config.Skin.XSuits;

static bool callFunction = false;
#pragma mark - MTKViewDelegate
namespace Variables {
    int ActiveTab = 1;
}

int aimbotIntensity = 2;
const char *aimbotIntensityText[] = {"Super Low","Low", "Medium", "High", "Super High", "Lock", "Super Lock"};
const char *aimbotTocDoText[] = {"Siêu Thấp","Thấp", "Trung Bình", "Cao", "Siêu Cao", "Khóa", "Siêu Khóa"};

bool callNotify = false;

bool isJailbroken() {
    //Rootfull
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"]) {
        return true;
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/bin/bash"]) {
        return true;
    }
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/etc/apt"]) {
        return true;
    }

    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"]) {
        return true;
    }

    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://package/Check.Packages"]]) {
        return true;
    }
    //Rootless
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb/usr/sbin/sshd"]) {
        return true;
    }

    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"]) {
        return true;
    }

    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"sileo://source/Check.Packages"]]) {
        return true;
    }
    return false;
}

- (void)drawInMTKView:(MTKView*)view
{

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    [self readIniConfig];

    #if TARGET_OS_OSX
    CGFloat framebufferScale = view.window.screen.backingScaleFactor ?: NSScreen.mainScreen.backingScaleFactor;
    #else
    CGFloat framebufferScale = view.window.screen.nativeScale;
    #endif
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    

    
    if (MenDeal == true) {
        [self.view setUserInteractionEnabled:YES];
    } else if (MenDeal == false) {
        [self.view setUserInteractionEnabled:NO];
    }
    
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil)
    {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@""];
        
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        
      
        
        CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
        CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 360) /2;

        ImGuiIO& Io = ImGui::GetIO();
        ImGui::SetNextWindowPos(ImVec2(Io.DisplaySize.x * 0.5f, Io.DisplaySize.y * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(480, 300), ImGuiCond_FirstUseEver);

if (MenDeal == true)
{
    // Kích thước menu nhỏ gọn (650x350)
    ImGui::SetNextWindowSize(ImVec2(650, 350), ImGuiCond_Always); 
    
    // Giao diện NoTitleBar (Không thanh tiêu đề ENGINE)
    ImGui::Begin("DUCK_MENU", &MenDeal, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);

    // =========================================================
    // CỘT 1: SIDEBAR ICON (BÊN TRÁI)
    // =========================================================
    ImGui::BeginGroup();
    ImVec2 iconBtnSize = ImVec2(45, 45); 
    
    if (ImGui::Button(ICON_FA_HOME, iconBtnSize)) Settings::Tab = 1;
    ImGui::Spacing();
    if (ImGui::Button(ICON_FA_EYE, iconBtnSize)) Settings::Tab = 2;
    ImGui::Spacing();
    if (ImGui::Button(ICON_FA_CROSSHAIRS, iconBtnSize)) Settings::Tab = 3;
    ImGui::Spacing();
    if (ImGui::Button(ICON_FA_BAN, iconBtnSize)) Settings::Tab = 4;
    ImGui::Spacing();
    if (ImGui::Button(ICON_FA_EDIT, iconBtnSize)) Settings::Tab = 5;
    ImGui::EndGroup();

    ImGui::SameLine();

    // =========================================================
    // CỘT 2: NỘI DUNG CHÍNH (Ở GIỮA)
    // =========================================================
    ImGui::BeginGroup();
    ImGui::BeginChild("MainContent", ImVec2(380, 0), false); 

    ImGui::Spacing();
    ImGui::SetWindowFontScale(1.2f);
    
    // --- THAY ĐỔI DÒNG CHỮ THEO TỪNG TAB ---
    if (Settings::Tab == 1) {
        ImGui::TextColored(ImVec4(1.0f, 0.84f, 0.0f, 1.0f), "CHÀO MỪNG NGƯỜI CHƠI, "); 
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "DUCK"); 
    } 
    else if (Settings::Tab == 2) {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "CÀI ĐẶT HIỂN THỊ - VISUAL"); 
    }
    else if (Settings::Tab == 3) {
        ImGui::TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), "HỖ TRỢ CHIẾN ĐẤU - AIMBOT"); 
    }
    else if (Settings::Tab == 4) {
        ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "CHỨC NĂNG HỆ THỐNG - MISC"); 
    }
    else if (Settings::Tab == 5) {
        ImGui::TextColored(ImVec4(1.0f, 0.5f, 1.0f, 1.0f), "KHO TRANG PHỤC - SKIN"); 
    }
    
    ImGui::SetWindowFontScale(1.0f);

    // --- NỘI DUNG CHI TIẾT TAB (GIỮ NGUYÊN LOGIC CỦA BẠN) ---
    if (Settings::Tab == 1) {
        std::string namedv = [[UIDevice currentDevice] name].UTF8String;
        NSDate *now = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"dd-MM-yyyy hh:mm:ss"];
        NSString *dateString = [dateFormatter stringFromDate:now];
        ImGui::Text("Thiết bị: %s", namedv.c_str());
        ImGui::Text("Trạng thái:");
        ImGui::SameLine();
        if (isJailbroken()) {
            ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "Jailbroken");
        } else {
            ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "No Jailbreak Or Hidden Jailbreak");
        }
        ImGui::Text("Thời gian: %s", [dateString UTF8String]);
        ImGui::Text("Tốc độ khung hình: %.1f FPS", ImGui::GetIO().Framerate);
        NSString *bundleIdentifier = [[NSBundle mainBundle] bundleIdentifier];
        if (bundleIdentifier) {
            ImGui::Text("Gói ứng dụng: %s", [bundleIdentifier UTF8String]);
        }
    }
    else if (Settings::Tab == 2) {
        if (ImGui::Checkbox(("Player"), &ESPPlayer)) {
            configManager::putBoolean(config, "playerSwitch", "esp", ESPPlayer);
        }

        if (ESPPlayer) {
            ImGui::Columns(2, NULL, false);

            if (ImGui::Checkbox(("Line"), &Config.ESPMenu.Line)) {
                configManager::putBoolean(config, "playerSwitch", "line", Config.ESPMenu.Line);
            }
            if (ImGui::Checkbox(("Health"), &Config.ESPMenu.Health)) {
                configManager::putBoolean(config, "playerSwitch", "health", Config.ESPMenu.Health);
            }
            if (ImGui::Checkbox(("Bone"), &Config.ESPMenu.Skeleton)) {
                configManager::putBoolean(config, "playerSwitch", "bone", Config.ESPMenu.Skeleton);
            }
            if (ImGui::Checkbox(("Team ID"), &Config.ESPMenu.TeamID)) {
                configManager::putBoolean(config, "playerSwitch", "teamid", Config.ESPMenu.TeamID);
            }
            if (ImGui::Checkbox(("Radar 360"), &Config.ESPMenu.Alert)) {
                configManager::putBoolean(config, "playerSwitch", "radar360", Config.ESPMenu.Alert);
            }

            ImGui::NextColumn();

            // --- CỘT 2 ---
            if (ImGui::Checkbox(("Box"), &Config.ESPMenu.Box)) {
                configManager::putBoolean(config, "playerSwitch", "box", Config.ESPMenu.Box);
            }
            if (ImGui::Checkbox(("Name"), &Config.ESPMenu.Name)) {
                configManager::putBoolean(config, "playerSwitch", "name", Config.ESPMenu.Name);
            }
            if (ImGui::Checkbox(("Distance"), &Config.ESPMenu.Distance)) {
                configManager::putBoolean(config, "playerSwitch", "distance", Config.ESPMenu.Distance);
            }
            if (ImGui::Checkbox(("Status"), &Config.ESPMenu.Weapon)) {
                configManager::putBoolean(config, "playerSwitch", "status", Config.ESPMenu.Weapon);
            }
            if (ImGui::Checkbox(("Ignore Bot"), &Config.ESPMenu.HideBot)) {
                configManager::putBoolean(config, "playerSwitch", "ignorebot", Config.ESPMenu.HideBot);
            }

            // Trở về chế độ 1 cột mặc định sau khi xong
            ImGui::Columns(1);
        }
    }
    else if (Settings::Tab == 3) {
        ImGui::Spacing();
        ImGui::TextColored(ImVec4(0, 1, 1, 1), ICON_FA_CROSSHAIRS " AIMBOT SETTINGS");

        if (ImGui::Checkbox("AIMBOT", &preferences.Config.SilentAim.AimBot)) {
            configManager::putBoolean(config, "SilentAim", "AimBot", preferences.Config.SilentAim.AimBot);
        }
        if (preferences.Config.SilentAim.AimBot) {
            ImGui::SameLine(175);
            if (ImGui::Checkbox("SHOW FOV", &ShowFov)) {
                configManager::putBoolean(config, "SilentAim", "ShowFov", ShowFov);
            }

            if (ImGui::Checkbox("IGNORE KNOCK", &preferences.Config.SilentAim.IgnoreKnocked)) {
                configManager::putBoolean(config, "SilentAim", "IgnoreKnocked", preferences.Config.SilentAim.IgnoreKnocked);
            }

            ImGui::SameLine(175);
            if (ImGui::Checkbox("IGNORE BOT", &preferences.Config.SilentAim.IgnoreBot)) {
                configManager::putBoolean(config, "SilentAim", "IgnoreBot", preferences.Config.SilentAim.IgnoreBot);
            }

            const char *chedoaimm[5] = {"AIM LOOK", "FIRE", "SCOPE", "FIRE + SCOPE", "AUTO AIM"};
            if (ImGui::Combo("MODE", &chedoaim, chedoaimm, IM_ARRAYSIZE(chedoaimm))) {
                configManager::putInteger(config, "SilentAim", "AimMode", chedoaim);
            }

            const char *targets[4] = {"HEAD", "NECK", "BODY", "BELLY"};
            if (ImGui::Combo("TARGET", &Istargets, targets, IM_ARRAYSIZE(targets))) {
                configManager::putInteger(config, "SilentAim", "AimTarget", Istargets);
            }
            const char* smoothList[] = { "SAFE", "SLOW", "MEDIUM", "FAST", "RICK" };
            
            if (ImGui::Combo("AIM SPEED", &smoothIndex, smoothList, IM_ARRAYSIZE(smoothList))) {

                switch (smoothIndex) {
                    case 0: AimBotSpeed = 15.0f; break;
                    case 1: AimBotSpeed = 10.0f;  break;
                    case 2: AimBotSpeed = 7.0f;  break;
                    case 3: AimBotSpeed = 3.0f;  break;
                    case 4: AimBotSpeed = 2.0f;  break;
                }

                configManager::putInteger(config, "SilentAim", "SmoothIndex", smoothIndex);
                configManager::putFloat(config, "SilentAim", "Smooth", AimBotSpeed);
            }
            if (ShowFov) {
                if (ImGui::SliderFloat("FOV", &preferences.Config.SilentAim.Fov, 0.0f, 500.0f, "%.0f")) {
                    configManager::putFloat(config, "SilentAim", "FovValue", preferences.Config.SilentAim.Fov);
                }
            }

            if (ImGui::SliderFloat("DISTANCE", &AimBotDistance, 0.0f, 300.0f, "%.0f")) {
                configManager::putFloat(config, "SilentAim", "Distance", AimBotDistance);
            }

            if (ImGui::SliderFloat("MACRO", &IsAimBotRecc, 0.0f, 3.0f, "%.1f")) {
                configManager::putFloat(config, "SilentAim", "Recoil", IsAimBotRecc);
            }
        }
    }
    else if (Settings::Tab == 4) {
        ImGui::Checkbox("iPad View", &WideView);
        if (WideView) {
            ImGui::SliderInt("TPP", &WideValue, 50, 150);
        }
    }
    else if (Settings::Tab == 5) {
        if (ImGui::Checkbox("Skin", &ModSkinn)) {
            configManager::putBoolean(config,"modSwitch", "skin", ModSkinn);
        }
        ImGui::SameLine();

        if (ImGui::Checkbox("Kill Message", &KillMessage)) {
            configManager::putBoolean(config,"modSwitch", "killmsg", KillMessage);
        }
        ImGui::SameLine();
        
        if (ImGui::Checkbox("Dead Box", &DeadBox)){
            configManager::putBoolean(config,"modSwitch", "deadbox", DeadBox);
        }

        if (ModSkinn || DeadBox || KillMessage) {
            const float buttonWidth = 135.5;
            ImGui::BeginGroup();
            if (ImGui::Button("Player", ImVec2(buttonWidth, 0)))
            Setting::Tabs = 1;
            ImGui::SameLine();
            ImGui::SetCursorPosX(ImGui::GetCursorPosX() + ImGui::GetStyle().ItemSpacing.x);
            if(ImGui::Button("Weapon", ImVec2(buttonWidth, 0)))
            Setting::Tabs = 2;
            ImGui::SameLine();
            ImGui::SetCursorPosX(ImGui::GetCursorPosX() + ImGui::GetStyle().ItemSpacing.x);
            if(ImGui::Button("Vehicle", ImVec2(buttonWidth, 0)))
            Setting::Tabs = 3;

            ImGui::EndGroup();

            if (Setting::Tabs == 1) {
                ImGui::BeginChild("##vailon", ImVec2(0, 0), true, 0);
                {

                    ImGui::Checkbox("###0", &preferences.Outfit);
                    ImGui::SameLine();
                    if (ImGui::InputInt("Outfit", &preferences.Config.Skin.XSuits)) {
                        if (prevXSuits != preferences.Config.Skin.XSuits) {
                            start = std::chrono::high_resolution_clock::now();
                            callFunction = true;
                            prevXSuits = preferences.Config.Skin.XSuits;
                        }
                    }

                    ImGui::Checkbox("###1", &preferences.Face);
                    ImGui::SameLine();
                    ImGui::InputInt("Face", &preferences.Config.Skin.XSuits);


                    ImGui::Checkbox("###2", &preferences.Bagg);
                    ImGui::SameLine();
                    ImGui::InputInt("Bag", &preferences.bag);


                    ImGui::Checkbox("###3", &preferences.Helmett);
                    ImGui::SameLine();
                    ImGui::InputInt("Helmet", &preferences.helmet);


                    ImGui::Checkbox("###4", &preferences.Emote);
                    ImGui::SameLine();
                    ImGui::InputInt("Emote", &ModEmote1);


                    ImGui::Checkbox("###5", &preferences.Parachute);
                    ImGui::SameLine();
                    ImGui::InputInt("Parachute", &preferences.Config.Skin.Parachute);

                    ImGui::EndChild();
                }
            }
            if (Setting::Tabs == 2) {
                ImGui::BeginChild("##vaicac", ImVec2(0, 0), true, 0);
                {


                    ImGui::Checkbox("###0", &preferences.M416);

                    ImGui::SameLine();

                    ImGui::InputInt("M416", &preferences.Config.Skin.M416);



                    ImGui::Checkbox("###1", &preferences.AKM);

                    ImGui::SameLine();

                    ImGui::InputInt("AKM", &preferences.Config.Skin.AKM);



                    ImGui::Checkbox("###2", &preferences.SCARL);

                    ImGui::SameLine();

                    ImGui::InputInt("SCAR-L", &preferences.Config.Skin.Scar);



                    ImGui::Checkbox("###3", &preferences.M762);

                    ImGui::SameLine();

                    ImGui::InputInt("M762", &preferences.Config.Skin.M762);


                    ImGui::Checkbox("###23", &preferences.GROZA);

                    ImGui::SameLine();

                    ImGui::InputInt("GROZA", &preferences.Config.Skin.Groza);



                    ImGui::Checkbox("###32", &preferences.AUG);

                    ImGui::SameLine();

                    ImGui::InputInt("AUG", &preferences.Config.Skin.AUG);


                    ImGui::Checkbox("###3U2", &preferences.M16);

                    ImGui::SameLine();

                    ImGui::InputInt("M16A4", &preferences.Config.Skin.M16A4);



                    ImGui::Checkbox("###3Ui2", &preferences.ACE32);

                    ImGui::SameLine();
                    ImGui::InputInt("ACE32", &preferences.Config.Skin.ACE32);


                    ImGui::Checkbox("###19", &preferences.KAR98);

                    ImGui::SameLine();

                    ImGui::InputInt("Kar98-k", &preferences.Config.Skin.K98);



                    ImGui::Checkbox("###20", &preferences.M24);

                    ImGui::SameLine();

                    ImGui::InputInt("M24", &preferences.Config.Skin.M24);



                    ImGui::Checkbox("###21", &preferences.AWM);

                    ImGui::SameLine();
                    ImGui::InputInt("AWM", &preferences.Config.Skin.AWM);



                    ImGui::Checkbox("###19T", &preferences.DP28);

                    ImGui::SameLine();

                    ImGui::InputInt("DP-28", &preferences.Config.Skin.DP28);



                    ImGui::Checkbox("###260", &preferences.M249);

                    ImGui::SameLine();

                    ImGui::InputInt("M249", &preferences.Config.Skin.M249);



                    ImGui::Checkbox("###21372", &preferences.UZI);

                    ImGui::SameLine();

                    ImGui::InputInt("UZI", &preferences.Config.Skin.UZI);



                    ImGui::Checkbox("###20UI", &preferences.UMP);

                    ImGui::SameLine();

                    ImGui::InputInt("UMP", &preferences.Config.Skin.UMP);



                    ImGui::Checkbox("###TT21", &preferences.TOMMY);


                    ImGui::SameLine();
                    ImGui::InputInt("Thompson", &preferences.Config.Skin.Thompson);



                    ImGui::Checkbox("###19TV", &preferences.VECTOR);

                    ImGui::SameLine();

                    ImGui::InputInt("Vector", &preferences.Config.Skin.Vector);



                    ImGui::Checkbox("###26y0", &preferences.BIZON);

                    ImGui::SameLine();

                    ImGui::InputInt("Bizon", &preferences.Config.Skin.Bizon);


                    ImGui::Checkbox("###26gy0", &preferences.PAN);

                    ImGui::SameLine();

                    ImGui::InputInt("Pan", &preferences.Config.Skin.Pan);

                    ImGui::EndChild();
                }
            }
            if (Setting::Tabs == 3) {
                ImGui::BeginChild("##vainho", ImVec2(0, 0), true, 0);
                {


                    ImGui::Checkbox("###0", &preferences.Dacia);

                    ImGui::SameLine();

                    ImGui::InputInt("Dacia", &preferences.Config.Skin.Dacia);

                    
                    
                    ImGui::Checkbox("###1", &preferences.CoupeRB);

                    ImGui::SameLine();

                    ImGui::InputInt("Coupe RB", &preferences.Config.Skin.CoupeRP);

                    
                    
                    ImGui::Checkbox("###2", &preferences.UAZ);

                    ImGui::SameLine();

                    ImGui::InputInt("UAZ", &preferences.Config.Skin.UAZ);

                    
                    ImGui::Checkbox("###23", &preferences.Moto);

                    ImGui::SameLine();

                    ImGui::InputInt("MotoBike", &preferences.Config.Skin.Moto);
                    

                    ImGui::Checkbox("###235", &preferences.BigFoot);

                    ImGui::SameLine();

                    ImGui::InputInt("BigFoot", &preferences.Config.Skin.Bigfoot);
                    

                    ImGui::Checkbox("###2345", &preferences.Mirado);

                    ImGui::SameLine();

                    ImGui::InputInt("Mirado", &preferences.Config.Skin.Mirado);
                    

                    ImGui::Checkbox("###2365", &preferences.Buggy);

                    ImGui::SameLine();

                    ImGui::InputInt("Buggy", &preferences.Config.Skin.Buggy);
                    

                    ImGui::Checkbox("###234995", &preferences.MiniBus);

                    ImGui::SameLine();

                    ImGui::InputInt("MiniBus", &preferences.Config.Skin.MiniBus);
                    

                    ImGui::Checkbox("###23650", &preferences.Boat);

                    ImGui::SameLine();

                    ImGui::InputInt("PG-117", &preferences.Config.Skin.Boat);
                    

                    ImGui::EndChild();
                }
            }
        }
    }

    ImGui::EndChild();
    ImGui::EndGroup();

    ImGui::SameLine();

    // =========================================================
    // CỘT 3: TIÊU ĐỀ & ĐÓNG (PHẢI) + DANH MỤC/HÌNH ẢNH TAB
    // =========================================================
    ImGui::BeginGroup();

    // HÀNG TRÊN CÙNG: DUCK-IOS (XANH LÁ) VÀ NÚT X (ĐỎ)
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.8f, 0.0f, 1.0f)); 
    ImGui::Button("DUCK-IOS", ImVec2(130, 40)); 
    ImGui::PopStyleColor();

    ImGui::SameLine(0, 5);

    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
    if (ImGui::Button("X", ImVec2(45, 40))) MenDeal = false;
    ImGui::PopStyleColor();

    ImGui::Spacing();

if (Settings::Tab == 1) {
    // 1. Thu hẹp vùng chứa nút xuống còn 170px để dành không gian cho các cột khác
    ImGui::BeginChild("ScrollableButtons", ImVec2(175, 0), false, ImGuiWindowFlags_NoScrollbar);

    // 2. Kích thước nút: Rộng 165 (vừa đủ hiện icon và chữ), Cao 45 (gọn gàng hơn)
    ImVec2 sideBtnSize = ImVec2(165, 45); 
    
    // 3. Giảm bo tròn xuống 12px để không bị thô khi nút nhỏ đi
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f); 
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 6)); 
    
    // 4. Giảm font chữ riêng cho vùng này nếu cần (ví dụ: 0.9f)
    ImGui::SetWindowFontScale(0.9f);

    // --- VISUAL ---
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.35f, 0.0f, 0.5f, 1.0f)); 
    if (ImGui::Button(ICON_FA_EYE " VISUAL", sideBtnSize)) Settings::Tab = 2;
    ImGui::PopStyleColor();

    // --- AIMBOT ---
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.0f, 0.45f, 1.0f)); 
    if (ImGui::Button(ICON_FA_CROSSHAIRS " AIMBOT", sideBtnSize)) Settings::Tab = 3;
    ImGui::PopStyleColor();

    // --- MEMORY ---
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.0f, 0.40f, 1.0f)); 
    if (ImGui::Button(ICON_FA_COG " MEMORY", sideBtnSize)) Settings::Tab = 4;
    ImGui::PopStyleColor();

    // --- MOD SKIN ---
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.0f, 0.35f, 1.0f)); 
    if (ImGui::Button(ICON_FA_MAGIC " SKIN", sideBtnSize)) Settings::Tab = 5;
    ImGui::PopStyleColor();

    // --- SETTINGS ---
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.0f, 0.30f, 1.0f)); 
    if (ImGui::Button(ICON_FA_WRENCH " SETTINGS", sideBtnSize)) Settings::Tab = 6;
    ImGui::PopStyleColor();

    ImGui::SetWindowFontScale(1.0f); // Trả font scale về mặc định
    ImGui::PopStyleVar(2); 
    ImGui::EndChild();
} else {
    // VÙNG HIỂN THỊ ẢNH CHO CÁC TAB 2, 3, 4, 5
    // Xóa bỏ viền của Child để ảnh trông nổi hơn hoặc giữ true nếu muốn có khung
    ImGui::BeginChild("ImageRegion", ImVec2(180, 0), false, ImGuiWindowFlags_NoScrollbar);
    
    static id<MTLTexture> tex_visual = nil;
    static id<MTLTexture> tex_aimbot = nil;
    static id<MTLTexture> tex_misc = nil;
    static id<MTLTexture> tex_skin = nil;

    ImVec2 imgSize = ImVec2(165, 230); 
    
    // Lấy vị trí con trỏ hiện tại để vẽ ảnh
    ImVec2 p = ImGui::GetCursorScreenPos();
    id<MTLTexture> current_tex = nil;

    // Xác định texture nào cần vẽ
    if (Settings::Tab == 2) {
        if (!tex_visual) tex_visual = CreateTextureFromMemory(self.device, img_visual_data, sizeof(img_visual_data));
        current_tex = tex_visual;
    } 
    else if (Settings::Tab == 3) {
        if (!tex_aimbot) tex_aimbot = CreateTextureFromMemory(self.device, img_aimbot_data, sizeof(img_aimbot_data));
        current_tex = tex_aimbot;
    }
    else if (Settings::Tab == 4) {
        if (!tex_misc) tex_misc = CreateTextureFromMemory(self.device, img_misc_data, sizeof(img_misc_data));
        current_tex = tex_misc;
    }
    else if (Settings::Tab == 5) {
        if (!tex_skin) tex_skin = CreateTextureFromMemory(self.device, img_skin_data, sizeof(img_skin_data));
        current_tex = tex_skin;
    }

    // Vẽ ảnh bo góc nếu texture tồn tại
    if (current_tex) {
        float rounding = 15.0f; // Độ bo tròn góc ảnh (chỉnh theo ý bạn)
        ImGui::GetWindowDrawList()->AddImageRounded(
            (__bridge void*)current_tex, 
            p, 
            ImVec2(p.x + imgSize.x, p.y + imgSize.y), 
            ImVec2(0, 0), ImVec2(1, 1), 
            IM_COL32_WHITE, 
            rounding
        );
        // Di chuyển con trỏ để ImGui biết vùng này đã được chiếm chỗ
        ImGui::Dummy(imgSize); 
    }

    ImGui::EndChild();
}

    ImGui::EndGroup();

    ImGui::End();
}
    
            
        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
                
                
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
                
        [commandBuffer presentDrawable:view.currentDrawable];
            
    }
        
        
        
        
        
    [commandBuffer commit];         
}

-(void) readIniConfig {
    ModSkinn = configManager::readBoolean(config,"modSwitch", "skin", false);
    KillMessage = configManager::readBoolean(config,"modSwitch", "killmsg", false);
    DeadBox = configManager::readBoolean(config,"modSwitch", "deadbox", false);
    ESPPlayer = configManager::readBoolean(config,"playerSwitch", "esp", false);
    Config.ESPMenu.HideBot = configManager::readBoolean(config,"playerSwitch", "ignorebot", false);
    Config.ESPMenu.Name = configManager::readBoolean(config,"playerSwitch", "name", false);
    Config.ESPMenu.Health = configManager::readBoolean(config,"playerSwitch", "health", false);
    Config.ESPMenu.Skeleton = configManager::readBoolean(config,"playerSwitch", "bone", false);
    Config.ESPMenu.Distance = configManager::readBoolean(config,"playerSwitch", "distance", false);
    Config.ESPMenu.TeamID = configManager::readBoolean(config,"playerSwitch", "teamid", false);
    Config.ESPMenu.Box = configManager::readBoolean(config,"playerSwitch", "box", false);
    Config.ESPMenu.Line = configManager::readBoolean(config,"playerSwitch", "line", false);
    Config.ESPMenu.Weapon = configManager::readBoolean(config,"playerSwitch", "status", false);
    Config.ESPMenu.Alert = configManager::readBoolean(config,"playerSwitch", "radar360", false);
    
    preferences.Config.SilentAim.AimBot        = configManager::readBoolean(config, "SilentAim", "AimBot", false);
    ShowFov                                    = configManager::readBoolean(config, "SilentAim", "ShowFov", false);
    preferences.Config.SilentAim.IgnoreKnocked = configManager::readBoolean(config, "SilentAim", "IgnoreKnocked", false);
    preferences.Config.SilentAim.IgnoreBot     = configManager::readBoolean(config, "SilentAim", "IgnoreBot", false);
    chedoaim   = configManager::readInteger(config, "SilentAim", "AimMode", 0);
    Istargets  = configManager::readInteger(config, "SilentAim", "AimTarget", 0);
    preferences.Config.SilentAim.Fov  = configManager::readFloat(config, "SilentAim", "FovValue", 200.0f);
    AimBotDistance   = configManager::readFloat(config, "SilentAim", "Distance", 150.0f);
    IsAimBotRecc = configManager::readFloat(config, "SilentAim", "Recoil", 1.0f);
    smoothIndex = configManager::readInteger(config, "SilentAim", "SmoothIndex", 2);

    switch (smoothIndex) {
        case 0: AimBotSpeed = 15.0f; break;
        case 1: AimBotSpeed = 10.0f;  break;
        case 2: AimBotSpeed = 7.0f;  break;
        case 3: AimBotSpeed = 3.0f;  break;
        case 4: AimBotSpeed = 2.0f;  break;
    }
}


- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}



#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

#pragma esp method ------------------------------------------------------------------------------------


typedef uintptr_t kaddr;
using namespace std;
using namespace SDK;





string encryptDecrypt(string toEncrypt) {
    char key[3] = {'K', 'C', 'Q'}; //Any chars will work, in an array of any size
    string output = toEncrypt;
    for (int i = 0; i < toEncrypt.size(); i++)
        output[i] = toEncrypt[i] ^ key[i % (sizeof(key) / sizeof(char))];
    return output;
}

kaddr getRealOffset(kaddr offset){
    return (unsigned long)Get_module_base()+offset;
}
long obbbbl() {//GUObject
   
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
      NSString *BundID = [infoDictionary objectForKey:@"CFBundleIdentifier"];
    if([BundID containsString:@"com.tencent.ig"]){
        return getRealOffset(0x10A288B80);
    }
    if([BundID containsString:@"pubg.krmobile"]){
        return getRealOffset(0x10A49C000);
    }
    if([BundID containsString:@"rekoo"]){
        return getRealOffset(0x10A47AF00);
    }
    if([BundID containsString:@"vn.vng.pubgmobile"]){
        return getRealOffset(0x10A692D18);
    }
    if([BundID containsString:@"imobile"]){
      return getRealOffset(0x109ABC718);
    }
    return false;
};

UWorld *GEWorld;
int GWorldNum = 0;
TUObjectArray gobjects;
UWorld *GetFullWorld()
{
    if(GWorldNum == 0) {
        gobjects = UObject::GUObjectArray->ObjObjects;
        for (int i=0; i< gobjects.Num(); i++)
            if (auto obj = gobjects.GetByIndex(i)) {
                if(obj->IsA(UEngine::StaticClass())) {
                    auto GEngine = (UEngine *) obj;
                    if(GEngine) {
                        auto ViewPort = GEngine->GameViewport;
                        if (ViewPort)
                        {
                            GEWorld = ViewPort->World;
                            GWorldNum = i;
                            return ViewPort->World;
                        }
                    }
                }
            }
    }else {
        auto GEngine = (UEngine *) (gobjects.GetByIndex(GWorldNum));
        if(GEngine) {
            auto ViewPort = GEngine->GameViewport;
            if(ViewPort) {
                GEWorld = ViewPort->World;
                return ViewPort->World;
            }
        }
    }
    return 0;
}

TNameEntryArray *GetGNames() {//GName Fun
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
      NSString *BundID = [infoDictionary objectForKey:@"CFBundleIdentifier"];
    if([BundID containsString:@"com.tencent.ig"]){
        return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104C0F1E8))();
    }
    if([BundID containsString:@"pubg.krmobile"]){
        return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104DD2100))();
    }
    if([BundID containsString:@"rekoo"]){
        return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104DAB6C4))();
    }
    if([BundID containsString:@"vn.vng.pubgmobile"]){
        return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104FD0B5C))();
    }
    if([BundID containsString:@"imobile"]){
      return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104734D98))();
    }
    return 0;
}

std::vector<AActor *> getActors() {
    auto World = GetFullWorld();
    if (!World)
    return std::vector<AActor *>();

    auto PersistentLevel = World->PersistentLevel;
    if (!PersistentLevel)
    return std::vector<AActor *>();

    auto Actors = *(TArray<AActor *> *)((uintptr_t) PersistentLevel + 0xA0);

    std::vector<AActor *> actors;
    for (int i = 0; i < Actors.Num(); i++) {
        auto Actor = Actors[i];
        if (Actor) {
            actors.push_back(Actor);
        }
    }
    return actors;
}
template <class T> void GetAllActors(std::vector<T*>& Actors) {
    UGameplayStatics* gGameplayStatics = (UGameplayStatics*)gGameplayStatics->StaticClass();
    auto GWorld = GetFullWorld();
    if (GWorld) {
        TArray<AActor*> Actors2;
        gGameplayStatics->GetAllActorsOfClass((UObject*)GWorld, T::StaticClass(), &Actors2);
        for (int i = 0; i < Actors2.Num(); i++) {
            Actors.push_back((T*)Actors2[i]);
        }
    }
}

FVector GetBoneLocationByName(ASTExtraPlayerCharacter *Actor, const struct FName BoneName) {
    return Actor->GetBonePos(BoneName, FVector());
}

#define TSL_FONT_DEFAULT_SIZE 20
static UFont *robotoFont = 0, *robotoTinyFont = 0,*tslFont = 0;

void DrawOutlinedText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void DrawTextcan(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = true) {
    UCanvas *Canvas = HUD->Canvas;   
    Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void *LoadFont() {
    while (!robotoFont || !robotoTinyFont || !tslFont) {
        tslFont = UObject::FindObject<UFont>("Font TSLFont.TSLFont");
        robotoFont = UObject::FindObject<UFont>("Font Roboto.Roboto");
        robotoTinyFont = UObject::FindObject<UFont>("Font RobotoTiny.RobotoTiny");
        sleep(1);
    }
    return 0;
}

ASTExtraPlayerController *g_PlayerController;
ASTExtraPlayerCharacter *g_LocalPlayer;
#define COLOR_WHITE FLinearColor(1.f, 1.f, 1.f, 1.f)
#define COLOR_GREEN FLinearColor(0, 0.5f, 0, 1.f)
#define COLOR_BLACK FLinearColor(0, 0, 0, 1.f)
#define COLOR_RED   FLinearColor(1.f, 0, 0, 1.f)

void DrawLine(AHUD *HUD, FVector2D posFrom, FVector2D posTo, float Thickness, FLinearColor Color) {
    HUD->DrawLine(posFrom.X, posFrom.Y, posTo.X, posTo.Y, Color, Thickness);
}

void DrawCircle(AHUD *HUD, int x, int y, int radius, int numsides, FLinearColor OutlineColor) {
    float Step = M_PI * 2.0 / numsides;
    int Count = 0;
    FVector2D V[128];
    for (float a = 0; a < M_PI * 2.0; a += Step)
    {
        float X1 = radius * cos(a) + x;
        float Y1 = radius * sin(a) + y;
        float X2 = radius * cos(a + Step) + x;
        float Y2 = radius * sin(a + Step) + y;
        V[Count].X = X1;
        V[Count].Y = Y1;
        V[Count + 1].X = X2;
        V[Count + 1].Y = Y2;
        HUD->Canvas->K2_DrawLine(FVector2D({ V[Count].X, V[Count].Y }), FVector2D({ X2, Y2 }), 1.5f, OutlineColor);
    }
}

void Box4Line(AHUD *HUD, float thicc, int x, int y, int w, int h, FLinearColor color) {
    int iw = w / 4;
    int ih = h / 4;

    HUD->DrawLine(x, y, x + iw, y, color, thicc);
    HUD->DrawLine(x + w - iw, y, x + w, y, color, thicc);
    HUD->DrawLine(x, y, x, y + ih, color, thicc);
    HUD->DrawLine(x + w - 1, y, x + w - 1, y + ih, color, thicc);

    // bottom
    HUD->DrawLine(x, y + h, x + iw, y + h, color, thicc);
    HUD->DrawLine(x + w - iw, y + h, x + w, y + h, color, thicc);
    HUD->DrawLine(x, y + h - ih, x, y + h, color, thicc);
    HUD->DrawLine(x + w - 1, y + h - ih, x + w - 1, y + h, color, thicc);
}

#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(g_PlayerController, w, false, s)

UGameplayStatics* iosde = (UGameplayStatics*)UGameplayStatics::StaticClass();

static std::unordered_set<uint32_t> AlreadyChangedSet;
static std::mutex AlreadyChangedSetMutex;

uintptr_t GetVirtualFunctionAddress(uintptr_t clazz, uintptr_t index) {
    if (!clazz) {
        return 0;
    }
    uintptr_t vtablePtr = *reinterpret_cast<uintptr_t*>(clazz);
    if (!vtablePtr) {
        return 0;
    }

    return *(reinterpret_cast<uintptr_t*>(vtablePtr) + index);
}


using PrechangeItemAvatarFunc = void(*)(uintptr_t, int, bool);

void ChangeItemAVc(uintptr_t thiz, int InItemID) {
    if (!thiz) {
        return;
    }

    constexpr uintptr_t VIRTUAL_FUNCTION_INDEX = 185;// idx
    uintptr_t funcAddr = GetVirtualFunctionAddress(thiz, VIRTUAL_FUNCTION_INDEX);

    if (!funcAddr) {
        return;
    }

    auto pFunc = reinterpret_cast<PrechangeItemAvatarFunc>(funcAddr);
    pFunc(thiz, InItemID, true);
}

int glWidth, glHeight;

auto GetTargetForAimBotByFOV() {
    UGameplayStatics *GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    ASTExtraPlayerCharacter *result = 0;
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;

    auto GWorld = GetFullWorld();
    if (IsValidAddress((kaddr)GWorld)) {
        UNetDriver *NetDriver = GWorld->NetDriver;
        if (IsValidAddress((kaddr)NetDriver)) {
            UNetConnection *ServerConnection = NetDriver->ServerConnection;
            if (IsValidAddress((kaddr)ServerConnection)) {
                localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
            }
        }
        
        if (IsValidAddress((kaddr)localPlayerController)) {
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
            GetAllActors(PlayerCharacter);

            if (IsValidAddress((kaddr)localPlayerController->Pawn)) {
                localPlayer = (ASTExtraPlayerCharacter*)localPlayerController->Pawn;
            } else {
                 for (auto actor : PlayerCharacter) {
                    if (actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                        localPlayer = actor;
                        break;
                    }
                }
            }

            if (localPlayer) {
                float max = std::numeric_limits<float>::infinity();

                for (auto Player : PlayerCharacter) {
                    if (!IsValidAddress((kaddr)Player)) continue;
                    
                    float Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                    if(AimBotDistance < Distance)
                            continue;
                    if (Player->PlayerKey == localPlayer->PlayerKey)
                        continue;
                    if (Player->TeamID == localPlayer->TeamID)
                        continue;
                    if (Player->bDead)
                        continue;
                    if (Player->bHidden)
                        continue;
                    if (!IsValidAddress((kaddr)Player->Mesh))
                        continue;
                    if (!IsValidAddress((kaddr)Player->RootComponent))
                        continue;
                    
                    if (preferences.Config.SilentAim.IgnoreKnocked) {
                        if (Player->Health == 0.0f)
                            continue;
                    }
                    if(isAimvisual){
                        if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true))
                            continue;
                    }
                    if (preferences.Config.SilentAim.IgnoreBot) {
                        if (Player->bEnsure)
                            continue;
                    }
                    auto Root = Player->RootComponent->K2_GetComponentLocation();
                    auto Head = Player->GetBonePos(("Head"), FVector());
                    FVector2D RootSc, HeadSc;
                    if (GameplayStatics->ProjectWorldToScreen(g_PlayerController, Root, false, &RootSc) && GameplayStatics->ProjectWorldToScreen(g_PlayerController, Head, false, &HeadSc)) {
                        float height = abs(HeadSc.Y - RootSc.Y);
                        float width = height * 0.65f;
                        FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                        if ((middlePoint.X >= 0 && middlePoint.X <= screenWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= screenHeight)) {
                            FVector2D v2Middle = FVector2D((float) (screenWidth / 2), (float) (screenHeight / 2));
                            FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);
                            if(isInsideFOV((int)middlePoint.X, (int)middlePoint.Y)) {
                                float dist = FVector2D::Distance(v2Middle, v2Loc);
                                if (dist < max) {
                                    max = dist;
                                    result = Player;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

bool isInsideFOV(int x, int y) {
    if (!preferences.Config.SilentAim.Fov)
        return true;
    int circle_x = screenWidth / 2;
    int circle_y = screenHeight / 2;
    int rad = (int) preferences.Config.SilentAim.Fov * 2.0f;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

void IMGUI_GOD(FRotator &angles) {
    if (angles.Pitch > 180)
        angles.Pitch -= 360;
    if (angles.Pitch < -180)
        angles.Pitch += 360;

    if (angles.Pitch < -75.f)
        angles.Pitch = -75.f;
    else if (angles.Pitch > 75.f)
        angles.Pitch = 75.f;

    while (angles.Yaw < -180.0f)
        angles.Yaw += 360.0f;
    while (angles.Yaw > 180.0f)
        angles.Yaw -= 360.0f;
}

void IMGUI_GOD(float *angles) {
    if (angles[0] > 180)
        angles[0] -= 360;
    if (angles[0] < -180)
        angles[0] += 360;

    if (angles[0] < -75.f)
        angles[0] = -75.f;
    else if (angles[0] > 75.f)
        angles[0] = 75.f;

    while (angles[1] < -180.0f)
        angles[1] += 360.0f;
    while (angles[1] > 180.0f)
        angles[1] -= 360.0f;
}

void IMGUI_GOD(FVector2D angles) {
    if (angles.X > 180)
        angles.X -= 360;
    if (angles.X < -180)
        angles.X += 360;

    if (angles.X < -75.f)
        angles.X = -75.f;
    else if (angles.X > 75.f)
        angles.X = 75.f;

    while (angles.Y < -180.0f)
        angles.Y += 360.0f;
    while (angles.Y > 180.0f)
        angles.Y -= 360.0f;
}

void RenderESP(AHUD *HUD, int ScreenWidth, int ScreenHeight) {
    updateSkin();
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
    glWidth = ScreenWidth;
    glHeight = ScreenHeight;
    UCanvas *Canvas = HUD->Canvas;
    if (Canvas) {
        static bool loadFont = false;
        if (!loadFont) {
            LoadFont();
            loadFont = true;
        }
    
        if (!robotoFont || !tslFont || !robotoTinyFont)
            return;
        UGameplayStatics *gGameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
        UKismetMathLibrary* UMC = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();
        auto Actors = getActors();
        auto GWorld = GetFullWorld();
        if (GWorld) {
            UNetDriver *NetDriver = GWorld->NetDriver;
            if (NetDriver) {
                UNetConnection *ServerConnection = NetDriver->ServerConnection;
                if (ServerConnection) {
                    localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
                }
            }

            if (localPlayerController) {
                std::vector<ASTExtraPlayerCharacter *> PlayerCharacter;
                GetAllActors(PlayerCharacter);
                for (auto actor = PlayerCharacter.begin();
                     actor != PlayerCharacter.end(); actor++) {
                    auto Actor = *actor;

                    if (Actor->PlayerKey ==
                        ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                        localPlayer = Actor;
                        break;
                    }
                }

                {
                    if (localPlayer) {
                        if (WideView) {
                            auto ThirdPersonCameraComponent = localPlayer->ThirdPersonCameraComponent;
                            if (ThirdPersonCameraComponent) {
                                *(float *) ((uintptr_t) &ThirdPersonCameraComponent->OrthoWidth - sizeof(float)) = WideValue;
                            }
                        }
                        if(!localPlayer->IsUsingGrenade()) {
                            auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                            if (WeaponManagerComponent) {
                                auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                                if ((int) propSlot.GetValue() >= 1 &&
                                    (int) propSlot.GetValue() <= 3) {
                                    auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                                if (CurrentWeaponReplicated) {
                                    auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
                                    auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
                                            
                                    auto ID = CurrentWeaponReplicated->GetWeaponID();
                                    if(ID != 108004 && ID != 108003 && ID != 108002 && ID != 108001 && ID != 108000 && ID != 108005 && ID != 108006 && ID != 108007)
                                        if (ShootWeaponEntityComp && ShootWeaponEffectComp)
                                        {
                                            if (Crosshair) {
                                              static float cnt = 0.0f;
                                              float r = cos(cnt) * .5f + .5f;
                                                float g = cos(cnt - 2.f * 3.14 / 3.f) * .5f + .5f;
                                                float b = cos(cnt - 4.f * 3.14 / 3.f) * .5f + .5f;
                                                if (cnt >= FLT_MAX) {
                                                    cnt = 0.0f;
                                                } else {
                                                    cnt += 0.01f;
                                                }
                                                
                                                memset(&ShootWeaponEntityComp->DeviationInfo, 0, sizeof(FSDeviation));
                                                memset(&ShootWeaponEntityComp->RecoilInfo, 0, sizeof(FSRecoilInfo));
                                                
                                                ShootWeaponEntityComp->ShotGunCenterPerc = 0.0f;
                                                ShootWeaponEntityComp->ShotGunVerticalSpread = 0.0f;
                                                ShootWeaponEntityComp->ShotGunHorizontalSpread = 0.0f;
                                                ShootWeaponEntityComp->GameDeviationFactor = 0.0f;
                                                ShootWeaponEntityComp->GameDeviationAccuracy = 0.0f;
                                                ShootWeaponEntityComp->CrossHairInitialSize = 0.0f;
                                                ShootWeaponEntityComp->CrossHairBurstSpeed = 0.0f;
                                                ShootWeaponEntityComp->CrossHairBurstIncreaseSpeed = 0.0f;
                                                ShootWeaponEntityComp->VehicleWeaponDeviationAngle = 0.0f;
                                            }
                                        }
                                    }
                                }
                            }
                        }
            
                        auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                         
                        if (ModSkinn) {
                            if (DeadBox) {
                                std::vector<APlayerTombBox *> TombBox;
                                GetAllActors(TombBox);
                                for (auto actor = TombBox.begin();
                                    actor != TombBox.end(); actor++) {
                                    auto TombBoxx = *actor;
                                    if (TombBoxx && TombBoxx->DamageCauser && TombBoxx->TargetPlayer && g_PlayerController) // Check pointers before dereferencing
                                    {
                                        if (TombBoxx->DamageCauser->PlayerKey == g_PlayerController->PlayerKey)
                                        {
                                            auto PlayerKey = TombBoxx->TargetPlayer->PlayerKey;
                                            if (AlreadyChangedSet.find(PlayerKey) == AlreadyChangedSet.end())
                                            {
                                                if (g_LocalPlayer && g_LocalPlayer->WeaponManagerComponent)
                                                {
                                                    auto DeadBoxAvatarCompPtr = (uintptr_t*)((uintptr_t)TombBoxx + 0x660); //DeadBoxAvatarComponent_BP_C* DeadBoxAvatarComponent_BP
                                                    if (DeadBoxAvatarCompPtr)
                                                    {
                                                        auto DeadBoxAvatarComp = *DeadBoxAvatarCompPtr;
                                                        auto CurrentWeaponReplicated = g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated;
                                                        if (CurrentWeaponReplicated)
                                                        {
                                                            auto Weaponid = g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponID();

                                                            if (Weaponid == 101004) {
                                                                ChangeItemAVc(DeadBoxAvatarComp, new_Skin.M416_1);
                                                                AlreadyChangedSet.insert(PlayerKey);
                                                            } else if (Weaponid == 101001) {
                                                                ChangeItemAVc(DeadBoxAvatarComp, new_Skin.AKM);
                                                                AlreadyChangedSet.insert(PlayerKey);
                                                            } else if (Weaponid == 101003) {
                                                                ChangeItemAVc(DeadBoxAvatarComp, new_Skin.Scar);
                                                                AlreadyChangedSet.insert(PlayerKey);
                                                            } else if (Weaponid == 101008) {
                                                                ChangeItemAVc(DeadBoxAvatarComp, new_Skin.M762);
                                                                AlreadyChangedSet.insert(PlayerKey);
                                                            }       
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }	

                            if (localPlayer->WeaponManagerComponent != 0) {
                                if (localPlayer->WeaponManagerComponent->CurrentWeaponReplicated != 0 ) {
                                    int weapowep = localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->GetWeaponID();
                                    auto currentTime = std::chrono::steady_clock::now();
                                    auto landchud = localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->synData;
                                    auto timeDiff = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastWeaponChangeTime).count();
                                    
                                    if (timeDiff > 1000) {
                                        for (int j = 0; j < landchud.Num(); j++) {
                                            auto& weaponInfo = landchud[j];
                                            auto weaponid = weaponInfo.DefineID.TypeSpecificID;
                                            if (weaponid != 0)
                                            {
                                                if (preferences.AKM && weapowep == 101001) {
                                                    for (int i = 0; i < sizeof(akmv) / sizeof(akmv[0]); i++) {
                                                        if (weaponid == akmv[i]) {
                                                            weaponInfo.DefineID.TypeSpecificID = new_Skin.AKM;
                                                            break;
                                                        }
                                    				}
                                				    for (int i = 0; i < sizeof(akmmag) / sizeof(akmmag[0]); i++) {
                                                        if (weaponid == akmmag[i]) {
                                                            weaponInfo.DefineID.TypeSpecificID = new_Skin.AKM_Mag;
                                                            break;
                                                        }
                                				    }
                                				}
                                				if (preferences.KAR98 && weapowep == 103001) {
                                    				for (int i = 0; i < sizeof(kar) / sizeof(kar[0]); i++) {
                                                        if (weaponid == kar[i]) {
                                                            weaponInfo.DefineID.TypeSpecificID = new_Skin.K98;
                                                            break;
                                                        }
                                    				}
                                				}
                                				if (preferences.M24 && weapowep == 103002) {
                                				for (int i = 0; i < sizeof(m24) / sizeof(m24[0]); i++) {
                                                if (weaponid == m24[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M24;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.AWM && weapowep == 103003) {
                                				for (int i = 0; i < sizeof(awm) / sizeof(awm[0]); i++) {
                                                if (weaponid == awm[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.AWM;
                                                    break;
                                                }
                                				}
                                				}
                                				
                                				
                                				if (preferences.TOMMY && weapowep == 102004) {
                                				for (int i = 0; i < sizeof(tommy) / sizeof(tommy[0]); i++) {
                                                if (weaponid == tommy[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Thompson;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.ACE32 && weapowep == 101102) {
                                				for (int i = 0; i < sizeof(ace32) / sizeof(ace32[0]); i++) {
                                                if (weaponid == ace32[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.ACE32;
                                                    break;
                                                }
                                				}
                                				}
                                				
                                				if (preferences.BIZON && weapowep == 102005) {
                                				for (int i = 0; i < sizeof(bizon) / sizeof(bizon[0]); i++) {
                                                if (weaponid == bizon[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Bizon;
                                                    break;
                                                }
                                				}
                                				}
                                				
                                				if (preferences.VECTOR && weapowep == 102003) {
                                				for (int i = 0; i < sizeof(vectorr) / sizeof(vectorr[0]); i++) {
                                                if (weaponid == vectorr[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Vector;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.UMP && weapowep == 102002) {
                                				for (int i = 0; i < sizeof(ump) / sizeof(ump[0]); i++) {
                                                if (weaponid == ump[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.UMP;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.UZI && weapowep == 102001) {
                                				for (int i = 0; i < sizeof(uzi) / sizeof(uzi[0]); i++) {
                                                if (weaponid == uzi[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.UZI;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.M16 && weapowep == 101002) {
                                				for (int i = 0; i < sizeof(m16) / sizeof(m16[0]); i++) {
                                                if (weaponid == m16[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M16A4;
                                                    break;
                                                }
                                				}
                                				for (int i = 0; i < sizeof(m16s) / sizeof(m16s[0]); i++) {
                                                if (weaponid == m16s[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M16A4_Stock;
                                                    break;
                                                }
                                				}
                                				for (int i = 0; i < sizeof(m16mag) / sizeof(m16mag[0]); i++) {
                                                if (weaponid == m16mag[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M16A4_Mag;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.PAN && weapowep == 108004) {
                                				for (int i = 0; i < sizeof(pan) / sizeof(pan[0]); i++) {
                                                if (weaponid == pan[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Pan;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.AUG && weapowep == 101006) {
                                				for (int i = 0; i < sizeof(aug) / sizeof(aug[0]); i++) {
                                                if (weaponid == aug[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.AUG;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.GROZA && weapowep == 101005) {
                                				for (int i = 0; i < sizeof(groza) / sizeof(groza[0]); i++) {
                                                if (weaponid == groza[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Groza;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.DP28 && weapowep == 105002) {
                                				for (int i = 0; i < sizeof(dp) / sizeof(dp[0]); i++) {
                                                if (weaponid == dp[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.DP28;
                                                    break;
                                                }
                                				}
                                				}
                                				if (preferences.M249 && weapowep == 105001) {
                                				for (int i = 0; i < sizeof(m249) / sizeof(m249[0]); i++) {
                                                if (weaponid == m249[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M249;
                                                    break;
                                                }
                                				}
                                				}
                                				
                                				if (preferences.SCARL && weapowep == 101003) {
                                				for (int i = 0; i < sizeof(scar) / sizeof(scar[0]); i++) {
                                                if (weaponid == scar[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Scar;
                                                    break;
                                                }
                                				}
                                				for (int i = 0; i < sizeof(scarmag) / sizeof(scarmag[0]); i++) {
                                                if (weaponid == scarmag[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.Scar_Mag;
                                                    break;
                                                }
                                				}
                                			}
                                				
                                				if (preferences.M762 && weapowep == 101008) {
                                				for (int i = 0; i < sizeof(m7) / sizeof(m7[0]); i++) {
                                                if (weaponid == m7[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M762;
                                                    break;
                                                }
                                				}
                                				for (int i = 0; i < sizeof(m7mag) / sizeof(m7mag[0]); i++) {
                                                if (weaponid == m7mag[i]) {
                                                    weaponInfo.DefineID.TypeSpecificID = new_Skin.M762_Mag;
                                                    break;
                                                }
                                				}
                                				}
                                				
                                				if (preferences.M416 && weapowep == 101004) {
                                    				for (int i = 0; i < sizeof(m4v) / sizeof(m4v[0]); i++) {
                                                    if (weaponid == m4v[i]) {
                                                        weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_1;
                                                        break;
                                                    }
                                    				}
                                    				for (int i = 0; i < sizeof(m4mag) / sizeof(m4mag[0]); i++) {
                                                    if (weaponid == m4mag[i]) {
                                                        weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_2;
                                                        break;
                                                    }
                                    				}
                                    				for (int i = 0; i < sizeof(m4sight) / sizeof(m4sight[0]); i++) {
                                                    if (weaponid == m4sight[i]) {
                                                        weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_3;
                                                        break;
                                                    }
                                    				}
                                    				for (int i = 0; i < sizeof(m4stock) / sizeof(m4stock[0]); i++) {
                                                    if (weaponid == m4stock[i]) {
                                                        weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_4;
                                                        break;
                                                    }
                                    				}
                                    				for (int i = 0; i < sizeof(m4stock1) / sizeof(m4stock1[0]); i++) {
                                                    if (weaponid == m4stock1[i]) {
                                                        weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_stock;
                                                        break;
                                                    }
                                    				}
                                    				for (int i = 0; i < sizeof(m4reddot) / sizeof(m4reddot[0]); i++) {
                                                        if (weaponid == m4reddot[i]) {
                                                            weaponInfo.DefineID.TypeSpecificID = new_Skin.M416_reddot;
                                                            break;
                                                        }
                                    				}
                                				}
                                                localPlayer->WeaponManagerComponent->CurrentWeaponReplicated->DelayHandleAvatarMeshChanged();
                                                lastWeaponChangeTime = currentTime;
                                            }
                                        }
                                    }
                                }
                            }

                            if (localPlayer -> CurrentVehicle) {
                                    if (localPlayer -> CurrentVehicle -> VehicleAvatar) {
                                      std::string SkinIDStr = std::to_string((int) localPlayer -> CurrentVehicle -> VehicleAvatar -> GetDefaultAvatarID());
                                      Active::SkinCarDefault = localPlayer -> CurrentVehicle -> GetAvatarID();

                            		  
                                      if (preferences.Moto && strstr(SkinIDStr.c_str(), "1901")) {
                                        Active::SkinCarMod = new_Skin.Moto;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.Dacia && strstr(SkinIDStr.c_str(), "1903")) {
                                        Active::SkinCarMod = new_Skin.Dacia;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.Boat && strstr(SkinIDStr.c_str(), "1911")) {
                                        Active::SkinCarMod = new_Skin.Boat;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.MiniBus && strstr(SkinIDStr.c_str(), "1904")) {
                                        Active::SkinCarMod = new_Skin.MiniBus;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.Mirado && strstr(SkinIDStr.c_str(), "1914")) {
                                        Active::SkinCarMod = new_Skin.Mirado;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.Mirado && strstr(SkinIDStr.c_str(), "1915")) {
                                        Active::SkinCarMod = new_Skin.Mirado;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.Buggy && strstr(SkinIDStr.c_str(), "1907")) {
                                        Active::SkinCarMod = new_Skin.Buggy;
                                        Active::SkinCarNew = true;
                                      }else if (preferences.CoupeRB && strstr(SkinIDStr.c_str(), "1961")) {
                                        Active::SkinCarMod = new_Skin.CoupeRP;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.BigFoot && strstr(SkinIDStr.c_str(), "1953")) {
                                        Active::SkinCarMod = new_Skin.Bigfoot;
                                        Active::SkinCarNew = true;
                                      } else if (preferences.UAZ && strstr(SkinIDStr.c_str(), "1908")) {
                                        Active::SkinCarMod = new_Skin.UAZ;
                                        Active::SkinCarNew = true;
                                      } else Active::SkinCarNew = false;

                                      if (Active::SkinCarDefault != Active::SkinCarMod && Active::SkinCarNew) {
                                        
                                        localPlayer -> CurrentVehicle -> VehicleAvatar -> ChangeItemAvatar(Active::SkinCarMod, true);
                                    }
                                }
                            }

                            if (localPlayerController->BackpackComponent) {
                            	 auto data = localPlayerController->BackpackComponent->ItemListNet;
                            	 auto bag = data.IncArray;
                            	 for (int j = 0; j < bag.Num(); j++) {
                            	 int ID = bag[j].Unit.DefineID.TypeSpecificID;
                            	 if (preferences.Outfit){
                                        for (int i = 0; i < sizeof(SuitX) / sizeof(SuitX[0]); i++) {
                                                 if (ID == SuitX[i]) {
                                                     bag[j].Unit.DefineID.TypeSpecificID = new_Skin.XSuits;
                                                     break;
                                                  }
                                				 }
                                				}
                                				if (preferences.Bagg){
                                        for (int i = 0; i < sizeof(Bag) / sizeof(Bag[0]); i++) {
                                                 if (ID == Bag[i]) {
                                                     bag[j].Unit.DefineID.TypeSpecificID = bag3;
                                                     break;
                                                  }
                                				 }
                                				}
                                				if (preferences.Helmett){
                                        for (int i = 0; i < sizeof(Helmet) / sizeof(Helmet[0]); i++) {
                                                 if (ID == Helmet[i]) {
                                                     bag[j].Unit.DefineID.TypeSpecificID = helmett3;
                                                     break;
                                                  }
                                				 }
                                				}
                                				if (preferences.Emote){
                                        for (int i = 0; i < sizeof(emote1) / sizeof(emote1[0]); i++) {
                                                 if (ID == emote1[i]) {
                                                     bag[j].Unit.DefineID.TypeSpecificID = sEmote1;
                                                     break;
                                                  }
                                				 }
                                        for (int i = 0; i < sizeof(emote2) / sizeof(emote2[0]); i++) {
                                            if (ID == emote2[i]) {
                                                bag[j].Unit.DefineID.TypeSpecificID = sEmote2;
                                                break;
                                            }
                        				}
                                        for (int i = 0; i < sizeof(emote3) / sizeof(emote3[0]); i++) {
                                            if (ID == emote3[i]) {
                                                bag[j].Unit.DefineID.TypeSpecificID = sEmote3;
                                                break;
                                            }
                        				}
                        			}
                                }
                            }

                             
                            if (localPlayer -> AvatarComponent2) {

                                auto AvatarComp = localPlayer -> AvatarComponent2;
                                                           
                                FNetAvatarSyncData NetAvatarComp = * (FNetAvatarSyncData * )((uintptr_t) AvatarComp + 0x388); //if u use 64bit change this offset
                                auto Slotsybc = NetAvatarComp.SlotSyncData;
                                if (preferences.Parachute) {
                                    Slotsybc[11].ItemId = new_Skin.Parachute;
                                }
                                if (preferences.Outfit) {
                                	Slotsybc[5].ItemId = new_Skin.XSuits;
                                }
                                if (preferences.Bagg) {
                                	Slotsybc[8].ItemId = bag3;
                                }
                                if (preferences.Helmett) {
                                	Slotsybc[9].ItemId = helmett3;
                                }
                                auto now = std::chrono::high_resolution_clock::now();
                                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start).count();

                                if (elapsed < 1 && callFunction) {
                                    localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
                                    localPlayerController->BackpackComponent->OnRep_ItemListNet();
                                } else {
                                    callFunction = false;
                                }
                            }
                        }
                        if(ESPPlayer) {
                            int totalEnemies = 0, totalBots = 0;
                            std::vector<ASTExtraPlayerCharacter *> PlayerCharacter;
                            GetAllActors(PlayerCharacter);
                            for (auto actor = PlayerCharacter.begin();
                                 actor != PlayerCharacter.end(); actor++) {
                                auto Player = *actor;

                                float Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                                if (Distance > EspDistance)
                                    continue;

                                if (Player->PlayerKey == localPlayer->PlayerKey)
                                    continue;

                                if (Player->TeamID == localPlayer->TeamID)
                                    continue;

                                if (Player->bDead)
                                    continue;

                                if (Player->bHidden)
                                    continue;

                                if (!Player->RootComponent)
                                    continue;


                                if (Config.ESPMenu.HideBot) {
                                    if (Player->bEnsure)
                                        continue;
                                }


                                if (Player->bEnsure)
                                    totalBots++;
                                else totalEnemies++;

                                bool IsVisible = localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true);
                        
                                FLinearColor ColorVisible;   
                                FLinearColor ColorVisibles;   
                                   
                                if (Player->bEnsure) {
                                    ColorVisible = COLOR_WHITE;       
                                    ColorVisibles = COLOR_WHITE;                          
                                }
                                   
                                if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true)) {
                                    ColorVisible = {1.f, 1.f, 1.f, 1.f};
                                    } else {
                                    ColorVisible = {0.f, 1.f, 0.f, 1.f};
                                }
                                if (!localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true)) {
                                    ColorVisibles = {1.f, 0.f, 0.f, 1.f};
                                    } else {
                                    ColorVisibles = {0.f, 1.f, 0.f, 1.f};
                                }
                                if (Player->Health <= 0) {
                                    ColorVisibles = {0.f, 0.f, 0.f, 1.f};
                                    ColorVisible = {0.f, 0.f, 0.f, 1.f};
                                }

                                FVector Head = GetBoneLocationByName(Player, "Head");
                                Head.Z += 12.5f;
                                FVector Root = GetBoneLocationByName(Player, "Root");
                                FVector upper_r = GetBoneLocationByName(Player, "upperarm_r");
                                FVector lowerarm_r = GetBoneLocationByName(Player, "lowerarm_r");
                                FVector hand_r = GetBoneLocationByName(Player, "hand_r");
                                FVector upper_l = GetBoneLocationByName(Player, "upperarm_l");
                                FVector lowerarm_l = GetBoneLocationByName(Player, "lowerarm_l");
                                FVector hand_l = GetBoneLocationByName(Player, "hand_l");
                                FVector thigh_l = GetBoneLocationByName(Player, "thigh_l");
                                FVector calf_l = GetBoneLocationByName(Player, "calf_l");
                                FVector foot_l = GetBoneLocationByName(Player, "foot_l");
                                FVector thigh_r = GetBoneLocationByName(Player, "thigh_r");
                                FVector calf_r = GetBoneLocationByName(Player, "calf_r");
                                FVector foot_r = GetBoneLocationByName(Player, "foot_r");
                                FVector neck_01 = GetBoneLocationByName(Player, "neck_01");
                                FVector pelvis = GetBoneLocationByName(Player, "pelvis");

                                FVector2D HeadSc, RootSc, upper_rPoSC, lowerarm_rPoSC, hand_rPoSC, upper_lPoSC, hand_lPoSC, thigh_lPoSC, calf_lPoSC, foot_lPoSC, thigh_rPoSC, calf_rPoSC, foot_rPoSC, neck_01PoSC, pelvisPoSC, lowerarm_lSC;
                                if (gGameplayStatics->ProjectWorldToScreen(
                                        localPlayerController,
                                        Head, false, &HeadSc) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            upper_r, false,
                                            &upper_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            upper_l, false,
                                            &upper_lPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            lowerarm_r, false,
                                            &lowerarm_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            hand_r, false,
                                            &hand_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            lowerarm_l, false,
                                            &lowerarm_lSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            hand_l, false,
                                            &hand_lPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            thigh_l, false,
                                            &thigh_lPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            calf_l, false,
                                            &calf_lPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            foot_l, false,
                                            &foot_lPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            thigh_r, false,
                                            &thigh_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            calf_r, false,
                                            &calf_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            foot_r, false,
                                            &foot_rPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            neck_01, false,
                                            &neck_01PoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            pelvis, false,
                                            &pelvisPoSC) &&
                                    gGameplayStatics->ProjectWorldToScreen(
                                            localPlayerController,
                                            Root, false, &RootSc)) {

                                    bool IsVisible = localPlayerController->LineOfSightTo(
                                            Player,
                                            {0, 0, 0},
                                            true);
                                    FLinearColor Color = {1.0f, 0, 0, 1.0f};
                                    if (IsVisible)
                                        Color = {0, 1.0f, 0, 1.0f};

                                    if (Config.ESPMenu.Line) {
                                        auto AboveHead = Player->GetHeadLocation(true);
                                        AboveHead.Z += 35.f;
                                        FVector2D AboveHeadSc;
                                        if (gGameplayStatics->ProjectWorldToScreen(localPlayerController,AboveHead, false,&AboveHeadSc)) {
                                            DrawLine(HUD, FVector2D(static_cast<float>(screenWidth / 2), 0), FVector2D(AboveHeadSc.X, AboveHeadSc.Y - 40), 1.5f, ColorVisible);
                                        }
                                    }
                                    if (Config.ESPMenu.Skeleton) {
                                        FName BoneID[18] = {"Head","neck_01", "spine_03", "spine_02", "spine_01", "pelvis","upperarm_r", "lowerarm_r", "hand_r","upperarm_l", "lowerarm_l", "hand_l","thigh_r", "calf_r", "foot_r","thigh_l", "calf_l", "foot_l"};
                                        FVector2D Bones[18];
                                        bool IsVisBone[18];
                                        for (int i = 0; i < 18; i++) {
                                            FVector BoneID_0 = GetBoneLocationByName(Player, BoneID[i]);
                                            gGameplayStatics->ProjectWorldToScreen(localPlayerController,BoneID_0, false, &Bones[i]);
                                            IsVisBone[i] = localPlayerController->LineOfSightTo(localPlayerController->PlayerCameraManager,BoneID_0, false);
                                        }
                                        if (Player->bEnsure) {
                                            DrawCircle(HUD, Bones[0].X, Bones[0].Y, 3, 12, IsVisBone[0] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[0], Bones[1], EspSktonThik, IsVisBone[0] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[2], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[2], Bones[3], EspSktonThik, IsVisBone[2] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[3], Bones[4], EspSktonThik, IsVisBone[3] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[4], Bones[5], EspSktonThik, IsVisBone[4] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[6], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[6], Bones[7], EspSktonThik, IsVisBone[6] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[7], Bones[8], EspSktonThik, IsVisBone[7] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[9], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[9], Bones[10], EspSktonThik, IsVisBone[9] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[10], Bones[11], EspSktonThik, IsVisBone[10] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[5], Bones[12], EspSktonThik, IsVisBone[5] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[12], Bones[13], EspSktonThik, IsVisBone[12] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[13], Bones[14], EspSktonThik, IsVisBone[13] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[5], Bones[15], EspSktonThik, IsVisBone[5] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[15], Bones[16], EspSktonThik, IsVisBone[15] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                            DrawLine(HUD,Bones[16], Bones[17], EspSktonThik, IsVisBone[16] ? FLinearColor(0.f, 1.f, 1.f, 1.f) : FLinearColor(1.f, 1.f, 1.f, 1.f));
                                        } else {
                                            DrawCircle(HUD, Bones[0].X, Bones[0].Y, 3, 12, IsVisBone[0] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[0], Bones[1], EspSktonThik, IsVisBone[0] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[2], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[2], Bones[3], EspSktonThik, IsVisBone[2] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[3], Bones[4], EspSktonThik, IsVisBone[3] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[4], Bones[5], EspSktonThik, IsVisBone[4] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[6], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[6], Bones[7], EspSktonThik, IsVisBone[6] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[7], Bones[8], EspSktonThik, IsVisBone[7] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[1], Bones[9], EspSktonThik, IsVisBone[1] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[9], Bones[10], EspSktonThik, IsVisBone[9] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[10], Bones[11], EspSktonThik, IsVisBone[10] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[5], Bones[12], EspSktonThik, IsVisBone[5] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[12], Bones[13], EspSktonThik, IsVisBone[12] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[13], Bones[14], EspSktonThik, IsVisBone[13] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[5], Bones[15], EspSktonThik, IsVisBone[5] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[15], Bones[16], EspSktonThik, IsVisBone[15] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                            DrawLine(HUD,Bones[16], Bones[17], EspSktonThik, IsVisBone[16] ? FLinearColor(0.f, 1.f, 0.f, 1.f) : FLinearColor(1.f, 0.f, 0.f, 1.f));
                                        }
                                    }
                                                
                                    if (Config.ESPMenu.Box) {
                                            float boxHeight = abs(HeadSc.Y - RootSc.Y);
                                           float boxWidth = boxHeight * 0.65f;
        							       FVector2D vBox = FVector2D(HeadSc.X - (boxWidth / 2), HeadSc.Y);
                                           Box4Line(HUD, 1.5f, vBox.X, vBox.Y, boxWidth, boxHeight, ColorVisibles);
                                    }

                                    if (Config.ESPMenu.Weapon) {
                                       auto WeaponManagerComponent = Player->WeaponManagerComponent;
                                       if (WeaponManagerComponent) {
                                           {
                                               auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
                                               if (CurrentWeaponReplicated) {
                                                   auto WeaponId = (int)CurrentWeaponReplicated->GetWeaponID();
                                                   if (WeaponId) {
                                                       
                                                       
                                                       std::wstring s;
                                                       s += CurrentWeaponReplicated->GetWeaponName().ToWString();
                                                       robotoFont->LegacyFontSize = 9.2f;
                                                       DrawOutlinedText(HUD, FString(s), FVector2D(HeadSc.X - 1, (HeadSc.Y - 7)), FLinearColor(1.0, 0.4980392156862745, 0.0, 1.0), COLOR_BLACK, true);
                                                       
                                                   }
                                               }
                                           }
                                       }
                                    }
                                }
                            }
                            if (Config.ESPMenu.Enemies) {
                                std::wstring numi;

                                if (totalEnemies + totalBots > 0) {
                                    numi = L"PLAYER : [" + std::to_wstring((int)totalEnemies) + L"] "
                                         + L"◈ BOT: [" + std::to_wstring((int)totalBots) + L"]                ";
                                } else {
                                    numi = L"◈ CLEAR ◈";
                                }

                                tslFont->LegacyFontSize = 20;
                                DrawTextcan(HUD, FString(numi), FVector2D(screenWidth / 2, 110), COLOR_GREEN, COLOR_BLACK);
                            }
                            {
                                if(localPlayer) {
                                    if (preferences.Config.SilentAim.AimBot) {
                                        
                                        // Gọi hàm tìm mục tiêu (Đảm bảo hàm này trả về ASTExtraPlayerCharacter*)
                                        ASTExtraPlayerCharacter *Target = GetTargetForAimBotByFOV();
                                        
                                        if (Target) {
                                            // Khai báo UMC (Cần thiết để tính toán góc)
                                            UKismetMathLibrary* UMC = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();

                                            bool triggerOk = false;

                                            float DistanceM = g_LocalPlayer->GetDistanceTo(Target) / 100.0f; // Khoảng cách mét

                                            // Nếu là súng thường (AR/SMG...): Theo cài đặt Menu
                                            if (chedoaim == 0) triggerOk = true; // Luôn Aim
                                            else if (chedoaim == 1) triggerOk = g_LocalPlayer->bIsWeaponFiring;
                                            else if (chedoaim == 2) triggerOk = g_LocalPlayer->bIsGunADS;
                                            else if (chedoaim == 3) triggerOk = g_LocalPlayer->bIsWeaponFiring && g_LocalPlayer->bIsGunADS;
                                            else if (chedoaim == 4) triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;


                                            // --- 3. THỰC HIỆN AIM ---
                                            if (triggerOk) {
                                                FVector targetAimPos = Target->GetBonePos("Head", {}); // Mặc định Head

                                                // Chỉnh vị trí (Head/Neck/Chest...)
                                                if(Istargets == 0) targetAimPos = Target->GetHeadLocation(true);
                                                else if(Istargets == 1) targetAimPos.Z -= 0.5f;
                                                else if(Istargets == 2) targetAimPos.Z -= 30.0f;
                                                else if(Istargets == 3) targetAimPos.Z -= 45.0f;

                                                // PREDICTION (Dự đoán)
                                                if (preferences.Config.SilentAim.Prediction) {
                                                    if (IsValidAddress((kaddr)g_LocalPlayer->WeaponManagerComponent)) {
                                                        auto WeapComp = g_LocalPlayer->WeaponManagerComponent;
                                                        if (IsValidAddress((kaddr)WeapComp->CurrentWeaponReplicated)) {
                                                            auto CurWeap = (ASTExtraShootWeapon*)WeapComp->CurrentWeaponReplicated;
                                                            if (IsValidAddress((kaddr)CurWeap->ShootWeaponComponent)) {
                                                                auto ShootEnt = CurWeap->ShootWeaponComponent->ShootWeaponEntityComponent;
                                                                
                                                                // Check BulletSpeed > 0 để tránh Crash chia cho 0
                                                                if (IsValidAddress((kaddr)ShootEnt) && ShootEnt->BulletFireSpeed > 0) {
                                                                    FVector Velocity = FVector(0,0,0);
                                                                    if (Target->CurrentVehicle) 
                                                                        Velocity = Target->CurrentVehicle->ReplicatedMovement.LinearVelocity;
                                                                    else 
                                                                        Velocity = Target->ReplicatedMovement.LinearVelocity; // Fix crash GetVelocity

                                                                    float DistRaw = g_LocalPlayer->GetDistanceTo(Target);
                                                                    float Time = DistRaw / ShootEnt->BulletFireSpeed;
                                                                    targetAimPos = UMC->Add_VectorVector(targetAimPos, UMC->Multiply_VectorFloat(Velocity, Time));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                // RECOIL CONTROL
                                                if (g_LocalPlayer->bIsWeaponFiring && IsAimBotRecc > 0) {
                                                    targetAimPos.Z -= DistanceM * IsAimBotRecc;
                                                }

                                                // TÍNH TOÁN GÓC & DI CHUYỂN TÂM
                                                FVector CamLoc = g_PlayerController->PlayerCameraManager->CameraCache.POV.Location;
                                                FRotator CamRot = g_PlayerController->PlayerCameraManager->CameraCache.POV.Rotation;
                                                
                                                FVector fDir = UMC->Subtract_VectorVector(targetAimPos, CamLoc);
                                                FRotator AimRot = UMC->Conv_VectorToRotator(fDir);

                                                // Tính Delta
                                                FRotator Delta;
                                                Delta.Pitch = AimRot.Pitch - CamRot.Pitch;
                                                Delta.Yaw = AimRot.Yaw - CamRot.Yaw;
                                                Delta.Roll = 0.f;

                                                // Chuẩn hóa góc (Rất quan trọng)
                                                IMGUI_GOD(Delta);

                                                // Di chuyển tâm (Aim)
                                                if (AimBotSpeed > 0) {
                                                    g_LocalPlayer->AddControllerYawInput(Delta.Yaw / AimBotSpeed);    
                                                    g_LocalPlayer->AddControllerPitchInput(Delta.Pitch / AimBotSpeed);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                UGameplayStatics* gGameplayStatics = (UGameplayStatics*)UGameplayStatics::StaticClass();
                
                if (Config.ESPMenu.GrenadeWarning) {
                    std::vector<ASTExtraGrenadeBase*> GrenadeBase;
                    GetAllActors(GrenadeBase);

                    for (auto Grenade : GrenadeBase)
                    {
                        if (!Grenade) {
                            continue;
                        }

                        if (Grenade->ItemDefineID.TypeSpecificID == 602002) {
                            continue;
                        }

                        auto GrenadeWorldLocation = Grenade->K2_GetActorLocation(); 
                        
                        float gDistance = Grenade->GetDistanceTo(localPlayer) / 100.f;

                        if (gDistance <= 100.f) {

                            tslFont->LegacyFontSize = max(6, 15 - (int)(gDistance / 100.f));
                            float txtWidth, txtHeight;
                            std::wstring grenadetext = (L"<BOOM>");

                            HUD->GetTextSize(grenadetext, tslFont, 1.f, &txtWidth, &txtHeight);
                            FVector2D Location;
                            if (W2S(GrenadeWorldLocation, &Location)) {
                                DrawOutlinedText(HUD, FString(grenadetext),
                                                 FVector2D(Location.X, Location.Y + 34),
                                                 COLOR_RED, COLOR_BLACK, true);
                            }
                            tslFont->LegacyFontSize = TSL_FONT_DEFAULT_SIZE;

                            if (gDistance < 10) {
                                std::wstring gwarn;
                                gwarn = std::wstring(L"! RUN !");
                                tslFont->LegacyFontSize = 40;
                                DrawOutlinedText(HUD, FString(gwarn),
                                                 FVector2D(screenWidth / 2, screenHeight / 2 - 100),
                                                 COLOR_RED, COLOR_BLACK, true);
                                tslFont->LegacyFontSize = TSL_FONT_DEFAULT_SIZE;
                            }

                            FVector bbOrigin = GrenadeWorldLocation;
                            FVector bbExtends(10, 10, 10);
                            FVector bbExtends2(10, 10, 3);

                            bbOrigin -= bbExtends / 2;
                            FVector one = bbOrigin;
                            FVector two = bbOrigin; two.X += bbExtends.X;
                            FVector three = bbOrigin; three.X += bbExtends.X; three.Y += bbExtends.Y;
                            FVector four = bbOrigin; four.Y += bbExtends.Y;
                            
                            FVector five = one; five.Z += bbExtends.Z;
                            FVector six = two; six.Z += bbExtends.Z;
                            FVector seven = three; seven.Z += bbExtends.Z;
                            FVector eight = four; eight.Z += bbExtends.Z;

                            FVector2D s1, s2, s3, s4, s5, s6, s7, s8, sgiua;
                            FVector2D grenadePos;

                            FVector bbOrigin2 = GrenadeWorldLocation;
                            bbOrigin2 -= bbExtends2 / 2;
                            FVector giua = bbOrigin2; giua.X += bbExtends2.X;
                            
                            if (W2S(one, &s1) && W2S(two, &s2) && W2S(three, &s3) && W2S(four, &s4) &&
                                W2S(five, &s5) && W2S(six, &s6) && W2S(seven, &s7) && W2S(eight, &s8) &&
                                W2S(giua, &sgiua) && W2S(GrenadeWorldLocation, &grenadePos))
                            {

                                DrawLine(HUD, s1, s2, 1.3f, COLOR_RED);
                                DrawLine(HUD, s2, s3, 1.3f, COLOR_RED);
                                DrawLine(HUD, s3, s4, 1.3f, COLOR_RED);
                                DrawLine(HUD, s4, s1, 1.3f, COLOR_RED);
                                DrawLine(HUD, s5, s6, 1.3f, COLOR_RED);
                                DrawLine(HUD, s6, s7, 1.3f, COLOR_RED);
                                DrawLine(HUD, s7, s8, 1.3f, COLOR_RED);
                                DrawLine(HUD, s8, s5, 1.3f, COLOR_RED);
                                DrawLine(HUD, s1, s5, 1.3f, COLOR_RED);
                                DrawLine(HUD, s2, s6, 1.3f, COLOR_RED);
                                DrawLine(HUD, s3, s7, 1.3f, COLOR_RED);
                                DrawLine(HUD, s4, s8, 1.3f, COLOR_RED);
                            }
                        }
                    }
                    GrenadeBase.clear();
                }
            }
            g_LocalPlayer = localPlayer;
            g_PlayerController = localPlayerController;
        }
    }
}

std::wstring NStoWS ( NSString* Str )
{
    NSStringEncoding pEncode    =   CFStringConvertEncodingToNSStringEncoding ( kCFStringEncodingUTF32LE );
    NSData* pSData              =   [ Str dataUsingEncoding : pEncode ];
    return std::wstring ( (wchar_t*) [ pSData bytes ], [ pSData length] / sizeof ( wchar_t ) );
}
NSString* WStoNS ( const std::wstring& Str )
{
    NSString* pString = [ [ NSString alloc ]
                          initWithBytes : (char*)Str.data()
                          length : Str.size() * sizeof(wchar_t)
                          encoding : CFStringConvertEncodingToNSStringEncoding ( kCFStringEncodingUTF32LE ) ];
    return pString;
}
    
void *(*oProcessEvent)(UObject *pObj, UFunction *pFunc, void *pArgs);
void *hkProcessEvent(UObject *pObj, UFunction *pFunc, void *pArgs) {
    if (pFunc) {
        if (pFunc->GetFullName() == ("Function Engine.HUD.ReceiveDrawHUD") ){
            AHUD *pHUD = (AHUD *) pObj;
            if (pHUD) {
                auto Params = (AHUD_ReceiveDrawHUD_Params *) pArgs;
                if (Params) {
                    RenderESP(pHUD, Params->SizeX, Params->SizeY);
                    screenWidth = Params->SizeX;
                    screenHeight = Params->SizeY;
                }
            }
        }
    }
    return oProcessEvent(pObj, pFunc, pArgs);
}


void  *RTL_language() {
    
    auto MAIN =(FUObjectArray *) (obbbbl());
    auto gobjects = MAIN->ObjObjects;
    for (int i=0;i< gobjects.Num(); i++)
    if (auto obj = gobjects.GetByIndex(i)) {
        if(obj->IsA(AHUD::StaticClass())) {
            auto HUD = (AHUD *) obj;
            int its = 76;
            auto VTable = (void**)HUD->VTable;
            if (VTable && ( VTable[its] != hkProcessEvent)) {
                oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                VTable[its] = (void *) hkProcessEvent;
            }
        }
        if(obj->IsA(ASTExtraPlayerController::StaticClass())) {
            auto HUD = (ASTExtraPlayerController *) obj;
            int its = 76;
            auto VTable = (void**)HUD->VTable;
            if (VTable && ( VTable[its] != hkProcessEvent)) {
                oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                VTable[its] = (void *) hkProcessEvent;
            }
        }
    }
    return 0;
}

#define hook GaYSSS9aAL


#define hook GaYSSS9aAL



+ (void)load
{
        FName::GNames = GetGNames();
    while (!FName::GNames) {
        FName::GNames = GetGNames();
          sleep(1);
    }
    
    
    UObject::GUObjectArray = (FUObjectArray *) (obbbbl());
    
    while (!UObject::GUObjectArray) {
    UObject::GUObjectArray = (FUObjectArray *) (obbbbl());
          sleep(1);
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    

          [self load1];
        
    });
}
+ (void)load1
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        RTL_language();
    });
}
__attribute__((constructor)) void _init() {
    pthread_t t;

}

@end