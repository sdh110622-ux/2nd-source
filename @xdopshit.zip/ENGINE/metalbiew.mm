#import "ESP/metalbiew.h"
#import "ESP/mahoa.h"
#include "sys/mman.h"
#include "ESP/Tools.h"
#import <AVFoundation/AVFoundation.h>
#include <stdio.h>
#include <stdint.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "authcheatbot/FTNotificationIndicator.h"
#import "authcheatbot/FCUUID.h"
#import "authcheatbot/menuButtonConfigLQ.h"
#import "authcheatbot/MBProgressHUD.h"
#import "authcheatbot/Reachability.h"
#include "ESP/Icon.h"
#include "ESP/Iconcpp.h"
#include "ESP/ico_font.h"
#include <string>
#include <stdio.h>
#include <string.h>
#include "ESP/Vector3.hpp"
#include "ESP/Vector2.hpp"
#import <Foundation/Foundation.h>
#import "ESP/UE4.h"
#import "ESP/PubgLoad.h"
#import "ESP/ini_rw.h"
#include "ESP/imgui_notify.h"
#include "ESP/tahoma.h"
#include "ESP/Include.h"
#import "PatchNonJB/PatchNonJB.h"
#import "ESP/ImageData.h"
#include "ESP/imgui/stb_image.h"
#import <UIKit/UIKit.h>

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
NSString *xrpb = NSSENCRYPT("Paste Key...");
#define E(str) _xor_(str).c_str()

NSString *bundle;
uint64_t GUObjectArray;
uint64_t GNameFun;

@interface metalbiew () <MTKViewDelegate>
@property (nonatomic, strong) IBOutlet MTKView *mtkView;
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

bool ESPPlayer = false;
bool ShowFov = false;
bool isAimvisual = true;
bool WideView = false;
bool Crosshair = false;
int smoothIndex = 2;
int Istargets = 2;
int WideValue = 100;
float IsAimBotRecc = 1.183f;
float AimBotSpeed = 10.0f;
static int chedoaim = 4;

static uintptr_t Get_module_base() {
    uint32_t count = _dyld_image_count();
    for (int i = 0; i < count; i++) {
        std::string path = (const char *)_dyld_get_image_name(i);
        if (path.find("ShadowTrackerExtra.app/ShadowTrackerExtra") != path.npos) {
            return (uintptr_t)_dyld_get_image_vmaddr_slide(i);
        }
    }
    return 0;
}

bool IsValidAddress(kaddr addr) {
    return addr > 0x100000000 && addr < 0x2000000000;
}

uintptr_t UE4;
kaddr module = (unsigned long)Get_module_base();

namespace Options {
    int boxtype = 1;
    int healthbartype = 0;
    int Nationtype = 2;
    int DirectionLineSize = 70;
    int VehicleDirectionLineSize = 100;
    int offscreen_range = 40;
    int max_distance_offscreen = 400;
    int playersdistancessize = 600;
    bool esp_Outline = true;
    int distance_Radar = 150;
}

enum EAimTarget { Head = 0, Chest = 1 };
enum EAimTrigger { None = 0, Shooting = 1, Scoping = 2, Both = 3, Any = 4 };

using namespace std;
using namespace SDK;

struct sConfig {
    struct sESPMenu {
        bool Enemies = false;
        bool Line = false;
        bool Box = false;
        bool Skeleton = false;
        bool Health = false;
        bool Name = false;
        bool Distance = false;
        bool TeamID = false;
        bool State = false;
        bool Weapon = false;
        bool Alert = false;
        bool HideBot = false;
        bool GrenadeWarning = false;
    };
    sESPMenu ESPMenu;
};
sConfig Config;

struct JsonPreferences {
    struct sConfig {
        struct sAimMenu {
            bool AimBot = false;
            bool IgnoreKnocked = false;
            bool IgnoreBot = false;
            bool VisCheck = false;
            bool Prediction = false;
            bool InstantHit = false;
            bool Recoil = false;
            float RecoilRate = 1.0f;
            float Fov = 100;
        };
        sAimMenu SilentAim;
    };
    sConfig Config;
} preferences;

UISlider * Auto1;
UISlider * Auto1Interval;
UISlider * sliderrr;
UISlider * aimspeed;
CGSize AutoFireCircelSize;
bool IsAirDrop = false;
int Interval = 1;
int counter;
int iAwareTexSiz = 20;
bool iAwareText = true;
int EspTextSiz = 9;
float EspBoxThik = 1.5f;
float EspSktonThik = 1.5f;
float IsfovSlider = 150.0f;
float AimSmooth = 5.0f;
float EspDistance = 250.0f;
bool AimTouch = false;
bool antibypass = false;
float AimBotDistance = 20.0f;

int boxtype = 1;
int healthbartype = 0;
int Nationtype = 2;
int DirectionLineSize = 70;
int VehicleDirectionLineSize = 100;
int offscreen_range = 40;
int max_distance_offscreen = 400;
int playersdistancessize = 600;
bool esp_Outline = true;
int distance_Radar = 150;

int g_screenWidth ;
int g_screenHeight ;
int screenWidth ;
int screenHeight ;
int screenDensity = 0;
int getEspFramerate;
int SCOLOR;
int scc;

float density = -1;
float gDistance;
int localFiring{0};
BOOL kaiguan1 = NO;
BOOL kaiguan2 = NO;
BOOL kaiguan3 = NO;
BOOL kaiguan4 = NO;
#define PI 3.14159265358979323846
#define __fastcall

float aimspeedsl() { return 20; }
int aimpos() { return 25; }
int autodiss() { return Auto1.value; }

@implementation metalbiew
INI* config;
bool MenDeal;

- (MTKView *)mtkView { return (MTKView *)self.view; }

- (void)loadView {
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
}

id<MTLTexture> CreateTextureFromMemory(id<MTLDevice> device, const void* data, size_t dataSize) {
    if (!data || dataSize <= 0) return nil;
    NSData *nsData = [NSData dataWithBytes:data length:dataSize];
    if (!nsData) return nil;
    MTKTextureLoader *loader = [[MTKTextureLoader alloc] initWithDevice:device];
    NSError *error = nil;
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    id<MTLTexture> texture = [loader newTextureWithData:nsData options:options error:&error];
    if (error) return nil;
    return texture;
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"ENGINE.ini"];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:[NSData data] attributes:nil];
    }
    config = ini_load((char*)filePath.UTF8String);
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    if (!self.device) abort();
    
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 15.0f;
    style.ChildRounding = 12.0f;
    style.FrameRounding = 10.0f;
    style.PopupRounding = 10.0f;
    style.ScrollbarRounding = 10.0f;
    style.GrabRounding = 10.0f;
    
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    style.Colors[ImGuiCol_ChildBg]  = ImVec4(0.05f, 0.05f, 0.05f, 0.50f);
    style.Colors[ImGuiCol_Border]   = ImVec4(0.15f, 0.15f, 0.15f, 0.50f);
    style.Colors[ImGuiCol_Button]   = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.18f, 0.18f, 0.18f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive]  = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.60f, 0.00f, 0.80f, 1.00f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.50f, 0.00f, 0.70f, 1.00f);

    ImFontConfig font_cfg;
    font_cfg.FontDataOwnedByAtlas = false;
    NSString *FontPath = @"/System/Library/Fonts/Core/AvenirNext.ttc";
    io.ConfigWindowsMoveFromTitleBarOnly = true;
    io.Fonts->AddFontFromFileTTF(FontPath.UTF8String, 15.0f, &font_cfg, io.Fonts->GetGlyphRangesVietnamese());
    ImGui::MergeIconsWithLatestFont(17.f, false);
    ImGui_ImplMetal_Init(_device);
    return self;
}

static auto start = std::chrono::steady_clock::now();
namespace Settings { static int Tab = 1; }
namespace Setting { static int Tabs = 1; }

static bool callFunction = false;
namespace Variables { int ActiveTab = 1; }

int aimbotIntensity = 2;
bool callNotify = false;

- (void)drawInMTKView:(MTKView*)view {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    [self readIniConfig];

    CGFloat framebufferScale = view.window.screen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    
    [self.view setUserInteractionEnabled:MenDeal];
    
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@""];
        
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(480, 300), ImGuiCond_FirstUseEver);

        if (MenDeal) {
            ImGui::SetNextWindowSize(ImVec2(650, 350), ImGuiCond_Always); 
            ImGui::Begin("DUCK_MENU", &MenDeal, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);

            // SIDEBAR
            ImGui::BeginGroup();
            ImVec2 iconBtnSize = ImVec2(45, 45); 
            if (ImGui::Button(ICON_FA_HOME, iconBtnSize)) Settings::Tab = 1; ImGui::Spacing();
            if (ImGui::Button(ICON_FA_EYE, iconBtnSize)) Settings::Tab = 2; ImGui::Spacing();
            if (ImGui::Button(ICON_FA_CROSSHAIRS, iconBtnSize)) Settings::Tab = 3; ImGui::Spacing();
            if (ImGui::Button(ICON_FA_BAN, iconBtnSize)) Settings::Tab = 4;
            ImGui::EndGroup();
            ImGui::SameLine();

            // MAIN CONTENT
            ImGui::BeginGroup();
            ImGui::BeginChild("MainContent", ImVec2(380, 0), false); 
            ImGui::Spacing();
            ImGui::SetWindowFontScale(1.2f);
            
            if (Settings::Tab == 1) ImGui::TextColored(ImVec4(1.0f, 0.84f, 0.0f, 1.0f), "CHÀO MỪNG NGƯỜI CHƠI, DUCK"); 
            else if (Settings::Tab == 2) ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "CÀI ĐẶT HIỂN THỊ - VISUAL"); 
            else if (Settings::Tab == 3) ImGui::TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), "HỖ TRỢ CHIẾN ĐẤU - AIMBOT"); 
            else if (Settings::Tab == 4) ImGui::TextColored(ImVec4(0.5f, 1.0f, 0.5f, 1.0f), "CHỨC NĂNG HỆ THỐNG - MISC"); 
            
            ImGui::SetWindowFontScale(1.0f);

            if (Settings::Tab == 1) {
                std::string namedv = [[UIDevice currentDevice] name].UTF8String;
                ImGui::Text("Thiết bị: %s", namedv.c_str());
                ImGui::Text("Tốc độ khung hình: %.1f FPS", ImGui::GetIO().Framerate);
            }
            else if (Settings::Tab == 2) {
                if (ImGui::Checkbox(("Player"), &ESPPlayer)) configManager::putBoolean(config, "playerSwitch", "esp", ESPPlayer);
                if (ESPPlayer) {
                    ImGui::Columns(2, NULL, false);
                    if (ImGui::Checkbox(("Line"), &Config.ESPMenu.Line)) configManager::putBoolean(config, "playerSwitch", "line", Config.ESPMenu.Line);
                    if (ImGui::Checkbox(("Health"), &Config.ESPMenu.Health)) configManager::putBoolean(config, "playerSwitch", "health", Config.ESPMenu.Health);
                    if (ImGui::Checkbox(("Bone"), &Config.ESPMenu.Skeleton)) configManager::putBoolean(config, "playerSwitch", "bone", Config.ESPMenu.Skeleton);
                    if (ImGui::Checkbox(("Radar 360"), &Config.ESPMenu.Alert)) configManager::putBoolean(config, "playerSwitch", "radar360", Config.ESPMenu.Alert);
                    ImGui::NextColumn();
                    if (ImGui::Checkbox(("Box"), &Config.ESPMenu.Box)) configManager::putBoolean(config, "playerSwitch", "box", Config.ESPMenu.Box);
                    if (ImGui::Checkbox(("Name"), &Config.ESPMenu.Name)) configManager::putBoolean(config, "playerSwitch", "name", Config.ESPMenu.Name);
                    if (ImGui::Checkbox(("Distance"), &Config.ESPMenu.Distance)) configManager::putBoolean(config, "playerSwitch", "distance", Config.ESPMenu.Distance);
                    if (ImGui::Checkbox(("Status"), &Config.ESPMenu.Weapon)) configManager::putBoolean(config, "playerSwitch", "status", Config.ESPMenu.Weapon);
                    if (ImGui::Checkbox(("Ignore Bot"), &Config.ESPMenu.HideBot)) configManager::putBoolean(config, "playerSwitch", "ignorebot", Config.ESPMenu.HideBot);
                    ImGui::Columns(1);
                }
            }
            else if (Settings::Tab == 3) {
                ImGui::Spacing();
                ImGui::TextColored(ImVec4(0, 1, 1, 1), ICON_FA_CROSSHAIRS " AIMBOT SETTINGS");
                if (ImGui::Checkbox("AIMBOT", &preferences.Config.SilentAim.AimBot)) configManager::putBoolean(config, "SilentAim", "AimBot", preferences.Config.SilentAim.AimBot);
                if (preferences.Config.SilentAim.AimBot) {
                    ImGui::SameLine(175);
                    if (ImGui::Checkbox("SHOW FOV", &ShowFov)) configManager::putBoolean(config, "SilentAim", "ShowFov", ShowFov);
                    if (ImGui::Checkbox("IGNORE KNOCK", &preferences.Config.SilentAim.IgnoreKnocked)) configManager::putBoolean(config, "SilentAim", "IgnoreKnocked", preferences.Config.SilentAim.IgnoreKnocked);
                    ImGui::SameLine(175);
                    if (ImGui::Checkbox("IGNORE BOT", &preferences.Config.SilentAim.IgnoreBot)) configManager::putBoolean(config, "SilentAim", "IgnoreBot", preferences.Config.SilentAim.IgnoreBot);
                    
                    const char *chedoaimm[5] = {"AIM LOOK", "FIRE", "SCOPE", "FIRE + SCOPE", "AUTO AIM"};
                    if (ImGui::Combo("MODE", &chedoaim, chedoaimm, IM_ARRAYSIZE(chedoaimm))) configManager::putInteger(config, "SilentAim", "AimMode", chedoaim);
                    
                    const char *targets[4] = {"HEAD", "NECK", "BODY", "BELLY"};
                    if (ImGui::Combo("TARGET", &Istargets, targets, IM_ARRAYSIZE(targets))) configManager::putInteger(config, "SilentAim", "AimTarget", Istargets);
                    
                    const char* smoothList[] = { "SAFE", "SLOW", "MEDIUM", "FAST", "RICK" };
                    if (ImGui::Combo("AIM SPEED", &smoothIndex, smoothList, IM_ARRAYSIZE(smoothList))) {
                        switch (smoothIndex) {
                            case 0: AimBotSpeed = 15.0f; break;
                            case 1: AimBotSpeed = 10.0f;  break;
                            case 2: AimBotSpeed = 7.0f;  break;
                            case 3: AimBotSpeed = 3.0f;  break;
                            case 4: AimBotSpeed = 2.0f;  break;
                        }
                        configManager::putInteger(config, "SilentAim", "SmoothIndex", smoothIndex);
                        configManager::putFloat(config, "SilentAim", "Smooth", AimBotSpeed);
                    }
                    if (ShowFov) {
                        if (ImGui::SliderFloat("FOV", &preferences.Config.SilentAim.Fov, 0.0f, 500.0f, "%.0f")) configManager::putFloat(config, "SilentAim", "FovValue", preferences.Config.SilentAim.Fov);
                    }
                    if (ImGui::SliderFloat("DISTANCE", &AimBotDistance, 0.0f, 300.0f, "%.0f")) configManager::putFloat(config, "SilentAim", "Distance", AimBotDistance);
                    if (ImGui::SliderFloat("MACRO", &IsAimBotRecc, 0.0f, 3.0f, "%.1f")) configManager::putFloat(config, "SilentAim", "Recoil", IsAimBotRecc);
                }
            }
            else if (Settings::Tab == 4) {
                ImGui::Checkbox("iPad View", &WideView);
                if (WideView) ImGui::SliderInt("TPP", &WideValue, 50, 150);
            }

            ImGui::EndChild();
            ImGui::EndGroup();
            ImGui::SameLine();

            // RIGHT COLUMN
            ImGui::BeginGroup();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.8f, 0.0f, 1.0f)); 
            ImGui::Button("DUCK-IOS", ImVec2(130, 40)); 
            ImGui::PopStyleColor();
            ImGui::SameLine(0, 5);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
            if (ImGui::Button("X", ImVec2(45, 40))) MenDeal = false;
            ImGui::PopStyleColor();
            ImGui::Spacing();

            if (Settings::Tab == 1) {
                ImGui::BeginChild("ScrollableButtons", ImVec2(175, 0), false, ImGuiWindowFlags_NoScrollbar);
                ImVec2 sideBtnSize = ImVec2(165, 45); 
                ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f); 
                ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 6)); 
                ImGui::SetWindowFontScale(0.9f);
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.35f, 0.0f, 0.5f, 1.0f)); if (ImGui::Button(ICON_FA_EYE " VISUAL", sideBtnSize)) Settings::Tab = 2; ImGui::PopStyleColor();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.0f, 0.45f, 1.0f)); if (ImGui::Button(ICON_FA_CROSSHAIRS " AIMBOT", sideBtnSize)) Settings::Tab = 3; ImGui::PopStyleColor();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.0f, 0.40f, 1.0f)); if (ImGui::Button(ICON_FA_COG " MEMORY", sideBtnSize)) Settings::Tab = 4; ImGui::PopStyleColor();
                ImGui::SetWindowFontScale(1.0f);
                ImGui::PopStyleVar(2); 
                ImGui::EndChild();
            } else {
                ImGui::BeginChild("ImageRegion", ImVec2(180, 0), false, ImGuiWindowFlags_NoScrollbar);
                static id<MTLTexture> tex_visual = nil;
                static id<MTLTexture> tex_aimbot = nil;
                static id<MTLTexture> tex_misc = nil;
                ImVec2 imgSize = ImVec2(165, 230); 
                ImVec2 p = ImGui::GetCursorScreenPos();
                id<MTLTexture> current_tex = nil;

                if (Settings::Tab == 2) { if (!tex_visual) tex_visual = CreateTextureFromMemory(self.device, img_visual_data, sizeof(img_visual_data)); current_tex = tex_visual; } 
                else if (Settings::Tab == 3) { if (!tex_aimbot) tex_aimbot = CreateTextureFromMemory(self.device, img_aimbot_data, sizeof(img_aimbot_data)); current_tex = tex_aimbot; }
                else if (Settings::Tab == 4) { if (!tex_misc) tex_misc = CreateTextureFromMemory(self.device, img_misc_data, sizeof(img_misc_data)); current_tex = tex_misc; }

                if (current_tex) {
                    ImGui::GetWindowDrawList()->AddImageRounded((__bridge void*)current_tex, p, ImVec2(p.x + imgSize.x, p.y + imgSize.y), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 15.0f);
                    ImGui::Dummy(imgSize); 
                }
                ImGui::EndChild();
            }
            ImGui::EndGroup();
            ImGui::End();
        }
        
        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
    }
    [commandBuffer commit];         
}

-(void) readIniConfig {
    ESPPlayer = configManager::readBoolean(config,"playerSwitch", "esp", false);
    Config.ESPMenu.HideBot = configManager::readBoolean(config,"playerSwitch", "ignorebot", false);
    Config.ESPMenu.Name = configManager::readBoolean(config,"playerSwitch", "name", false);
    Config.ESPMenu.Health = configManager::readBoolean(config,"playerSwitch", "health", false);
    Config.ESPMenu.Skeleton = configManager::readBoolean(config,"playerSwitch", "bone", false);
    Config.ESPMenu.Distance = configManager::readBoolean(config,"playerSwitch", "distance", false);
    Config.ESPMenu.Box = configManager::readBoolean(config,"playerSwitch", "box", false);
    Config.ESPMenu.Line = configManager::readBoolean(config,"playerSwitch", "line", false);
    Config.ESPMenu.Weapon = configManager::readBoolean(config,"playerSwitch", "status", false);
    Config.ESPMenu.Alert = configManager::readBoolean(config,"playerSwitch", "radar360", false);
    
    preferences.Config.SilentAim.AimBot        = configManager::readBoolean(config, "SilentAim", "AimBot", false);
    ShowFov                                    = configManager::readBoolean(config, "SilentAim", "ShowFov", false);
    preferences.Config.SilentAim.IgnoreKnocked = configManager::readBoolean(config, "SilentAim", "IgnoreKnocked", false);
    preferences.Config.SilentAim.IgnoreBot     = configManager::readBoolean(config, "SilentAim", "IgnoreBot", false);
    chedoaim   = configManager::readInteger(config, "SilentAim", "AimMode", 0);
    Istargets  = configManager::readInteger(config, "SilentAim", "AimTarget", 0);
    preferences.Config.SilentAim.Fov  = configManager::readFloat(config, "SilentAim", "FovValue", 200.0f);
    AimBotDistance   = configManager::readFloat(config, "SilentAim", "Distance", 150.0f);
    IsAimBotRecc = configManager::readFloat(config, "SilentAim", "Recoil", 1.0f);
    smoothIndex = configManager::readInteger(config, "SilentAim", "SmoothIndex", 2);

    switch (smoothIndex) {
        case 0: AimBotSpeed = 15.0f; break;
        case 1: AimBotSpeed = 10.0f;  break;
        case 2: AimBotSpeed = 7.0f;  break;
        case 3: AimBotSpeed = 3.0f;  break;
        case 4: AimBotSpeed = 2.0f;  break;
    }
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) { hasActiveTouch = YES; break; }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self updateIOWithTouchEvent:event]; }

#pragma esp method ------------------------------------------------------------------------------------

typedef uintptr_t kaddr;
using namespace std;
using namespace SDK;

kaddr getRealOffset(kaddr offset){
    return (unsigned long)Get_module_base()+offset;
}

long obbbbl() {
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *BundID = [infoDictionary objectForKey:@"CFBundleIdentifier"];
    if([BundID containsString:@"com.tencent.ig"]){ return getRealOffset(0x10A288B80); }
    if([BundID containsString:@"pubg.krmobile"]){ return getRealOffset(0x10A49C000); }
    if([BundID containsString:@"rekoo"]){ return getRealOffset(0x10A47AF00); }
    if([BundID containsString:@"vn.vng.pubgmobile"]){ return getRealOffset(0x10A692D18); }
    if([BundID containsString:@"imobile"]){ return getRealOffset(0x109ABC718); } // Updated Offset
    return 0;
};

UWorld *GEWorld;
int GWorldNum = 0;
TUObjectArray gobjects;

UWorld *GetFullWorld() {
    if(GWorldNum == 0) {
        if (!UObject::GUObjectArray) return 0;
        gobjects = UObject::GUObjectArray->ObjObjects;
        for (int i=0; i< gobjects.Num(); i++)
            if (auto obj = gobjects.GetByIndex(i)) {
                if(obj->IsA(UEngine::StaticClass())) {
                    auto GEngine = (UEngine *) obj;
                    if(GEngine && GEngine->GameViewport) {
                        GEWorld = GEngine->GameViewport->World;
                        GWorldNum = i;
                        return GEWorld;
                    }
                }
            }
    } else {
        auto GEngine = (UEngine *) (gobjects.GetByIndex(GWorldNum));
        if(GEngine && GEngine->GameViewport) {
            GEWorld = GEngine->GameViewport->World;
            return GEWorld;
        }
    }
    return 0;
}

TNameEntryArray *GetGNames() {
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *BundID = [infoDictionary objectForKey:@"CFBundleIdentifier"];
    if([BundID containsString:@"com.tencent.ig"]){ return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104C0F1E8))(); }
    if([BundID containsString:@"pubg.krmobile"]){ return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104DD2100))(); }
    if([BundID containsString:@"rekoo"]){ return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104DAB6C4))(); }
    if([BundID containsString:@"vn.vng.pubgmobile"]){ return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104FD0B5C))(); }
    if([BundID containsString:@"imobile"]){ return ((TNameEntryArray *(*)()) ((unsigned long)Get_module_base() + 0x104734D98))(); } // Updated Offset
    return 0;
}

template <class T> void GetAllActors(std::vector<T*>& Actors) {
    UGameplayStatics* gGameplayStatics = (UGameplayStatics*)UGameplayStatics::StaticClass();
    auto GWorld = GetFullWorld();
    if (GWorld) {
        TArray<AActor*> Actors2;
        gGameplayStatics->GetAllActorsOfClass((UObject*)GWorld, T::StaticClass(), &Actors2);
        for (int i = 0; i < Actors2.Num(); i++) {
            Actors.push_back((T*)Actors2[i]);
        }
    }
}

FVector GetBoneLocationByName(ASTExtraPlayerCharacter *Actor, const struct FName BoneName) {
    return Actor->GetBonePos(BoneName, FVector());
}

#define TSL_FONT_DEFAULT_SIZE 20
static UFont *robotoFont = 0, *robotoTinyFont = 0, *tslFont = 0;

void DrawOutlinedText(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = false) {
    UCanvas *Canvas = HUD->Canvas;
    if (Canvas && tslFont) Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void DrawTextcan(AHUD *HUD, FString Text, FVector2D Pos, FLinearColor Color, FLinearColor OutlineColor, bool isCenter = true) {
    UCanvas *Canvas = HUD->Canvas;   
    if (Canvas && tslFont) Canvas->K2_DrawText(tslFont, Text, Pos, Color, 1.f, {}, {}, isCenter, isCenter, true, OutlineColor);
}

void *LoadFont() {
    while (!robotoFont || !robotoTinyFont || !tslFont) {
        tslFont = UObject::FindObject<UFont>("Font TSLFont.TSLFont");
        robotoFont = UObject::FindObject<UFont>("Font Roboto.Roboto");
        robotoTinyFont = UObject::FindObject<UFont>("Font RobotoTiny.RobotoTiny");
        sleep(1);
    }
    return 0;
}

ASTExtraPlayerController *g_PlayerController;
ASTExtraPlayerCharacter *g_LocalPlayer;
#define COLOR_WHITE FLinearColor(1.f, 1.f, 1.f, 1.f)
#define COLOR_GREEN FLinearColor(0, 0.5f, 0, 1.f)
#define COLOR_BLACK FLinearColor(0, 0, 0, 1.f)
#define COLOR_RED   FLinearColor(1.f, 0, 0, 1.f)

void DrawLine(AHUD *HUD, FVector2D posFrom, FVector2D posTo, float Thickness, FLinearColor Color) {
    HUD->DrawLine(posFrom.X, posFrom.Y, posTo.X, posTo.Y, Color, Thickness);
}

void DrawCircle(AHUD *HUD, int x, int y, int radius, int numsides, FLinearColor OutlineColor) {
    float Step = M_PI * 2.0 / numsides;
    int Count = 0;
    FVector2D V[128];
    for (float a = 0; a < M_PI * 2.0; a += Step) {
        float X1 = radius * cos(a) + x;
        float Y1 = radius * sin(a) + y;
        float X2 = radius * cos(a + Step) + x;
        float Y2 = radius * sin(a + Step) + y;
        V[Count].X = X1; V[Count].Y = Y1;
        V[Count + 1].X = X2; V[Count + 1].Y = Y2;
        HUD->Canvas->K2_DrawLine(FVector2D({ V[Count].X, V[Count].Y }), FVector2D({ X2, Y2 }), 1.5f, OutlineColor);
    }
}

void Box4Line(AHUD *HUD, float thicc, int x, int y, int w, int h, FLinearColor color) {
    int iw = w / 4; int ih = h / 4;
    HUD->DrawLine(x, y, x + iw, y, color, thicc);
    HUD->DrawLine(x + w - iw, y, x + w, y, color, thicc);
    HUD->DrawLine(x, y, x, y + ih, color, thicc);
    HUD->DrawLine(x + w - 1, y, x + w - 1, y + ih, color, thicc);
    HUD->DrawLine(x, y + h, x + iw, y + h, color, thicc);
    HUD->DrawLine(x + w - iw, y + h, x + w, y + h, color, thicc);
    HUD->DrawLine(x, y + h - ih, x, y + h, color, thicc);
    HUD->DrawLine(x + w - 1, y + h - ih, x + w - 1, y + h, color, thicc);
}

#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(g_PlayerController, w, false, s)

UGameplayStatics* iosde = (UGameplayStatics*)UGameplayStatics::StaticClass();
int glWidth, glHeight;

auto GetTargetForAimBotByFOV() {
    UGameplayStatics *GameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
    ASTExtraPlayerCharacter *result = 0;
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;

    auto GWorld = GetFullWorld();
    if (IsValidAddress((kaddr)GWorld)) {
        UNetDriver *NetDriver = GWorld->NetDriver;
        if (IsValidAddress((kaddr)NetDriver)) {
            UNetConnection *ServerConnection = NetDriver->ServerConnection;
            if (IsValidAddress((kaddr)ServerConnection)) {
                localPlayerController = (ASTExtraPlayerController *) ServerConnection->PlayerController;
            }
        }
        
        if (IsValidAddress((kaddr)localPlayerController)) {
            std::vector<ASTExtraPlayerCharacter*> PlayerCharacter;
            GetAllActors(PlayerCharacter);

            if (IsValidAddress((kaddr)localPlayerController->Pawn)) {
                localPlayer = (ASTExtraPlayerCharacter*)localPlayerController->Pawn;
            } else {
                 for (auto actor : PlayerCharacter) {
                    if (actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                        localPlayer = actor; break;
                    }
                }
            }

            if (localPlayer) {
                float max = std::numeric_limits<float>::infinity();
                for (auto Player : PlayerCharacter) {
                    if (!IsValidAddress((kaddr)Player) || !IsValidAddress((kaddr)Player->RootComponent)) continue;
                    
                    float Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                    if(AimBotDistance < Distance || Player->PlayerKey == localPlayer->PlayerKey || Player->TeamID == localPlayer->TeamID || Player->bDead || Player->bHidden) continue;
                    if (!IsValidAddress((kaddr)Player->Mesh)) continue;
                    
                    if (preferences.Config.SilentAim.IgnoreKnocked && Player->Health == 0.0f) continue;
                    if (isAimvisual && !localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true)) continue;
                    if (preferences.Config.SilentAim.IgnoreBot && Player->bEnsure) continue;
                    
                    auto Root = Player->RootComponent->K2_GetComponentLocation();
                    auto Head = Player->GetBonePos(("Head"), FVector());
                    FVector2D RootSc, HeadSc;
                    if (GameplayStatics->ProjectWorldToScreen(g_PlayerController, Root, false, &RootSc) && GameplayStatics->ProjectWorldToScreen(g_PlayerController, Head, false, &HeadSc)) {
                        float height = abs(HeadSc.Y - RootSc.Y);
                        float width = height * 0.65f;
                        FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                        if ((middlePoint.X >= 0 && middlePoint.X <= screenWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= screenHeight)) {
                            FVector2D v2Middle = FVector2D((float) (screenWidth / 2), (float) (screenHeight / 2));
                            FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);
                            if(isInsideFOV((int)middlePoint.X, (int)middlePoint.Y)) {
                                float dist = FVector2D::Distance(v2Middle, v2Loc);
                                if (dist < max) { max = dist; result = Player; }
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

bool isInsideFOV(int x, int y) {
    if (!preferences.Config.SilentAim.Fov) return true;
    int circle_x = screenWidth / 2;
    int circle_y = screenHeight / 2;
    int rad = (int) preferences.Config.SilentAim.Fov * 2.0f;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

void IMGUI_GOD(FRotator &angles) {
    if (angles.Pitch > 180) angles.Pitch -= 360;
    if (angles.Pitch < -180) angles.Pitch += 360;
    if (angles.Pitch < -75.f) angles.Pitch = -75.f;
    else if (angles.Pitch > 75.f) angles.Pitch = 75.f;
    while (angles.Yaw < -180.0f) angles.Yaw += 360.0f;
    while (angles.Yaw > 180.0f) angles.Yaw -= 360.0f;
}

void RenderESP(AHUD *HUD, int ScreenWidth, int ScreenHeight) {
    ASTExtraPlayerCharacter *localPlayer = 0;
    ASTExtraPlayerController *localPlayerController = 0;
    glWidth = ScreenWidth; glHeight = ScreenHeight;
    UCanvas *Canvas = HUD->Canvas;
    if (Canvas) {
        static bool loadFont = false;
        if (!loadFont) { LoadFont(); loadFont = true; }
        if (!robotoFont || !tslFont || !robotoTinyFont) return;
        
        UGameplayStatics *gGameplayStatics = (UGameplayStatics *) UGameplayStatics::StaticClass();
        UKismetMathLibrary* UMC = (UKismetMathLibrary*)UKismetMathLibrary::StaticClass();
        auto GWorld = GetFullWorld();
        if (GWorld) {
            UNetDriver *NetDriver = GWorld->NetDriver;
            if (NetDriver && NetDriver->ServerConnection) {
                localPlayerController = (ASTExtraPlayerController *) NetDriver->ServerConnection->PlayerController;
            }

            if (localPlayerController) {
                std::vector<ASTExtraPlayerCharacter *> PlayerCharacter;
                GetAllActors(PlayerCharacter);
                for (auto actor = PlayerCharacter.begin(); actor != PlayerCharacter.end(); actor++) {
                    auto Actor = *actor;
                    if (Actor->PlayerKey == ((ASTExtraPlayerController *) localPlayerController)->PlayerKey) {
                        localPlayer = Actor; break;
                    }
                }

                if (localPlayer) {
                    if (WideView) {
                        auto ThirdPersonCameraComponent = localPlayer->ThirdPersonCameraComponent;
                        if (ThirdPersonCameraComponent) {
                            *(float *) ((uintptr_t) &ThirdPersonCameraComponent->OrthoWidth - sizeof(float)) = WideValue;
                        }
                    }
                    
                    if(ESPPlayer) {
                        int totalEnemies = 0, totalBots = 0;
                        for (auto Player : PlayerCharacter) {
                            if (!IsValidAddress((kaddr)Player) || !Player->RootComponent) continue;

                            float Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                            if (Distance > EspDistance || Player->PlayerKey == localPlayer->PlayerKey || Player->TeamID == localPlayer->TeamID || Player->bDead || Player->bHidden) continue;
                            if (Config.ESPMenu.HideBot && Player->bEnsure) continue;

                            if (Player->bEnsure) totalBots++; else totalEnemies++;

                            bool IsVisible = localPlayerController->LineOfSightTo(Player, {0, 0, 0}, true);
                            FLinearColor ColorVisible = Player->bEnsure ? COLOR_WHITE : (IsVisible ? COLOR_GREEN : COLOR_RED);
                            FLinearColor ColorVisibles = Player->bEnsure ? COLOR_WHITE : (IsVisible ? COLOR_GREEN : COLOR_RED);

                            if (Player->Health <= 0) { ColorVisibles = {0,0,0,1}; ColorVisible = {0,0,0,1}; }

                            FVector Head = GetBoneLocationByName(Player, "Head"); Head.Z += 12.5f;
                            FVector Root = GetBoneLocationByName(Player, "Root");
                            
                            FVector2D HeadSc, RootSc;
                            if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, Head, false, &HeadSc) &&
                                gGameplayStatics->ProjectWorldToScreen(localPlayerController, Root, false, &RootSc)) {

                                if (Config.ESPMenu.Line) {
                                    auto AboveHead = Player->GetHeadLocation(true); AboveHead.Z += 35.f;
                                    FVector2D AboveHeadSc;
                                    if (gGameplayStatics->ProjectWorldToScreen(localPlayerController, AboveHead, false, &AboveHeadSc)) {
                                        DrawLine(HUD, FVector2D(static_cast<float>(screenWidth / 2), 0), FVector2D(AboveHeadSc.X, AboveHeadSc.Y - 40), 1.5f, ColorVisible);
                                    }
                                }
                                if (Config.ESPMenu.Skeleton) {
                                    FName BoneID[18] = {"Head","neck_01", "spine_03", "spine_02", "spine_01", "pelvis","upperarm_r", "lowerarm_r", "hand_r","upperarm_l", "lowerarm_l", "hand_l","thigh_r", "calf_r", "foot_r","thigh_l", "calf_l", "foot_l"};
                                    FVector2D Bones[18];
                                    bool IsVisBone[18];
                                    for (int i = 0; i < 18; i++) {
                                        FVector BoneID_0 = GetBoneLocationByName(Player, BoneID[i]);
                                        gGameplayStatics->ProjectWorldToScreen(localPlayerController,BoneID_0, false, &Bones[i]);
                                        IsVisBone[i] = localPlayerController->LineOfSightTo(localPlayerController->PlayerCameraManager,BoneID_0, false);
                                    }
                                    FLinearColor BoneColor = Player->bEnsure ? FLinearColor(0,1,1,1) : FLinearColor(0,1,0,1);
                                    DrawCircle(HUD, Bones[0].X, Bones[0].Y, 3, 12, BoneColor);
                                    DrawLine(HUD,Bones[0], Bones[1], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[1], Bones[2], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[2], Bones[3], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[3], Bones[4], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[4], Bones[5], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[1], Bones[6], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[6], Bones[7], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[7], Bones[8], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[1], Bones[9], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[9], Bones[10], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[10], Bones[11], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[5], Bones[12], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[12], Bones[13], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[13], Bones[14], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[5], Bones[15], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[15], Bones[16], EspSktonThik, BoneColor);
                                    DrawLine(HUD,Bones[16], Bones[17], EspSktonThik, BoneColor);
                                }
                                if (Config.ESPMenu.Box) {
                                    float boxHeight = abs(HeadSc.Y - RootSc.Y);
                                    float boxWidth = boxHeight * 0.65f;
                                    FVector2D vBox = FVector2D(HeadSc.X - (boxWidth / 2), HeadSc.Y);
                                    Box4Line(HUD, 1.5f, vBox.X, vBox.Y, boxWidth, boxHeight, ColorVisibles);
                                }
                                if (Config.ESPMenu.Weapon) {
                                    auto WeaponManagerComponent = Player->WeaponManagerComponent;
                                    if (WeaponManagerComponent && WeaponManagerComponent->CurrentWeaponReplicated) {
                                        auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
                                        auto WeaponId = (int)CurrentWeaponReplicated->GetWeaponID();
                                        if (WeaponId) {
                                            std::wstring s = CurrentWeaponReplicated->GetWeaponName().ToWString();
                                            robotoFont->LegacyFontSize = 9.2f;
                                            DrawOutlinedText(HUD, FString(s), FVector2D(HeadSc.X - 1, (HeadSc.Y - 7)), FLinearColor(1.0, 0.498, 0.0, 1.0), COLOR_BLACK, true);
                                        }
                                    }
                                }
                            }
                        }
                        if (Config.ESPMenu.Enemies) {
                            std::wstring numi = (totalEnemies + totalBots > 0) ? L"PLAYER : [" + std::to_wstring(totalEnemies) + L"] ◈ BOT: [" + std::to_wstring(totalBots) + L"]" : L"◈ CLEAR ◈";
                            tslFont->LegacyFontSize = 20;
                            DrawTextcan(HUD, FString(numi), FVector2D(screenWidth / 2, 110), COLOR_GREEN, COLOR_BLACK);
                        }
                        
                        if (preferences.Config.SilentAim.AimBot) {
                            ASTExtraPlayerCharacter *Target = GetTargetForAimBotByFOV();
                            if (Target) {
                                bool triggerOk = false;
                                float DistanceM = g_LocalPlayer->GetDistanceTo(Target) / 100.0f;
                                if (chedoaim == 0) triggerOk = true;
                                else if (chedoaim == 1) triggerOk = g_LocalPlayer->bIsWeaponFiring;
                                else if (chedoaim == 2) triggerOk = g_LocalPlayer->bIsGunADS;
                                else if (chedoaim == 3) triggerOk = g_LocalPlayer->bIsWeaponFiring && g_LocalPlayer->bIsGunADS;
                                else if (chedoaim == 4) triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;

                                if (triggerOk) {
                                    FVector targetAimPos = Target->GetBonePos("Head", {});
                                    if(Istargets == 0) targetAimPos = Target->GetHeadLocation(true);
                                    else if(Istargets == 1) targetAimPos.Z -= 0.5f;
                                    else if(Istargets == 2) targetAimPos.Z -= 30.0f;
                                    else if(Istargets == 3) targetAimPos.Z -= 45.0f;

                                    if (preferences.Config.SilentAim.Prediction) {
                                        if (IsValidAddress((kaddr)g_LocalPlayer->WeaponManagerComponent) && IsValidAddress((kaddr)g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated)) {
                                            auto CurWeap = (ASTExtraShootWeapon*)g_LocalPlayer->WeaponManagerComponent->CurrentWeaponReplicated;
                                            if (IsValidAddress((kaddr)CurWeap->ShootWeaponComponent)) {
                                                auto ShootEnt = CurWeap->ShootWeaponComponent->ShootWeaponEntityComponent;
                                                if (IsValidAddress((kaddr)ShootEnt) && ShootEnt->BulletFireSpeed > 0) {
                                                    FVector Velocity = Target->CurrentVehicle ? Target->CurrentVehicle->ReplicatedMovement.LinearVelocity : Target->ReplicatedMovement.LinearVelocity;
                                                    float DistRaw = g_LocalPlayer->GetDistanceTo(Target);
                                                    targetAimPos = UMC->Add_VectorVector(targetAimPos, UMC->Multiply_VectorFloat(Velocity, DistRaw / ShootEnt->BulletFireSpeed));
                                                }
                                            }
                                        }
                                    }
                                    if (g_LocalPlayer->bIsWeaponFiring && IsAimBotRecc > 0) targetAimPos.Z -= DistanceM * IsAimBotRecc;

                                    FVector CamLoc = g_PlayerController->PlayerCameraManager->CameraCache.POV.Location;
                                    FRotator CamRot = g_PlayerController->PlayerCameraManager->CameraCache.POV.Rotation;
                                    FRotator AimRot = UMC->Conv_VectorToRotator(UMC->Subtract_VectorVector(targetAimPos, CamLoc));

                                    FRotator Delta;
                                    Delta.Pitch = AimRot.Pitch - CamRot.Pitch;
                                    Delta.Yaw = AimRot.Yaw - CamRot.Yaw;
                                    Delta.Roll = 0.f;

                                    IMGUI_GOD(Delta);
                                    if (AimBotSpeed > 0) {
                                        g_LocalPlayer->AddControllerYawInput(Delta.Yaw / AimBotSpeed);    
                                        g_LocalPlayer->AddControllerPitchInput(Delta.Pitch / AimBotSpeed);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            g_LocalPlayer = localPlayer;
            g_PlayerController = localPlayerController;
        }
    }
}

void *(*oProcessEvent)(UObject *pObj, UFunction *pFunc, void *pArgs);
void *hkProcessEvent(UObject *pObj, UFunction *pFunc, void *pArgs) {
    if (pFunc && pFunc->GetFullName() == ("Function Engine.HUD.ReceiveDrawHUD")) {
        AHUD *pHUD = (AHUD *) pObj;
        if (pHUD && pArgs) {
            auto Params = (AHUD_ReceiveDrawHUD_Params *) pArgs;
            RenderESP(pHUD, Params->SizeX, Params->SizeY);
            screenWidth = Params->SizeX;
            screenHeight = Params->SizeY;
        }
    }
    return oProcessEvent(pObj, pFunc, pArgs);
}

void *RTL_language() {
    auto MAIN = (FUObjectArray *)(obbbbl());
    if (!MAIN) return 0;
    auto gobjects = MAIN->ObjObjects;
    for (int i=0; i< gobjects.Num(); i++) {
        if (auto obj = gobjects.GetByIndex(i)) {
            if(obj->IsA(AHUD::StaticClass()) || obj->IsA(ASTExtraPlayerController::StaticClass())) {
                auto HUD = obj;
                int its = 76;
                auto VTable = (void**)HUD->VTable;
                if (VTable && (VTable[its] != hkProcessEvent)) {
                    oProcessEvent = decltype(oProcessEvent)(VTable[its]);
                    VTable[its] = (void *) hkProcessEvent;
                }
            }
        }
    }
    return 0;
}

+ (void)load {
    FName::GNames = GetGNames();
    while (!FName::GNames) { FName::GNames = GetGNames(); sleep(1); }
    
    UObject::GUObjectArray = (FUObjectArray *) (obbbbl());
    while (!UObject::GUObjectArray) { UObject::GUObjectArray = (FUObjectArray *) (obbbbl()); sleep(1); }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self load1];
    });
}

+ (void)load1 {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        RTL_language();
    });
}

__attribute__((constructor)) void _init() {
    pthread_t t;
}

@end