#pragma once

#ifndef _MSC_VER
#ifdef __cplusplus
#define __forceinline inline
#else
#define __forceinline
#endif
#endif

// PUBG (4.3.0) Created by @JokerRepo and for pattern @enen
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class EventTrackEx.MovieSceneXTEventSection
// 0x0110 (0x01C0 - 0x00B0)
class UMovieSceneXTEventSection : public UMovieSceneSection
{
public:
	struct FNameCurve                                  Events;                                                   // 0x00B0(0x0068) (Deprecated)
	struct FMovieSceneXTEventSectionData               EventData;                                                // 0x0118(0x0020)
	unsigned char                                      UnknownData00[0x88];                                      // 0x0138(0x0088) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EventTrackEx.MovieSceneXTEventSection");
		return pStaticClass;
	}

};


// Class EventTrackEx.MovieSceneXTEventTrack
// 0x0020 (0x0078 - 0x0058)
class UMovieSceneXTEventTrack : public UMovieSceneNameableTrack
{
public:
	TArray<struct FMovieSceneObjectBindingID>          EventReceivers;                                           // 0x0058(0x0010) (Edit, ZeroConstructor)
	TArray<class UMovieSceneSection*>                  Sections;                                                 // 0x0068(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EventTrackEx.MovieSceneXTEventTrack");
		return pStaticClass;
	}

};


// Class EventTrackEx.MovieSceneXTQTESection
// 0x0028 (0x00D8 - 0x00B0)
class UMovieSceneXTQTESection : public UMovieSceneSection
{
public:
	struct FString                                     MsgName;                                                  // 0x00B0(0x0010) (Edit, ZeroConstructor)
	TArray<float>                                      Times;                                                    // 0x00C0(0x0010) (Edit, ZeroConstructor)
	EXTQTEOperationArea                                OperationArea;                                            // 0x00D0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00D1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EventTrackEx.MovieSceneXTQTESection");
		return pStaticClass;
	}

};


// Class EventTrackEx.MovieSceneXTQTETrack
// 0x0010 (0x0068 - 0x0058)
class UMovieSceneXTQTETrack : public UMovieSceneTrack
{
public:
	TArray<class UMovieSceneSection*>                  Sections;                                                 // 0x0058(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EventTrackEx.MovieSceneXTQTETrack");
		return pStaticClass;
	}

};


}

