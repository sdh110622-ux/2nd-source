#pragma once

// WE SUPPORT FUN  (4.6.0) SDKGen by @O_N_E_B_I_E_C_E | @onebiecerr 
// Send Message Me For SDKGen Tool  
// Generate on Tue Sep  8 20:35:15 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VoiceText_type.BP_STRUCT_VoiceText_type
// 0x0018
struct FBP_STRUCT_VoiceText_type
{
	int                                                VoiceTextId_0_6FC5DE403E05E86B27664BDF0A63A1A4;           // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     VoiceTextValue_1_0BE5D24055E8B9FB76C1783D0A09E585;        // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

