#pragma once

#ifndef _MSC_VER
#ifdef __cplusplus
#define __forceinline inline
#else
#define __forceinline
#endif
#endif

// PUBG (4.3.0) Created by @JokerRepo and for pattern @enen
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class PixUI.PixUIBrushWrapper
// 0x0010 (0x0038 - 0x0028)
class UPixUIBrushWrapper : public UObject
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIBrushWrapper");
		return pStaticClass;
	}

};


// Class PixUI.PixUIBPLibrary
// 0x0000 (0x0028 - 0x0028)
class UPixUIBPLibrary : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIBPLibrary");
		return pStaticClass;
	}


	struct FString PixUI_Version();
	void PixUI_Tick(float fDeltaTime);
	bool PixUI_StartupEx(const struct FString& strCachePathForWrite, bool bSupportAsyncModel);
	bool PixUI_Startup(const struct FString& strCachePathForWrite);
	bool PixUI_Shutdown();
	void PixUI_SetTickIntervalSec(float fTickIntervalSec);
	void PixUI_SetSupportTextShape(bool beSupportTextShape);
	void PixUI_SetSupportEngineFont(bool bSupportEngineFont);
	void PixUI_SetSpecialCapability(const struct FString& strCapability);
	void PixUI_SetSecretKey(const struct FString& strSecretKey);
	void PixUI_SetPxLibDefaultVersionTag(int nNewPxLibVersionTag);
	void PixUI_SetPixUIMaxLayerId(int nMaxLayerId);
	void PixUI_SetPixUIMaxDynamicTextureTotalSize(int nMaxDynamicTextureTotalSize);
	void PixUI_SetPixUIMaxDynamicTextureGCSize(int nMaxDynamicTextureGCSize);
	void PixUI_SetPixUIMaxDynamicTextureGCRate(float fMaxGCRate);
	void PixUI_SetMobileUseTouchEvent(bool bUseTouchEvent);
	void PixUI_SetMatRootPath(const struct FString& strMatRootPath);
	void PixUI_SetMatBasePath(const struct FString& strMatBasePath);
	void PixUI_SetMatAsyncLoad(bool bMatAsyncLoad);
	void PixUI_SetJsGCThreshold(int nGCThreshold);
	void PixUI_SetGradientBrushCallFlushCommands(bool beGradientBrushCallFlushCommands);
	void PixUI_SetFontTypeFaceName(const struct FString& strFontName, EPxFontFaceType ePxFontTypeFace, const struct FString& strFontTypeFaceName);
	void PixUI_SetExternalInterface(const TScriptInterface<class UPixUIExternalInterface>& scriptInterfaceExternal);
	void PixUI_SetExtBpCallSupportThrowException(bool bSupportThrowException);
	void PixUI_SetDynamicTextureUpdateMode(EPxDynamicTextureUpdateMode eUpdateMode);
	void PixUI_SetDynamicTextureFilter(TEnumAsByte<ETextureFilter> eTextureFilter);
	bool PixUI_SetDynamicLibraryPath(struct FString* strDynamicLibraryPath);
	void PixUI_SetDynamicFixFontSize(bool bOpenDynamicFix);
	void PixUI_SetDrawEffectNoPixelSnapping(bool bNoPixelSnapping);
	void PixUI_SetDefaultFontSize(int nFontSize);
	void PixUI_SetDefaultFont(const struct FString& strFontName);
	void PixUI_SetCoreTickDuration(int nDurationCount);
	bool PixUI_SetCoreLibValidByTag(int nVersionTag, bool bValid);
	void PixUI_SetAutoTick(bool bAutoTick);
	void PixUI_SetAsyncMode(bool beRunAsyncMode);
	void PixUI_SetAsyncBpCallWaitOutTime(float fTimeOutSecond);
	bool PixUI_SetAndroidDyLibSearchEnvPath(const struct FString& strDyLibSearchEnvPath);
	int PixUI_RHIShaderPlatform();
	int PixUI_RHIShaderLevel();
	void PixUI_RemoveSystemFont(const struct FString& strFontName);
	bool PixUI_RemoveDynamicLibraryPath(const struct FString& strDynamicLibraryPath);
	void PixUI_PublicCapabilitySwitch(EPxPublicCapability EPxDebugInfo, bool bOpen);
	void PixUI_PrintProfilerInfo();
	float PixUI_PlatformOSVersionCode();
	struct FString PixUI_PlatformOSVersion();
	int PixUI_PlatformCode();
	struct FString PixUI_Platform();
	bool PixUI_IsSupportTextShape();
	bool PixUI_IsStartUp();
	bool PixUI_IsRHIShaderVulkan();
	bool PixUI_IsRHIShaderOpenGLES2();
	bool PixUI_IsRHIShaderOpenGL();
	bool PixUI_IsRHIShaderMetal();
	bool PixUI_IsRHIShaderDX();
	bool PixUI_IsOsBit64();
	bool PixUI_IsOsBit32();
	bool PixUI_IsMobileUseTouchEvent();
	bool PixUI_IsDynamicFixFontSize();
	bool PixUI_IsAutoTick();
	class UObject* PixUI_GetWindowSlotObject(int nWindowID, const struct FString& strTagId);
	int PixUI_GetTotalFontCount();
	float PixUI_GetTickIntervalSec();
	void PixUI_GetSupportPxLibVersionTagArray(TArray<int>* arraySupportPxLibVersionTag);
	bool PixUI_GetSupportEngineFont();
	class UPixUIScriptVM* PixUI_GetScriptVMByID(int nScriptVmId);
	int PixUI_GetPxLibDefaultVersionTag();
	class UObject* PixUI_GetPixUIWidgetSlotObject(int nPxWidgetID, const struct FString& strSlotTagId);
	class UPixUIWidget* PixUI_GetPixUIWidgetByID(int nPxWidgetID);
	int PixUI_GetPixUIMaxLayerId();
	int PixUI_GetPixUIMaxDynamicTextureTotalSize();
	int PixUI_GetPixUIMaxDynamicTextureGCSize();
	float PixUI_GetPixUIMaxDynamicTextureGCRate();
	struct FString PixUI_GetMatRootPath();
	struct FString PixUI_GetMatBasePath();
	bool PixUI_GetMatAsyncLoad();
	int PixUI_GetJsGCThreshold();
	bool PixUI_GetGradientBrushCallFlushCommands();
	struct FString PixUI_GetFontTypeFaceName(const struct FString& strFontName, EPxFontFaceType ePxFontTypeFace);
	struct FString PixUI_GetFontPathByIndex(int nIndex);
	bool PixUI_GetFontPath(const struct FString& strFontName, struct FString* strOutFontPath);
	struct FString PixUI_GetFontNameByIndex(int nIndex);
	bool PixUI_GetExtBpCallSupportThrowException();
	EPxDynamicTextureUpdateMode PixUI_GetDynamicTextureUpdateMode();
	TEnumAsByte<ETextureFilter> PixUI_GetDynamicTextureFilter();
	void PixUI_GetDynamicLibraryPaths(TArray<struct FString>* arrayOutPaths);
	bool PixUI_GetDrawEffectNoPixelSnapping();
	void PixUI_GetDefaultFontSize(int* nOutFontSize);
	void PixUI_GetDefaultFont(struct FString* strFontName);
	int PixUI_GetCoreTickDuration();
	int PixUI_GetCoreLibVersionTagByIndex(int nIndex);
	int PixUI_GetCoreLibCount();
	void PixUI_GetCachePath(struct FString* strOutCachePath);
	bool PixUI_GetAsyncMode();
	float PixUI_GetAsyncBpCallWaitOutTime();
	class UPixUIWidget* PixUI_FindByWindowID(int nWindowID);
	void PixUI_DebugInfoSwitch(EPxDebugInfo EPxDebugInfo, bool bOpen);
	class UPixUIWidget* PixUI_CreateWidget();
	class UPixUIViewPortWidget* PixUI_CreateViewPortWidget();
	class UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvasEx(class UCanvasPanel* pParentCanvas);
	class UPixUIViewPortWidget* PixUI_CreateViewPortAddToCanvas(class UCanvasPanel* pParentCanvas, const struct FAnchors& Anchors, const struct FMargin& Margin);
	class UPixUIScriptVM* PixUI_CreateScriptVM();
	class UPixUIWidget* PixUI_CreateAddToCanvasEx(class UCanvasPanel* pParentCanvas);
	class UPixUIWidget* PixUI_CreateAddToCanvas(class UCanvasPanel* p_ParentCanvas, const struct FAnchors& Anchors, const struct FMargin& Margin);
	void PixUI_ClearDynamicLibraryPaths();
	void PixUI_ClearCacheFile();
	bool PixUI_CallPixUIAssetGC(int nViewId);
	bool PixUI_BePublicCapabilityOpen(EPxPublicCapability EPxDebugInfo);
	bool PixUI_BeDebugInfoOpen(EPxDebugInfo EPxDebugInfo);
	void PixUI_AddSystemFont(const struct FString& strFontName, const struct FString& strFontPath);
	bool PixUI_AddDynamicLibraryPath(const struct FString& strDynamicLibraryPath);
};


// Class PixUI.PixUIExternalInterface
// 0x0000 (0x0028 - 0x0028)
class UPixUIExternalInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIExternalInterface");
		return pStaticClass;
	}


	bool OnWidgetUnload(class UWidget* pWidget);
	class UWidget* OnWidgetLoad(const struct FString& strWidgetPath, const struct FString& strWidgetTag);
	class UPixUIBrushWrapper* OnSlateBrushLoad(const struct FString& strBrushPath);
	bool OnFileLoad(const struct FString& StrFilePath, const struct FScriptDelegate& callDelegate);
	bool OnFileCanLoad(const struct FString& StrFilePath);
};


// Class PixUI.PixUIInput
// 0x0038 (0x0060 - 0x0028)
class UPixUIInput : public UObject
{
public:
	struct FScriptDelegate                             DelegateActivateInput;                                    // 0x0028(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             DelegateDeactivateInput;                                  // 0x0038(0x0010) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0048(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIInput");
		return pStaticClass;
	}


	void OnInputText(const struct FString& strInsert, bool bEndInput, bool bLostFocus, bool bReplace);
	class UPixUIInput* Get();
};


// Class PixUI.PixUIRenderTarget
// 0x0140 (0x0168 - 0x0028)
class UPixUIRenderTarget : public UObject
{
public:
	struct FScriptMulticastDelegate                    DelegateOnCreate;                                         // 0x0028(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnClose;                                          // 0x0038(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnDestroy;                                        // 0x0048(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnLoaded;                                         // 0x0058(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateInit;                                // 0x0068(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateDone;                                // 0x0078(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnInternalError;                                  // 0x0088(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateOnExternalOpen;                                   // 0x0098(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptMulticastDelegate                    DelegateOnExternalClose;                                  // 0x00A8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnMessage;                                        // 0x00B8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAlert;                                          // 0x00C8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateOnConfirm;                                        // 0x00D8(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             DelegateOnPrompt;                                         // 0x00E8(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptMulticastDelegate                    DelegateOnAppForeground;                                  // 0x00F8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAppBackground;                                  // 0x0108(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	int                                                pxLibVersionTag;                                          // 0x0118(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4C];                                      // 0x011C(0x004C) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIRenderTarget");
		return pStaticClass;
	}


	void SetTickIntervalSec(float fTickIntervalSec);
	void SetExternalRenderTarget2D(class UTextureRenderTarget2D* pTextureRenderTarget);
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	void SetBeDelayCallMessage(bool bDelayMessage);
	struct FString SendPxMessage(const struct FString& strMessage);
	void ReSize(int nNewWidth, int nNewHeight);
	void ReScale(float fScale);
	int PostPxMessage(const struct FString& strMessage);
	void OnExternalTouchEvent(const struct FVector2D& v2dPosTouch, int nPointerIndex, EPxTouchType ETouchType);
	void OnExternalTextInput(const struct FString& strNewInput, bool beEndInput, bool beLostFocus, bool beReplace);
	void OnExternalMouseEvent(const struct FVector2D& v2dPosMouse, const struct FVector2D& v2dOffsetWheel, EPxMouseType eMouseType, EPxKeyEventType uEvent);
	void OnExternalKeyBoardEvent(const struct FKeyEvent& KeyEvent, EPxKeyEventType eEventType);
	void OnExternalGamepadEvent(const struct FKeyEvent& KeyEvent, EPxKeyEventType eEventType);
	void OnExternalGamepadAnalogEvent(const struct FAnalogInputEvent& AnalogInputEvent, EPxKeyEventType eEventType);
	int LoadPageFromUrl(const struct FString& strUrl);
	int LoadPageFromGameAssetPath(const struct FString& strAssetPath);
	int LoadPageFromData(const struct FString& strBasePath, TArray<unsigned char>* arrayData);
	bool IsPxViewValid();
	void HistoryGo(int nStep);
	int GetRenderTarget2DWidth();
	int GetRenderTarget2DHeight();
	class UTextureRenderTarget2D* GetRenderTarget2D();
	struct FString GetCoreLibVersion();
	void DestroyPage();
	int Create(int nWidth, int nHeight, float fScale, bool bAsyncModel, bool bCoreLibAsyncModel, bool bGammaSpace, bool bAntiAliasing);
	void ClosePage();
};


// Class PixUI.PixUIScriptVM
// 0x00E8 (0x0110 - 0x0028)
class UPixUIScriptVM : public UObject
{
public:
	struct FScriptMulticastDelegate                    DelegateOnCreate;                                         // 0x0028(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnClose;                                          // 0x0038(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnDestroy;                                        // 0x0048(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnLoaded;                                         // 0x0058(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateInit;                                // 0x0068(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateDone;                                // 0x0078(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnInternalError;                                  // 0x0088(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateOnExternalOpen;                                   // 0x0098(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptMulticastDelegate                    DelegateOnExternalClose;                                  // 0x00A8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnMessage;                                        // 0x00B8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAppForeground;                                  // 0x00C8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAppBackground;                                  // 0x00D8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	int                                                pxLibVersionTag;                                          // 0x00E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x24];                                      // 0x00EC(0x0024) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIScriptVM");
		return pStaticClass;
	}


	void SetTickIntervalSec(float fTickIntervalSec);
	void SetScriptGlobalString(const struct FString& StrName, const struct FString& strKey, const struct FString& strValue);
	void SetScriptGlobalNumber(const struct FString& StrName, const struct FString& strKey, float fValue);
	void SetScriptGlobalBoolean(const struct FString& StrName, const struct FString& strKey, bool bValue);
	void SetJsGCThreshold(int nGCThreshold);
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	void SetBeDelayCallMessage(bool bDelayMessage);
	struct FString SendPxMessage(const struct FString& strMessage, int nWaitMS);
	int PostPxMessage(const struct FString& strMessage, int nWaitMS);
	int LoadUrl(const struct FString& strUrl, int nWaitMS);
	bool IsValid();
	bool IsPxVmValid();
	struct FString GetScriptGlobalString(const struct FString& StrName, const struct FString& strKey);
	float GetScriptGlobalNumber(const struct FString& StrName, const struct FString& strKey);
	bool GetScriptGlobalBoolean(const struct FString& StrName, const struct FString& strKey);
	int GetPxVMId();
	struct FString GetCoreLibVersion();
	int DoFile(const struct FString& StrFilePath, int nWaitMS);
	int DoBufferByAssetPath(const struct FString& strAssetPath, const struct FString& StrName, const struct FString& strModuleName, int nWaitMS);
	int DoBuffer(TArray<unsigned char> arrayData, const struct FString& strBasePath, const struct FString& StrName, const struct FString& strModuleName, int nWaitMS);
	int DestroyVM(int nWaitMS);
	void CreateScriptGlobal(const struct FString& StrName);
	int CreateEx(bool bAsyncMode, bool bCoreLibAsyncMode, int nWaitMS);
	int Create(bool bAsyncMode, int nWaitMS);
	int CloseVM(int nWaitMS);
};


// Class PixUI.PixUIViewPortWidget
// 0x0038 (0x0298 - 0x0260)
class UPixUIViewPortWidget : public UUserWidget
{
public:
	struct FScriptDelegate                             PixUIWidgetOpenDelegate;                                  // 0x0260(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             PixUIWidgetConfirmDelegate;                               // 0x0270(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             PixUIWidgetPromptDelegate;                                // 0x0280(0x0010) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0290(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIViewPortWidget");
		return pStaticClass;
	}


	struct FString SendPxMessage(const struct FString& strMessage);
	void PostPxViewMessage(const struct FString& strMessage);
	int PostPxMessage(const struct FString& strMessage);
	void OnPixUITransformDelegate(EPxWidgetTransformType EPxWidgetTransformType, int nParam1, int nParam2);
	struct FString OnPixUIPromptDelegate(const struct FString& strTip, const struct FString& strDefault);
	int OnPixUIOpenDelegate(const struct FString& strUrl, const struct FString& StrName, const struct FString& strFeatures, bool bReplace);
	bool OnPixUIConfirmDelegate(const struct FString& strConfirmMsg);
	int LoadPxViewFromUrl(const struct FString& strUrl);
	int LoadPxViewFromGameAssetPath(const struct FString& strAssetPath);
	int LoadPxViewFromData(const struct FString& strRootPath, TArray<unsigned char>* arrayData);
	int LoadPageFromUrl(const struct FString& strUrl);
	int LoadPageFromGameAssetPath(const struct FString& strAssetPath);
	int LoadPageFromData(const struct FString& strRootPath, TArray<unsigned char>* arrayData);
	class UPixUIWidget* GetPixUIWidget();
	void ClosePxView();
	void ClosePage();
};


// Class PixUI.PixUIWidget
// 0x0228 (0x0358 - 0x0130)
class UPixUIWidget : public UCanvasPanel
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0130(0x0008) MISSED OFFSET
	struct FScriptMulticastDelegate                    DelegateOnCreate;                                         // 0x0138(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnClose;                                          // 0x0148(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnDestroy;                                        // 0x0158(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnLoaded;                                         // 0x0168(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateInit;                                // 0x0178(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnScriptStateDone;                                // 0x0188(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnInternalError;                                  // 0x0198(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateOnExternalOpen;                                   // 0x01A8(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptMulticastDelegate                    DelegateOnExternalClose;                                  // 0x01B8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnMessage;                                        // 0x01C8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAlert;                                          // 0x01D8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateOnConfirm;                                        // 0x01E8(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptDelegate                             DelegateOnPrompt;                                         // 0x01F8(0x0010) (Edit, ZeroConstructor, InstancedReference)
	struct FScriptMulticastDelegate                    DelegateOnTransform;                                      // 0x0208(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAppForeground;                                  // 0x0218(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    DelegateOnAppBackground;                                  // 0x0228(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptDelegate                             DelegateHookKeyEvent;                                     // 0x0238(0x0010) (Edit, ZeroConstructor, InstancedReference)
	int                                                pxLibVersionTag;                                          // 0x0248(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsAsync;                                                 // 0x024C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsCoreLibAsync;                                          // 0x024D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsForcePaint;                                            // 0x024E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsLazyReleaseMode;                                       // 0x024F(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EPxWidgetBatchType                                 BatchType;                                                // 0x0250(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0251(0x0007) MISSED OFFSET
	struct FText                                       TextDefaultUrl;                                           // 0x0258(0x0018) (Edit, BlueprintVisible)
	bool                                               bIsStateNodeMode;                                         // 0x0270(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsRHIRender;                                             // 0x0271(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsRHIRenderAntiAliasing;                                 // 0x0272(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPxSlotTopHit;                                            // 0x0273(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsRetainMode;                                            // 0x0274(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bNoPixelSnapping;                                         // 0x0275(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xE2];                                      // 0x0276(0x00E2) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PixUIWidget");
		return pStaticClass;
	}


	void ShowNextDrawItem();
	void ShowNextDrawBatch();
	void ShowAllDrawItem();
	void ShowAllDrawBatch();
	void SetTickMode(EPxTickMode eTickMode);
	void SetTickIntervalSec(float fTickIntervalSec);
	void SetScriptGlobalString(const struct FString& StrName, const struct FString& strKey, const struct FString& strValue);
	void SetScriptGlobalNumber(const struct FString& StrName, const struct FString& strKey, float fValue);
	void SetScriptGlobalBoolean(const struct FString& StrName, const struct FString& strKey, bool bValue);
	void SetJsGCThreshold(int nGCThreshold);
	void SetBeSupportEventCallNested(bool bSupportEventCallNested);
	void SetBeDelayCallMessage(bool bDelayMessage);
	void SetBackgroundBlur(float fBlurStrength);
	void SetAutoTransform(bool bAutoTransform);
	struct FString SendPxMessage(const struct FString& strMessage);
	int PostPxMessage(const struct FString& strMessage);
	int OpenPageFromUrl(const struct FString& strUrl);
	int OpenPageFromGameAssetPath(const struct FString& strAssetPath);
	int OpenPageFromData(const struct FString& strBasePath, TArray<unsigned char>* arrayData);
	void OnExternalTouchEvent(const struct FVector2D& v2dPosTouch, int nPointerIndex, EPxTouchType ETouchType);
	void OnExternalTextInput(const struct FString& strNewInput, bool beEndInput, bool beLostFocus, bool beReplace);
	void OnExternalMouseEvent(const struct FVector2D& v2dPosMouse, const struct FVector2D& v2dOffsetWheel, EPxMouseType eMouseType, EPxKeyEventType uEvent);
	void OnExternalKeyBoardEvent(const struct FKeyEvent& KeyEvent, EPxKeyEventType eEventType);
	void OnExternalGamepadEvent(const struct FKeyEvent& KeyEvent, EPxKeyEventType eEventType);
	void OnExternalGamepadAnalogEvent(const struct FAnalogInputEvent& AnalogInputEvent, EPxKeyEventType eEventType);
	int LoadPageFromUrl(const struct FString& strUrl);
	int LoadPageFromGameAssetPath(const struct FString& strAssetPath);
	int LoadPageFromData(const struct FString& strBasePath, TArray<unsigned char>* arrayData);
	bool IsPxViewValid();
	void HistoryGo(int nStep);
	class UObject* GetSlotObjectByTagId(const struct FString& strSlotTagId);
	struct FString GetScriptGlobalString(const struct FString& StrName, const struct FString& strKey);
	float GetScriptGlobalNumber(const struct FString& StrName, const struct FString& strKey);
	bool GetScriptGlobalBoolean(const struct FString& StrName, const struct FString& strKey);
	int GetPxWinId();
	class UWidget* GetCtrlWidget();
	struct FString GetCoreLibVersion();
	void DestroyPage();
	void CreateScriptGlobal(const struct FString& StrName);
	void ClosePage();
};


// Class PixUI.PxCustomDelegate
// 0x0060 (0x0088 - 0x0028)
class UPxCustomDelegate : public UObject
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0028(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxCustomDelegate");
		return pStaticClass;
	}


	void OnPxCustomDelegate();
	class UPxCustomDelegate* MakeCustomDelegate(const struct FString& strCustomDelegateName);
};


// Class PixUI.PxCustomInterfaceDyImp
// 0x00B8 (0x00E0 - 0x0028)
class UPxCustomInterfaceDyImp : public UObject
{
public:
	unsigned char                                      UnknownData00[0xB8];                                      // 0x0028(0x00B8) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxCustomInterfaceDyImp");
		return pStaticClass;
	}


	class UPxCustomInterfaceDyImp* MakeCustomInterface(const struct FString& strCustomInterfaceName, class UClass* pOverrideBaseClass);
};


// Class PixUI.PxFileLoad
// 0x0078 (0x00A0 - 0x0028)
class UPxFileLoad : public UObject
{
public:
	unsigned char                                      UnknownData00[0x78];                                      // 0x0028(0x0078) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxFileLoad");
		return pStaticClass;
	}


	void OnFileLoad(TArray<unsigned char> arrayFileData);
};


// Class PixUI.PxSubLayerWidget
// 0x03A0 (0x04A0 - 0x0100)
class UPxSubLayerWidget : public UWidget
{
public:
	unsigned char                                      UnknownData00[0x3A0];                                     // 0x0100(0x03A0) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxSubLayerWidget");
		return pStaticClass;
	}

};


// Class PixUI.PxSubCtrlWidget
// 0x0010 (0x04B0 - 0x04A0)
class UPxSubCtrlWidget : public UPxSubLayerWidget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x04A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxSubCtrlWidget");
		return pStaticClass;
	}

};


// Class PixUI.PxSubNodeWidget
// 0x03A0 (0x04A0 - 0x0100)
class UPxSubNodeWidget : public UWidget
{
public:
	unsigned char                                      UnknownData00[0x3A0];                                     // 0x0100(0x03A0) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUI.PxSubNodeWidget");
		return pStaticClass;
	}

};


}

